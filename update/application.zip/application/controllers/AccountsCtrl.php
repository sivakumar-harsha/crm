<?php
 
 defined('BASEPATH') OR exit('No direct script access allowed');

 class AccountsCtrl extends CI_Controller {

	public function __construct()
	{
        parent::__construct();
        $this->load->database();
        $this->load->model("AccountsMod","am");
        $this->load->model('MasterMod','mm');
        $this->load->model('ReportMod','rm');
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->helper('cookie');
        $this->load->library('upload');
    }
  
  
  public function Accounttree()
  {
      if($this->session->userdata("session_role") == "admin")
      {
          $pro_data["project_info"] = $this->mm->fetch_project_info();
          $this->load->view("header",$pro_data);
          $this->load->view("accountree");
          $this->load->view("footer",$pro_data);
      }
      else
      {
          redirect("login");
      }
  }
  
  public function fetch_main_ledgers()
  {
        if($this->session->has_userdata('logged_in')) 
        {  
           $res = $this->am->fetch_main_ledgers();
           echo json_encode($res);
        }
  }
  
  public function add_sub_ledger()
  {
       if($this->session->has_userdata('logged_in')) 
       { 
           $main_ledger_id = $this->input->post("main_ledger_id");
           $sub_ledger_name = $this->input->post("sub_ledger_name");
           $acc_id = $this->am->get_last_acc_id();
           $accid = $acc_id->accid+1;
           $vchaccid = "acc".$accid;
           
           $parent_id = substr($main_ledger_id,3);
           
           if($main_ledger_id == "acc1" || $main_ledger_id == "acc2" || $acc_id  =="acc3" || $acc_id  =="acc4")
           {
               $charactertype = "1";

               $data = array(
                       "accid" =>$accid,
                       "vchaccid" =>$vchaccid,
                       "vch" =>"acc",
                       "vchaccname" =>$sub_ledger_name,
                       "vchparentid" =>$main_ledger_id,
                       "parentid" => $parent_id,
                       "chracctype" =>$charactertype,
                   );
                 $res = $this->am->add_sub_ledger($data);
                echo "success";
           }

       }
  }
  
  public function fetch_all_sub_ledgers()
  {
       if($this->session->has_userdata('logged_in')) 
       {
           $main_ledger = $this->input->post("main_ledger");
           $res = $this->am->fetch_all_sub_ledgers($main_ledger);
           echo json_encode($res);
       }
  }
  
  public function add_multi_sub_ledger()
  {
      if($this->session->has_userdata('logged_in')) 
       {
           $main_ledger_id = $this->input->post("main_ledger_id");
           $sub_ledger_id = $this->input->post("add_sub_ledger_id");
           $acc_name = $this->input->post("add_acc_name");
           $add_type = $this->input->post("add_type");
           $tree_type = $this->input->post("tree_type");
           $lastid = $this->am->get_last_acc_id();
           
           $accid = $lastid->accid+1;
           $vchaccid =  "acc".$accid;
           $parent_id = substr($sub_ledger_id,3);
           
            $data = array(
               "accid" =>$accid,
               "vch" =>"acc",
               "vchaccid" =>$vchaccid,
               "vchaccname" =>$acc_name,
               "vchparentid" =>$sub_ledger_id,
               "parentid" =>$parent_id,
               "chracctype" =>$tree_type,
               "cr_dr_status" =>$add_type,
            );
            $res = $this->am->add_sub_ledger($data);
           echo "success";
       }
  }
  
  public function fetch_accounts_tree()
  {
      if($this->session->has_userdata('logged_in')) 
      {
            $draw = intval($this->input->post("draw"));
    		
    		$res = $this->am->fetch_account_tree();
    	
    		$arr = [];
            $a = 0 ;
            
            foreach($res as $da)
            {
                $a++;
                
              $account_id = "<a href='#' onclick=view_data(".$da->accid.")>".$da->account_id."</a>";
                
                $arr[] = 
                        array(
                            $a,
                            $account_id,
                            $da->account_name,
                            $da->numaccbalance,
                        );
            }
            
      	   $result = array(
            			"draw"=> $draw,
    				    "recordsTotal"=>count($res),
    				    "recordsFiltered"=> count($res),
    				    "data"=>$arr,
    				);
            echo json_encode($result);
       }
  }
  
  public function get_child_account_tree()
  {
      if($this->session->has_userdata('logged_in')) 
      {
          $accid = $this->input->post("accid");
          
          $data = $this->am->get_account_details($accid);
          
          $res = $this->am->get_child_account_tree($accid);
          
          $content = "";
          
          $content .= "<h4 style='font-size:14px;'>".$data->account_name."</h4>";
          $content .= "<table class='table table-bordered' width='100%'>";
                         
              $content .= "<thead>
                                    <tr>
                                        <th>S.no</th>
                                        <th>Account Id</th>
                                        <th>Account Name</th>
                                    </tr>
                           </thead>";    
                           
                           
                $a = 0;
                
                foreach($res as $da){
                    
                    $a++;
                    $content .= "<tr>
                                  <td>".$a."</td>
                                  <td><a href='#' onclick=view_data_1(".$da->accid.")>".$da->account_id."</a></td>
                                  <td>".$da->account_name."</td>
                                  <div id='sub_data'></div>
                              </tr>";
                }
              $content .= "</table>";
              
             echo $content;
      }
  }
  
  
  public function general_receipt()
  {
      if($this->session->userdata("session_role") == "admin")
      {
            $pro_data["project_info"] = $this->mm->fetch_project_info();
            $data["account_head"] =$this->am->get_account_head_for_general_receipt();
            $this->load->view("header",$pro_data);
            $this->load->view("general_receipt",$data);
            $this->load->view("footer",$pro_data);
      }
      else
      {
          redirect("login");
      }
  }
  
  
  public function add_general_receipt()
  {
      if($this->session->has_userdata('logged_in')) 
      {
        $account_head = $this->input->post("account_head");
        $date = $this->input->post("date");
        $particulars = $this->input->post("particulars");
        $amount = $this->input->post("amount");
        $narration = $this->input->post("narration");
        $paymode = $this->input->post("paymode");
        $bank  = $this->input->post("bank");
        $bank_branch = $this->input->post("bank_branch");
        $cheque_no = $this->input->post("cheque_no");
        $transaction_no  = $this->input->post("transaction_no");
        $trans_date = $this->input->post("trans_date");
        
        $date = date("Y-m-d H:i:s");
        $year = date('y');
        $month = date('m');
                
        if($month < 4)
        {
           $year = $year-1;
        }
        
        $x = 0;
        
        do 
        {
          $x++;
          $gr_no = "gr".$x."/".$year;
        } 
        while($this->am->check_receipt_no_already_exits($gr_no));
       
          $data = array(
              "receipt_no" =>$gr_no,
              "account_id" =>$account_head, 
              "particulars" =>$particulars,
              "amount" =>$amount,
              "pay_mode" =>$paymode,
              "transaction_date" =>$trans_date,
              "narration" =>$narration,
              "bank" =>$bank,
              "branch" =>$bank_branch,
              "cheque_no" =>$cheque_no,
              "transaction_no"  =>$transaction_no,
              "date_time" =>$date,
          );
          $res = $this->am->add_general_receipt($data);
          
          //$this->credit_cash_entry($particulars,$amount);
          
          echo $gr_no;
      }
  }
  
  public function get_particulars_by_account_head()
  {
      if($this->session->has_userdata('logged_in')) 
      {
          $account_head = $this->input->post("account_head");
          $res = $this->am->get_particulars_by_account_head($account_head);
          $content = "<option value = ''>--Select--</option>";
          foreach($res as $da)
          {
              $content .="<option value=".$da->account_id.">".$da->account_name."</option>";
          }
          echo $content;
      }
  }
  
  
  public function print_general_receipt()
  {
       if($this->session->has_userdata('logged_in')) 
      {
          $gr_no = $this->input->get("gr_no");
          $company_details = $this->rm->get_company_details();
          $res = $this->am->print_general_receipt($gr_no);
          $acc_name = $this->am->get_account_name($res->account_id);
          $particulars = $this->am->get_account_name($res->particulars);
          
               $content = "<!DOCTYPE html>
                                    <html>
                                    <head>
                                        <title>Receipt Id : ".$gr_no." </title>
                                        <style>
                                            *{
                                                padding:1px;
                                                margin:0px;
                                                font-family: 'Courier';
                                                font-size:12px;
                                            }
                                        </style>
                                    </head>
                                    <body>
                                        <div style='border:1px solid #aaa;padding:10px;margin:30px;'>
                                        <center><p style='font-size:20px;padding-top:0px;'>General Receipt</p></center>
                                        <table style='width:100%'>
                                            <tr>
                                                <td style='padding:15px;'>
                                                    <p style='margin-top:5px;font-size:17px;'>".$company_details->name."</p>
                                                    <p style='margin-top:5px;'>".$company_details->city."</p>
                                                 </td>
                                                <td style='text-align: right;padding:15px;'>
                                                    <p style='margin-top:5px;'><img src='./datas/temp/phone-icon.PNG' style='width:12px;'> +91 ".$company_details->phone." </p>
                                                    <p style='margin-top:5px;'><img src='./datas/temp/email-icon.PNG' style='width:12px;'> ".$company_details->email." </p>
                                                    <br>
                                                </td>
                                            </tr>
                                        </table>";
                                        
                                        
                            $content .= "<table style='width:100%;>
                                            <tr>
                                                <td style='width:25%;padding:5px;text-align: left;'></td>
                                                <td style='width:25%;padding:5px;text-align: left;'></td>
                                                <td style='width:25%;padding:5px;text-align: right;'></td>
                                                <td style='width:25%;padding:5px;text-align: right;'>Date  : ".date_format(date_create($res->transaction_date),"d-m-Y")."</td>
                                            </tr>";
                                      
                            $content .= "</table>";
                            
                            
                            $content .= "<h4 align='center' style='background-color:#dff0d8;padding:5px;'>Payment Details</h4>";
                            
                            $content .= "<table style='width:100%;'>
                                          
                                           <tr>
                                                <td style='width:25%;padding:5px;text-align: left;'>Account Head</td>
                                                <td style='width:25%;padding:5px;text-align: center;'>:</td>
                                                <td style='width:25%;padding:5px;text-align: right;'>".$acc_name->account_name."</td>
                                           </tr>
                                           
                                            <tr>
                                                <td style='width:25%;padding:5px;text-align: left;'>Pariculars</td>
                                                <td style='width:25%;padding:5px;text-align: center;'>:</td>
                                                <td style='width:25%;padding:5px;text-align: right;'>".$particulars->account_name."</td>
                                           </tr>
                                           
                                          <tr>
                                                <td style='width:25%;padding:5px;text-align: left;'>Pay Mode</td>
                                                <td style='width:25%;padding:5px;text-align: center;'>:</td>
                                                <td style='width:25%;padding:5px;text-align: right;'>".$res->pay_mode."</td>
                                           </tr>";
                                           
                                        if($res->pay_mode != "Cash")
                                           {
                                            $content .= " <tr>
                                                            <td style='width:25%;padding:5px;text-align: left;'>Bank</td>
                                                            <td style='width:25%;padding:5px;text-align: center;'>:</td>
                                                            <td style='width:25%;padding:5px;text-align: right;'>".$res->bank."</td>
                                                          </tr>
                                                   
                                                        <tr>
                                                            <td style='width:25%;padding:5px;text-align: left;'>Branch</td>
                                                            <td style='width:25%;padding:5px;text-align: center;'>:</td>
                                                            <td style='width:25%;padding:5px;text-align: right;'>".$res->branch."</td>
                                                        </tr>";
                                                        
                                                if($res->pay_mode == "Cheque")
                                                {
                                                     $content .= " <tr>
                                                            <td style='width:25%;padding:5px;text-align: left;'>Cheque</td>
                                                            <td style='width:25%;padding:5px;text-align: center;'>:</td>
                                                            <td style='width:25%;padding:5px;text-align: right;'>".$res->cheque_no."</td>
                                                          </tr>";
                                                }
                                                else if($res->pay_mode == "Transfer")
                                                {
                                                    $content .= " <tr>
                                                            <td style='width:25%;padding:5px;text-align: left;'>Transaction no</td>
                                                            <td style='width:25%;padding:5px;text-align: center;'>:</td>
                                                            <td style='width:25%;padding:5px;text-align: right;'>".$res->transaction_no."</td>
                                                          </tr>";
                                                }
                                           }
                                           
                                           $content .= "<tr>
                                                <td style='width:25%;padding:5px;text-align: left;'>Amount</td>
                                                <td style='width:25%;padding:5px;text-align: center;'>:</td>
                                                <td style='width:25%;padding:5px;text-align: right;'>".$res->amount."</td>
                                           </tr>
                                           
                                            <tr>
                                                <td style='width:25%;padding:5px;text-align: left;'>Narrations</td>
                                                <td style='width:25%;padding:5px;text-align: center;'>:</td>
                                                <td style='width:25%;padding:5px;text-align: right;'>".$res->narration."</td>
                                           </tr>";
                                  
                      
                            $content .= "</table>";
                            $this->load->library('pdf');
                            $this->pdf->loadHtml($content);
                            $this->pdf->render();
                            $filename = "Gr_receipt('".$gr_no."')";
                            $this->pdf->stream("'$filename'".".pdf", array("Attachment" => false));
      }
  }
  
  
  public function main_cash_voucher()
  {
      if($this->session->userdata("session_role") == "admin")
      {
            $pro_data["project_info"] = $this->mm->fetch_project_info();
            $data["account_head"] =$this->am->get_account_head_for_general_receipt();
            $this->load->view("header",$pro_data);
            $this->load->view("main_cash_voucher",$data);
            $this->load->view("footer",$pro_data);
      }
      else
      {
          redirect("login");
      }
  }
 
 
     public function credit_cash_entry($particulars,$amount)
     {
          if($this->session->has_userdata('logged_in')) 
          {
              $check_amt = $this->am->get_cash_entry($particulars);
              $balance_amt = $check_amt->numaccbalance + $amount;
              $data = array("numaccbalance" =>$balance_amt);
              $res = $this->add_credit_cash_entry($data,$particulars);
              //echo "success";
          }
     }
     
     public function add_mv_receipt()
     {
          if($this->session->has_userdata('logged_in')) 
          {
                $account_head = $this->input->post("account_head");
                $date = $this->input->post("date");
                $sub_category = $this->input->post("sub_category");
                $amount = $this->input->post("amount");
                $narration = $this->input->post("narration");
                $paymode = $this->input->post("paymode");
                $cash_release = $this->input->post("cash_release");
                $bank  = $this->input->post("bank");
                $bank_branch = $this->input->post("bank_branch");
                $cheque_no = $this->input->post("cheque_no");
                $transaction_no  = $this->input->post("transaction_no");
                $trans_date = $this->input->post("trans_date");
                
                $date = date("Y-m-d H:i:s");
                $year = date('y');
                $month = date('m');
                        
                if($month < 4)
                {
                   $year = $year-1;
                }
                
                $x = 0;
                
                
                if($cash_release == "Petty_Cash")
                {
                    do 
                    {
                      $x++;
                      $mv_no = "PC".$x."/".$year;
                    } 
                    while($this->am->check_pc_receipt_no_already_exits($mv_no));
                }
                else 
                {
                    do 
                    {
                      $x++;
                      $mv_no = "MV".$x."/".$year;
                    } 
                    while($this->am->check_mv_receipt_no_already_exits($mv_no));
                }

                  $data = array(
                      "receipt_no" =>$mv_no,
                      "account_id" =>$account_head, 
                      "sub_category" =>$sub_category,
                      "debit" =>$amount,
                      "pay_mode" =>$paymode,
                      "transaction_date" =>$trans_date,
                      "narration" =>$narration,
                      "bank" =>$bank,
                      "branch" =>$bank_branch,
                      "cheque_no" =>$cheque_no,
                      "transaction_no"  =>$transaction_no,
                      "date_time" =>$date,
                  );
                  
                   $res = $this->am->add_mv_receipt($data);
                 
                    if($paymode == "Cash")
                    { 
                      $this->calc_cash_balance($amount,$cash_release);
                    }
                    else 
                    {
                        $this->calc_cash_balance($amount);
                    }
                  
                  echo $mv_no;
          }
     }
     
     public function fetch_cash_balance()
     {
          if($this->session->has_userdata('logged_in')) 
          {
              $res = $this->am->fetch_cash_balance();
              echo json_encode($res);
          }
     }
     
     public function calc_cash_balance($amount,$cash_release)
     {
          if($this->session->has_userdata('logged_in')) 
          {
              if($cash_release == "Petty_cash")
              {
                  $petty_cash = $this->get_petty_cash_amount();
                  $balance = $petty_cash - $amount;
                  
                  $array = array("numaccbalance" =>$balance);
                  $res = $this->update_pettycash_balance($array);
              }
              else 
              {
                  
              }
          }
     }
     
      
	  public function view_accounts_ledger()
	  {
	      if($this->session->has_userdata('logged_in')) 
           {
                $pro_data["project_info"] = $this->mm->fetch_project_info();
                $data["account_head"] =$this->am->get_account_head_for_general_receipt();
        		$this->load->view('header',$pro_data);
        		$this->load->view('view_ledger_accounts',$data);
        		$this->load->view('footer',$pro_data);
           }
	  }
	  
	  public function fetch_view_accounts_ledger()
	  {
	       if($this->session->has_userdata('logged_in')) 
           {
               
               $acc_head = $this->input->post("acc_head");
               $acc_sub = $this->input->post("acc_sub_category");
               $from_date = $this->input->post("f_date");
               $to_date = $this->input->post("to_date");
               $res = $this->am->fetch_view_accounts_ledger($acc_head,$acc_sub,$from_date,$to_date);
               $content = "";
               $content .="<table class = 'table table-bordered' style='width:100%'>
                            
                            <thead>
                                 <tr>
                                      <th>S.no</th>
                                      <th>Acc Sr No</th>
                                      <th>DATE</th>
                                      <th>Account Name</th>
                                      <th>Debit</th>
                                      <th>Credit</th>
                                      <th>Balance</th>
                                      <th>Note</th>
                                 </tr>
                            </thead><tbody>";
                            
                
                 $a = 0;
                            
                 foreach($res as $da)
                 {
                    $a++;
                    $content .="<tr>
                                      <td>".$a."</td>
                                      <td>".$da->sr_no."</td>
                                      <td>".date_format(date_create($da->datetime),"d-m-Y h:i:s a")."</td>
                                      <td>".$da->account_name." (".$da->cr_parent_id.")</td>
                                      <td>".$da->debit."</td>
                                      <td>".$da->credit."</td>
                                      <td></td>
                                      <td>".$da->note."</td>
                                 </tr>";
                 }

               $content .="</table>";
               echo $content;
           }
	  }

}

?>
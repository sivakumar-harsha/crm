<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LeadCtrl extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('Configmod','cm');
		$this->load->model('LeadMod','lm');
		$this->load->model('MasterMod','mm');
		$this->load->model('PayoutMod','pm');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper('cookie');
	}
	
	public function create_lead()
	{
	    if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
    	{    		
		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
		   	$data["users"] = $this->lm->fetch_users();
		   	$data["ai"] = $this->lm->fetch_ai();
		   	$data["agents_pos"] = $this->lm->fetch_agents_pos();
		   	$data["policy_type"] = $this->lm->fetch_list_of_policy_type_motor();
		   	$data["client_type"] = $this->lm->fetch_client_type();
		   	$data["business"] = $this->lm->fetch_business_type();
		   	$data["class"] = $this->lm->fetch_list_of_class();
		   	$data["fuel_type"] = $this->lm->fetch_fuel_type();
		   	$data["rto"] = $this->lm->fetch_rto();
		   	$data["state"] = $this->lm->fetch_state();
		   	$data["region"] = $this->lm->fetch_region();
    		$this->load->view('header',$pro_data);
    		$this->load->view('lead',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else if($this->session->has_userdata('logged_in') && ($this->session->userdata('session_role') == "user" || $this->session->userdata('session_role') == "AI"))
	    {
	        $pro_data["project_info"] = $this->mm->fetch_project_info();
	        
	        if($this->session->userdata("session_role") == "user")
	        {
	           $data["agents_pos"] = $this->lm->fetch_agents_pos();
	           
	           $data["region"] = $this->lm->fetch_region();
	        }
	        else if($this->session->userdata("session_role") == "AI")
	        {
	            $data["agents_pos"] = $this->lm->fetch_agents_pos_by_area_incharge($this->session->userdata("session_id"));
	            $data["region"] = $this->lm->fetch_region_by_area_incharge($this->session->userdata("session_id"));
	        }
	        
	        $data["users"] = $this->lm->fetch_users();
	        $data["ai"] = $this->lm->fetch_ai();
	        $data["client_type"] = $this->lm->fetch_client_type();
	        $data["business"] = $this->lm->fetch_business_type();
	        $data["class"] = $this->lm->fetch_list_of_class();
	        $data["policy_type"] = $this->lm->fetch_list_of_policy_type_motor();
	        $data["fuel_type"] = $this->lm->fetch_fuel_type();
	        $data["rto"] = $this->lm->fetch_rto();
	        $data["state"] = $this->lm->fetch_state();
    		$this->load->view('header',$pro_data);
    		$this->load->view('lead',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else
	    {
	    	redirect("login");
	    }
	}
	
	
	public function add_lead_details()
	{
	    if($this->session->has_userdata('logged_in'))
	    {
	        $client_type = $this->input->post("client_type");
	        $client_name = $this->input->post("client_name");
	        $mobile_no = $this->input->post("mobile_no");
	        $other_contact_details = $this->input->post("other_contact_details");
	        $landline_no = $this->input->post("landline_no");
	        $address = $this->input->post("address");
	        $email_id = $this->input->post("email_id");
	        $contact_person_name = $this->input->post("contact_person_name");
	        $contact_person_des = $this->input->post("contact_person_des");
	        $dob = $this->input->post("dob");
	        $age = $this->input->post("age");
	        $area = $this->input->post("area");
	        $pin = $this->input->post("pin_code");
	        
	        $bussiness_type = $this->input->post("bussiness_type");
	        $class = $this->input->post("policy_class");
	        $policy_type = $this->input->post("policy_type");
	        $lead_generated_date =  $this->input->post("lead_generated_date");
	        $due_date =  $this->input->post("due_date");
	        $broken_policy =  $this->input->post("broken_policy");
	        $location=  $this->input->post("location");
	        $classification =  $this->input->post("classification");
	        $source =  $this->input->post("source");
	        $agent_pos = $this->input->post("agent_pos");
	        $assign_to_user =  $this->input->post("assign_to_user");
	        $area_incharge = $this->input->post("area_incharge");
	        
	        $v_regn_no = $this->input->post("v_regn_no");
	        
	        $region = $this->lm->fetch_agent_region($agent_pos);
	        
	        $region_id = "";
	        
	        if($region != null)
	        {
	            $region_id = $region->region;
	        }
	        
	        $remarks = $this->input->post("remarks");
	        $lead_created_by = $this->session->userdata('session_name');
	        
	        $file = $this->input->post("files");
	        
	        $created_date = date("Y-m-d H:i:sa");
	        $updated_date = date("Y-m-d H:i:sa");
	        
	        $res_1 = $this->lm->fetch_vechi_regn_no_already_exits($v_regn_no);
	      
	       $data = array( 
	             "client_type_id" =>$client_type,
	             "client_name" =>$client_name,
	             "mobile_no" =>$mobile_no,
	             "other_contact_details"=>$other_contact_details,
	             "landline_no" => $landline_no,
	             "address" =>$address,
	             "email" =>$email_id,
	             "contact_person_name" =>$contact_person_name,
	             "contact_person_designation"=>$contact_person_des,
	             "date_of_birth" => $dob,
	             "age" =>$age,
	             "area" =>$area,
	             "pin_code" =>$pin,
	             );
	             
	       $res = $this->lm->add_client_details($data);
	             
	             
        	    if(isset($_FILES))
        		{
        			$config['upload_path'] = './datas/old_policy_document/';
        			$config['allowed_types'] = '*';
        			
        			$this->load->library('upload',$config);
        			$this->upload->initialize($config);
        			if(!$this->upload->do_upload('file'))
        			{
        				$file = '';
        			}
        			else
        			{
        				$file = $this->upload->data('file_name');
        			}
        		}
		
	             if($res != "")
	             {
    	             $arr = array( 
    	             "client_id" =>$res,
    	             "business_type" =>$bussiness_type,
    	             "class"=>$class,
    	             "policy_type" => $policy_type,
    	             "lead_generated_date" => $lead_generated_date,
    	             "due_date" =>$due_date,
    	             "broken_policy" => $broken_policy,
    	             "location" =>$location,
    	             "classfication" =>$classification,
    	             "source"=>$source,
    	             "lead_status"=>"open",
    	             "agency_and_pos" => $agent_pos,
    	             "assigned_user" => $assign_to_user,
    	             "area_incharge" =>$area_incharge,
    	              "region_id" =>$region_id,
    	             "remarks" =>$remarks,
    	             "lead_created_by" =>$lead_created_by,
    	             "old_policy_document" =>$file,
    	             "lead_created_id" =>$this->session->userdata('session_id'),
    	             "created_date"=>$created_date,
    	             "updated_date"=>$updated_date
    	             );
    	             
    	             $data_1 = $this->lm->add_lead_details($arr);
	             }
	             
	             if($class == "1")
	             {
                    $v_info = array("lead_id"=>$data_1,"vechi_register_no" =>$v_regn_no);
                    $add_v_info = $this->lm->add_vechicle_regn_no($v_info);   
	             }
                    
                    $activity_log = array("lead_id"=>$data_1,"action"=>"Created <b>New Lead</b>","action_type"=>"new_lead_creation","created_by"=>$lead_created_by,"time"=>$created_date);
                    $add_activity = $this->lm->add_activity_log($activity_log);
                    echo $data_1;
	    }
	}
	    
	    public function get_lead_details()
	    {
    	    if($this->session->has_userdata('logged_in'))
    	    {
    	        $id = $this->input->post("last_inserted_id");
    	        $res = $this->lm->get_lead_details($id);
    	        echo json_encode($res);
    	    }
	    }
	    
	    public function add_follow_up_details()
	    {
    	    if($this->session->has_userdata('logged_in'))
    	    {
    	        $id = $this->input->post("id");
    	        $follow_up_status = $this->input->post("follow_up_status");
    	        $follow_up_reason = $this->input->post("follow_up_reason");
    	        $next_follow_date = $this->input->post("enter_next_follow_date");
    	        $enter_next_follow_time = $this->input->post("enter_next_follow_time");
    	        $follow_comment =$this->input->post("follow_comment");
    	        $follow_up_created_date = date("Y-m-d");
    	         
    	        $check = $this->lm->check_follow_up_already_exits($id);
    	      
    	        if($check !="" && $check != NULL)
    	        {
    	            foreach($check as $da)
    	            {
    	                
    	                $data_lead = array("next_follow_up_date"=>$next_follow_date,"last_follow_up_date" =>$da->next_follow_up_date,"follow_up_reason"=>$follow_up_reason,"follow_up_created_date"=>$follow_up_created_date,"next_follow_up_time" => $enter_next_follow_time,"lead_status" =>"followup");
    	                $res = $this->lm->update_follow_up_details($data_lead,$id);
    	            }
    	        }
    	        else
    	        {
    	             $data_lead = array("next_follow_up_date"=>$next_follow_date,"follow_up_reason"=>$follow_up_reason,"follow_up_created_date"=>$follow_up_created_date,"next_follow_up_time" => $enter_next_follow_time,"lead_status" =>"followup");
    	             $res = $this->lm->update_follow_up_details($data_lead,$id);
    	        }
    	        
    	        $data = array("lead_id"=>$id,"follow_up_status"=>$follow_up_status,"next_follow_up_date"=>$next_follow_date,"next_follow_up_time" =>$enter_next_follow_time,"reason"=>$follow_up_reason,"comment" =>$follow_comment,"follow_up_created_date"=>$follow_up_created_date);
    	        $res = $this->lm->add_follow_up_details($data);
    	        
    	       if($check !="" && $check != NULL)
    	        {
        	        foreach($check as $da)
        	        {
        	            $update_data = array("last_follow_up_date" =>$da->next_follow_up_date,"last_status_update" =>$da->follow_up_created_date);
        	            echo json_encode($update_data);
        	        }
    	        }
    	        else
    	        {
    	            $update_data = array("last_follow_up_date" =>"","last_status_update" =>date("Y-m-d"));
        	       echo json_encode($update_data);
    	        }
    	        
    	        $activity_log = array(
                                "lead_id"=>$id,
                                "action"=>"created followup with reason  : <b><i>".$follow_up_reason."</i></b>. New Followup Set to <b>".date_format(date_create($next_follow_date),"d-m-Y")." ".date("h:i:s a",strtotime($enter_next_follow_time))."</b>",
                                "action_type"=>"Follow_up",
                                "created_by"=>$this->session->userdata('session_name'),
                                "time"=>date("Y-m-d H:i:sa"));
                $add_activity = $this->lm->add_activity_log($activity_log);
    	    }
	    }
	    
	    public function fetch_policy_type_using_class()
	    {
	        if($this->session->has_userdata('logged_in'))
    	    {
    	        $policy_class = $this->input->post("policy_class");
    	        $res = $this->lm->fetch_policy_type_using_class($policy_class);
    	        echo json_encode($res);
    	    }
	    }
	    
	    public function fetch_make()
	    {
	        if($this->session->has_userdata('logged_in'))
    	    {
    	        $vechile_type = $this->input->post("vechile_type");
    	        
    	        $res=array();
    	         
    	        if($vechile_type == "1" || $vechile_type == "3" || $vechile_type == "68")
    	        {
    	            $res = $this->lm->fetch_make_car();
    	        }
    	        else if($vechile_type == "2")
    	        {
    	            $res = $this->lm->fetch_make_bike();
    	        }
    	        else if($vechile_type == "4")
    	        {
    	            $res = $this->lm->fetch_e_two_wheeler();
    	        }
    	        else if($vechile_type == "7" || $vechile_type == "12" || $vechile_type == "13" || $vechile_type == "14" || $vechile_type == "59" || $vechile_type == "60" || $vechile_type == "65" || $vechile_type == "66" || $vechile_type == "69" || $vechile_type == "70")
    	        {
    	            $res = $this->lm->fetch_pc_make($vechile_type);
    	        }
    	        else if($vechile_type == "8" || $vechile_type == "9" || $vechile_type == "10" || $vechile_type == "15" || $vechile_type == "16" || $vechile_type == "61")
    	        {
    	            $res = $this->lm->fetch_gc_make($vechile_type);
    	        }
    	        else if($vechile_type == "20")
    	        {
    	            $res = $this->lm->fetch_misc_make();
    	        }
    	        else if($vechile_type == "55")
    	        {
    	            $res = $this->lm->fetch_scooter_make();
    	        }
    	        echo json_encode($res);
    	    }
	    }
	    
	    public function fetch_model()
	    {
	        if($this->session->has_userdata('logged_in'))
    	    {
    	        $vechile_type = $this->input->post("vechile_type");
    	        $vechi_make = $this->input->post("vechi_make");
    	        
    	        $res = array();
    	        
    	        if($vechile_type == "1" || $vechile_type == "3" || $vechile_type == "68")
    	        {
    	            $res = $this->lm->fetch_car_model($vechi_make);
    	        }
    	        else if($vechile_type == "2")
    	        {
    	            $res = $this->lm->fetch_bike_model($vechi_make);
    	        }
    	        else if($vechile_type == "4")
    	        {
    	            $res = $this->lm->fetch_e_two_wheeler_model($vechi_make);
    	        }
    	        else if($vechile_type == "7" || $vechile_type == "12" || $vechile_type == "13" || $vechile_type == "14" || $vechile_type == "59" || $vechile_type == "60" || $vechile_type == "65" || $vechile_type == "66" || $vechile_type == "69" || $vechile_type == "70")
    	        {
    	            $res = $this->lm->fetch_pc_model($vechile_type,$vechi_make);
    	        }
    	        else if($vechile_type == "8" || $vechile_type == "9" || $vechile_type == "10" || $vechile_type == "15" || $vechile_type == "16" || $vechile_type == "61")
    	        {
    	            $res = $this->lm->fetch_gc_model($vechile_type,$vechi_make);
    	        }
    	        else if($vechile_type == "20")
    	        {
    	            $res = $this->lm->fetch_misc_model($vechi_make);
    	        }
    	        else if($vechile_type == "55")
    	        {
    	            $res = $this->lm->fetch_scooter_model($vechi_make);
    	        }
    	        echo json_encode($res);
    	    }
	    }
	    
	    public function fetch_vechile_varient()
	    {
	       if($this->session->has_userdata('logged_in'))
    	    {
    	        $vechile_type = $this->input->post("vechile_type");
    	        $vechi_make = $this->input->post("vechi_make");
    	        $vechi_model = $this->input->post("vechi_model");
    	        
    	        $res = array();
    	        
    	        if($vechile_type == "1" || $vechile_type == "3" || $vechile_type == "68")
    	        {
    	            $res = $this->lm->fetch_car_varient($vechi_make,$vechi_model);
    	        }
    	        else if($vechile_type == "2")
    	        {
    	            $res = $this->lm->fetch_bike_varient($vechi_make,$vechi_model);
    	        }
    	        else if($vechile_type == "4")
    	        {
    	            $res = $this->lm->fetch_e_two_wheeler_varient($vechi_make,$vechi_model);
    	        }
    	        else if($vechile_type == "7" || $vechile_type == "12" || $vechile_type == "13" || $vechile_type == "14" || $vechile_type == "59" || $vechile_type == "60" || $vechile_type == "65" || $vechile_type == "66" || $vechile_type == "69" || $vechile_type == "70")
    	        {
    	            $res = $this->lm->fetch_pc_varient($vechile_type,$vechi_make,$vechi_model);
    	        }
    	        else if($vechile_type == "8" || $vechile_type == "9" || $vechile_type == "10" || $vechile_type == "15" || $vechile_type == "16" || $vechile_type == "61")
    	        {
    	            $res = $this->lm->fetch_gc_varient($vechile_type,$vechi_make,$vechi_model);
    	        }
    	        else if($vechile_type == "20")
    	        {
    	            $res = $this->lm->fetch_misc_varient($vechi_make,$vechi_model);
    	        }
    	        else if($vechile_type == "55")
    	        {
    	            $res = $this->lm->fetch_scooter_varient($vechi_make,$vechi_model);
    	        }
    	        echo json_encode($res);
    	    }
	    }
	    
	    
	    public function add_vechile_details()
	    {
	        if($this->session->has_userdata('logged_in'))
    	    {
    	          $id = $this->input->post("id");
            	  $vechile_type = $this->input->post("vechile_type");
            	  $policy_type = $this->input->post("policy_type");
                  $vechi_make =$this->input->post("vechi_make");
                  $vechi_model =$this->input->post("vechi_model");
                  $vechi_varient =$this->input->post("vechi_varient");
                  $vechi_cc =$this->input->post("vechi_cc");
                  $vechi_manu_month =$this->input->post("vechi_manu_month");
                  $vechi_manu_year =$this->input->post("vechi_manu_year");
                  $vechi_seating =$this->input->post("vechi_seating");
                  $vechi_classfication =$this->input->post("vechi_classfication");
                  $vechi_fuel_type =$this->input->post("vechi_fuel_type");
                  $vechi_gvw =$this->input->post("vechi_gvw");
                  $passenger_carrying =$this->input->post("passenger_carrying");
                  $vechi_engine_num =$this->input->post("vechi_engine_num");
                  $vechi_chassis_num =$this->input->post("vechi_chassis_num");
                  $vechi_hypothecation =$this->input->post("vechi_hypothecation");
                  $created_user =$this->input->post("created_user");
                  $vechi_remarks =$this->input->post("vechi_remarks");
                  $regn_date =$this->input->post("regn_date");
                  $register_no =$this->input->post("register_no"); 
                  $rto =$this->input->post("rto");
                  $zone =$this->input->post("zone");
                  $regn_address =$this->input->post("regn_address");
                  $state =$this->input->post("state");
                  $city =$this->input->post("city");
                  $pincode =$this->input->post("pincode");
                  $vechi_user_name =$this->input->post("vechi_user_name");
                  $vechi_user_cont =$this->input->post("vechi_user_cont");
                  $date = date("Y-m-d");
                  
                  $data = array(
                        "lead_id" =>$id,
                        "vechile_type" =>$vechile_type,
                        "policy_type" =>$policy_type,
                        "vechi_make" =>$vechi_make,
                        "vechi_model" =>$vechi_model,
                        "vechi_varient" =>$vechi_varient,
                        "vechi_cc" =>$vechi_cc,
                        "vechi_manu_month" =>$vechi_manu_month,
                        "vechi_manu_year" =>$vechi_manu_year,
                        "vechi_seating" =>$vechi_seating,
                        "vechi_classfication" =>$vechi_classfication,
                        "vechi_fuel_type" =>$vechi_fuel_type,
                        "vechi_gvw" =>$vechi_gvw,
                        "passenger_carrying" =>$passenger_carrying,
                        "vechi_engine_num" =>$vechi_engine_num,
                        "vechi_chassis_num" =>$vechi_chassis_num,
                        "vechi_hypothecation" =>$vechi_hypothecation,
                        "created_by" =>$created_user,
                        "vechi_remarks" =>$vechi_remarks,
                        "regn_date" =>$regn_date,
                        "vechi_register_no" =>$register_no,
                        "rto" =>$rto,
                        "zone" =>$zone,
                        "regn_address" =>$regn_address,
                        "state" =>$state,
                        "city" =>$city,
                        "pincode" =>$pincode,
                        "vechi_user_name" =>$vechi_user_name,
                        "vechi_user_cont" =>$vechi_user_cont,
                        "created_at" =>$date,
                      );
                  
                   $check_lead_id = $this->lm->check_this_lead_id_already_exits($id);
                  
                  if($check_lead_id > 0)
                  {
                      $res = $this->lm->update_vechicle_details_1($data,$id);
                  }
                  else
                  {
                      $res = $this->lm->add_vechicle_details($data);
                  }
                  
                  
                  $activity_log = array("lead_id"=>$id,"action"=>"<i><b>New Vechicle</b></i> Details Added","action_type"=>"add_vechicle","created_by"=>$this->session->userdata('session_name'),"time"=>date("Y-m-d H:i:s"));
                 $add_activity = $this->lm->add_activity_log($activity_log);
    	    }
	    }
	    public function get_exp_date()
	    {
	        $date = $this->input->post("date");
	        $newDate = date("Y-m-d", strtotime(date("Y-m-d", strtotime($date)) . " + 1 year"));
	        echo date("Y-m-d", strtotime(date("Y-m-d", strtotime($newDate)) . " - 1 day"));
	    }
	    
	    public function get_vechile_details()
	    {
	        if($this->session->has_userdata('logged_in'))
    	    {
    	        $id = $this->input->post("id");
    	        
    	        $vehi_type = $this->lm->get_vechile_type($id);
    	        
    	        $res = array();
    	       
    	        if($vehi_type != null)
    	        {
    	            if($vehi_type->policy_type == "1" || $vehi_type->policy_type == "68")
    	            {
    	                $res = $this->lm->get_car_details($id);  
        	        }
        	        else if($vehi_type->policy_type == "2")
        	        {
        	            $res = $this->lm->get_bike_details($id);  
        	        }
        	        else if($vehi_type->policy_type == "3")
        	        {
        	            $res = $this->lm->get_car_details($id);  
        	        }
        	        else if($vehi_type->policy_type == "4")
        	        {
        	            $res = $this->lm->get_bike_details($id);  
        	        }
                	else if($vehi_type->policy_type == "7" || $vehi_type->policy_type == "12" || $vehi_type->policy_type == "13" || $vehi_type->policy_type == "14" || $vehi_type->policy_type == "59" || $vehi_type->policy_type == "60" || $vehi_type->policy_type == "65" || $vehi_type->policy_type == "66" || $vehi_type->policy_type == "69" ||$vehi_type->policy_type == "70")
                    {
                            $res = $this->lm->get_pc_details($id,$vehi_type->policy_type);
                    }
                    else if($vehi_type->policy_type == "8" || $vehi_type->policy_type == "9" || $vehi_type->policy_type == "10" || $vehi_type->policy_type == "15" || $vehi_type->policy_type == "16" || $vehi_type->policy_type == "61")
                    {
                            $res = $this->lm->get_gc_details($id,$vehi_type->policy_type);
                    }
                    else if($vehi_type->policy_type == "20")
                    {
                            $res = $this->lm->fetch_make_misc($id);
                    }
                    else if($vehi_type->policy_type == "55")
                    {
                        $res = $this->lm->fetch_make_scooter($id);
                    }
    	        }
    	        
    	        echo json_encode($res);
    	    }
	    }
	    
	    
	 public function upload_document_files()
	 {
	      if($this->session->has_userdata('logged_in'))
    	    {
        	   $id = $this->input->post("id");
        	   $document_type = $this->input->post("document_type");
        	    if(isset($_FILES))
        		{
        			$config['upload_path'] = './datas/documents/';
        			$config['allowed_types'] = '*';
        			
        			$this->load->library('upload',$config);
        			$this->upload->initialize($config);
        			if(!$this->upload->do_upload('file'))
        			{
        				$file = '';
        				$file_path = "";
        			}
        			else
        			{
        				$file_path = base_url().'datas/documents/'.$this->upload->data('file_name');
        				$file = $this->upload->data('file_name');
        			}
        		}
        		
        		$data = array("lead_id" =>$id,"document_type"=>$document_type,"document_file" =>$file);
        		$res = $this->lm->upload_document_files($data);
        		
        		$html = "";
        		$html .="<tr>
        		           <td><a href='./datas/documents/".$res->document_file."'><i class='fa fa-file'></i></a></td>
        		           <td>".$res->document_file."</td>
        		           <td>".$res->document_type."</td>
        		           <td><i class='fa fa-edit' onclick=edit_data(".$res->id.")></i></td>
        		           <td><i class='fa fa-trash' onclick=delete_data(".$res->id.")></i></td>
        		         </tr>";
        		 echo $html;
    	    }	 
	 }
	 
	 public function move_lead_to_prospect()
	 {
	      if($this->session->has_userdata('logged_in'))
    	    {
        	     $id = $this->input->post("id");
        	     $data = array("lead_type" =>'1');
        	     $res = $this->lm->move_lead_to_prospect($id,$data);
        	     
        	     $activity_log = array("lead_id"=>$id,"action"=>"Generated <b><i>Prospect</b></i>","action_type"=>"prospect","created_by"=>$this->session->userdata('session_name'),"time"=>date("Y-m-d H:i:s"));
                 $add_activity = $this->lm->add_activity_log($activity_log);
    	    }
	 }
	 
	 public function move_classification()
	 {
	      if($this->session->has_userdata('logged_in'))
    	    {
        	     $id = $this->input->post("id");
        	     $classfication = $this->input->post("val");
        	     if($classfication == 4)
        	     {
        	         $lead_data = $this->lm->get_receiver_email_id($id);
        	         $due_date = "";
        	         if($lead_data != null)
        	         {
        	            $due_date = $lead_data->due_date;
        	            if($due_date != "0000-00-00")
        	            {
        	                $due_date = date("Y-m-d", strtotime(date("Y-m-d", strtotime($due_date)) . " + 1 year"));
        	                $data = array("lead_status" => "lost","due_date" => $due_date);
        	                $res = $this->lm->move_classification($id,$data);   
        	            }
        	         }
        	     }
        	     else
        	     {
    	            $data = array("classfication" =>$classfication);
    	            $res = $this->lm->move_classification($id,$data);  
        	     }
    	    }
	 }
	 
	 public function move_to_lead()
	 {
	     if($this->session->has_userdata('logged_in'))
    	    {
        	     $id = $this->input->post("id");
        	     $data = array("lead_type" =>'0');
        	     $res = $this->lm->move_to_lead($id,$data);
    	    }
	 }
	 
	 // Admin // 
	 
	 public function leads()
	 {
	     if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
    	{    		
		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
		   	$data["users"] = $this->lm->fetch_users();
		   	$data["client_type"] = $this->lm->fetch_client_type();
		   	$data["business"] = $this->lm->fetch_business_type();
		   	$data["class"] = $this->lm->fetch_list_of_class();
		   	$data["policy_type"] = $this->lm->fetch_list_of_policy_type_motor();
    		$this->load->view('header',$pro_data);
    		$this->load->view('view_all_leads',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else if($this->session->has_userdata('logged_in') && ($this->session->userdata('session_role') == "user" || $this->session->userdata('session_role') == "AI"))
	    {
	        $pro_data["project_info"] = $this->mm->fetch_project_info();
	        $data["users"] = $this->lm->fetch_users();
	        $data["client_type"] = $this->lm->fetch_client_type();
	        $data["business"] = $this->lm->fetch_business_type();
	        $data["class"] = $this->lm->fetch_list_of_class();
	        $data["policy_type"] = $this->lm->fetch_list_of_policy_type_motor();
    		$this->load->view('header',$pro_data);
    		$this->load->view('view_all_leads',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else
	    {
	    	redirect("login");
	    }
	 }
	 
	 public function fetch_all_leads()
	 {
	     if($this->session->has_userdata('logged_in'))
    	 {
    	     $draw = intval($this->input->post("draw"));
    	     
    	     $lead_type = $this->input->post("lead_type");
    	     $classification = $this->input->post("classification");
    	     $category = $this->input->post("category");
    	     $bulk_status = $this->input->post("bulk_status");
    	     $order_category = $this->input->post("order_category");
    	     $search = $this->input->post("text");
    	     
    	     $res = $this->lm->fetch_all_leads($lead_type,$classification,$category,$bulk_status,$order_category,$search);
    	     
    	     $arr = [];
    	     
    	     $a = $_POST['start'];
    	     
    	     $res1 = array();
    	     $res2 = array();
    	     $res3 = array();
    	     $res4 = array();
    	     
    	     foreach($res as $da)
    	     {
    	         if($da->due_date >= date("Y-m-d"))
    	         {
    	             $res1[] = $da;
    	         }
    	         else if($da->due_date == "0000-00-00")
    	         {
    	             $res4[] = $da;
    	         }
    	         else
    	         {
    	             $res2[] = $da;
    	         }
    	     }
    	     rsort($res2);
    	     foreach($res1 as $da)
    	     {
    	         $res3[] = $da;
    	     }
    	     foreach($res2 as $da)
    	     {
    	         $res3[] = $da;
    	     }
    	     foreach($res4 as $da)
    	     {
    	         $res3[] = $da;
    	     }
    	     
         foreach($res3 as $da)
         {
    	         $a++;
    	         
    	   $action = "<a href='create_lead?id=".$da->id."' class='btn btn-warning btn-xs'><i class='fa fa-eye'></i></a>";
    	   
        	 if($da->lead_type == '0' && $da->classfication == '1' && $da->policy_status == '0')
        	 {
        	     $action .= "&nbsp;<button onclick=move_prospect(".$da->id.") class='btn btn-primary btn-xs'><i class='fa fa-diamond'></i> Prospect</button>";
        	     
        	     $action .= "&nbsp;<button onclick=move_classfication(".$da->id.") class='btn btn-danger btn-xs'><i class='fa fa-arrows'></i> Move</button>";
        	 }
        	 else if($da->lead_type == '1' && $da->classfication == '1' && $da->policy_status == '0')
        	 {
        	     $action .= "&nbsp;<button onclick=move_to_lead(".$da->id.") class='btn btn-danger btn-xs'><i class='fa fa-arrows'></i> Lead</button>";
                
                 if($da->quote_status == '0')
                 {
                    $action .= "&nbsp;<button onclick=send_quote(".$da->id.",'".$da->lclass."')  class='btn btn-success btn-xs'><i class='fa fa-whatsapp'></i> Quote</button>";
                 }
                 else
                 {
                     $action .= "&nbsp;<button onclick=send_quote(".$da->id.",'".$da->lclass."')  class='btn btn-info btn-xs'><i class='fa fa-check'></i>Quote sent</button>";
                 }
                 
                 if($da->due_date != "0000-00-00")
        	     {
        	        $action .= "&nbsp;<button onclick=move_to_nextyear(".$da->id.") class='btn btn-primary btn-xs'><i class='fa fa-step-forward'></i></button>";   
        	     }
        	 }
        	 else if($da->policy_status == '1')
        	 {
        	     $action .= "&nbsp;<a href='generate_policy?id=".$da->id."' class='btn btn-primary btn-xs'><i class='fa fa-file'></i> Save policy</a>";
        	 }
        	 else
        	 {
        	     $action .= "&nbsp;<button onclick=move_classfication(".$da->id.") class='btn btn-danger btn-xs'><i class='fa fa-arrows'></i> Move</button>";
        	     if($da->due_date != "0000-00-00")
        	     {
        	        $action .= "&nbsp;<button onclick=move_to_nextyear(".$da->id.") class='btn btn-primary btn-xs'><i class='fa fa-step-forward'></i></button>";   
        	     }
        	 }
        	 
        	 $agn_name = "";
        	 $usr_name = "";
        	 
        	  $date = "No Due Date";
        	 
        	 if($da->due_date != "0000-00-00")
        	 {
        	    $date = date_format(date_create($da->due_date),"d-m-Y"); 
        	 }
        	 
        	 if($da->agency_and_pos != "all")
        	 {
        	     if($da->agency_and_pos != "")
        	     {
            	     $get_agent_name = $this->lm->get_agent_name($da->agency_and_pos);
            	     $agn_name = $get_agent_name->name;
        	     }
        	     else
        	     {
        	         $agn_name = "";
        	     }
        	 }
        	 else
        	 {
        	     $agn_name = "";
        	 }
        	 
        	 if($da->assigned_user != "all")
        	 {
        	     if($da->assigned_user != "")
        	     {
            	     $get_user = $this->lm->get_user_name($da->assigned_user);
            	     
            	     if($get_user != "")
            	     {
            	       $usr_name = $get_user->name;
            	     }
            	     else
            	     {
            	         $usr_name = "";
            	     }
        	     }
        	     else
        	     {
        	         $usr_name = "";
        	     }
        	 }
        	 else
        	 {
        	     $usr_name = "";
        	 }
        	 
    	    if($da->area_incharge != "all")
            {
                if($da->area_incharge != "")
                {
                     $ai = $this->lm->get_area_incharge($da->area_incharge);
                     
                     if($ai != null)
                     {
                       $ai = $ai->name;
                     }
                     else
                     {
                         $ai = "";
                     }
                }
                else
                {
                        $ai = "";
                }
            }
            else
            {
                 $ai = "";
            } 
        
          $client_name = "<a href='#' onclick=view_data(".$da->id.")>".$da->client_name."</a>";
            $arr[] =array(
                           $a,
                           $client_name,
                           $da->mobile_no,
                           $da->lclass,
                           $da->p_type,
                           $da->b_type,
                           $da->area,
                           $agn_name,
                           $usr_name,
                           $ai,
                           $date,
                           $action,
                        );
            }
    	   $result = array(
            			"draw"=> $draw,
    				    "recordsTotal"=> $this->lm->get_all_datas_count($lead_type,$classification,$category,$bulk_status,$order_category,$search),
    				    "recordsFiltered"=> $this->lm->get_filtered_datas_count($lead_type,$classification,$category,$bulk_status,$order_category,$search),
    				    "data"=>$arr,
    				);
             echo json_encode($result);
    	 }
	 }
	 
  public function followups()
  {
      if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
    	{    		
		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
		   	$data["users"] = $this->lm->fetch_users();
		   	$data["client_type"] = $this->lm->fetch_client_type();
		   	$data["business"] = $this->lm->fetch_business_type();
		   	$data["class"] = $this->lm->fetch_list_of_policy_type();
    		$this->load->view('header',$pro_data);
    		$this->load->view('followups',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else if($this->session->has_userdata('logged_in') && ($this->session->userdata('session_role') == "user" || $this->session->userdata('session_role') == "AI"))
	    {
	        $pro_data["project_info"] = $this->mm->fetch_project_info();
	        $data["users"] = $this->lm->fetch_users();
	        $data["client_type"] = $this->lm->fetch_client_type();
	        $data["business"] = $this->lm->fetch_business_type();
	        $data["class"] = $this->lm->fetch_list_of_policy_type();
    		$this->load->view('header',$pro_data);
    		$this->load->view('followups',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else
	    {
	    	redirect("login");
	    }
  }
  
  public function fetch_all_follow_ups()
  {
       if($this->session->has_userdata('logged_in'))
       {
           $draw = intval($this->input->post("draw")); 
           
           $from_date = $this->input->post("from_date");
           $to_date = $this->input->post("to_date");
           
           $res = $this->lm->fetch_all_follow_ups($from_date,$to_date);
           
           $arr = [];
           $a = 0 ;
        
        foreach($res as $da)
        {
        	$a++;

            $action = "<button class='btn btn-info btn-xs' onclick=edit_data(".$da->id.")><i class='fa fa-edit'></i></button> 
                      <a class='btn btn-warning btn-xs' onclick=follow_up_log(".$da->lead_id.")><i class='fa fa-eye'></i></a> 
            		 <button class='btn btn-danger btn-xs' onclick=delete_data(".$da->id.")><i class='fa fa-trash-o'></i></button>";
            
            $arr[] = array(
                $a,
                $da->client_name,
                $da->mobile_no,
                date_format(date_create($da->next_follow_up_date),"d-m-Y"),
                date_format(date_create($da->next_follow_up_time),"h:i:sa"),
                date_format(date_create($da->lead_generated_date),"d-m-Y"),
                $da->reason,
                $action,
            );
        }

        $result = array(
        			"draw"=> $draw,
				    "recordsTotal"=>count($res),
				    "recordsFiltered"=> count($res),
				    "data"=>$arr,
				);
        echo json_encode($result);
		
       }
  }
  
  public function delete_follow_up()
  {
      if($this->session->has_userdata('logged_in'))
       {
           $id = $this->input->post("id");
           $res = $this->lm->delete_follow_up($id);
       }
  }
  
  public function fetch_edit_follow_up()
  {
       if($this->session->has_userdata('logged_in'))
       {
           $id = $this->input->post("id");
           $res = $this->lm->fetch_edit_follow_up($id);
           echo json_encode($res);
       }
  }
  
  public function edit_follow_up_details()
  {
       if($this->session->has_userdata('logged_in'))
	    {
	        $id = $this->input->post("id");
	        $lead_id = $this->input->post("lead_id");
	        $follow_up_status = $this->input->post("follow_up_status");
	        $follow_up_reason = $this->input->post("follow_up_reason");
	        $next_follow_date = $this->input->post("enter_next_follow_date");
	        $enter_next_follow_time = $this->input->post("enter_next_follow_time");
	        $follow_comment =$this->input->post("follow_comment");
	        $follow_up_updated_date = date("Y-m-d");
	        
	        $arr = array("next_follow_up_date"=>$next_follow_date);
	        $update = $this->lm->update_follow_up_details($arr,$lead_id);
	      
	        $data = array("follow_up_status"=>$follow_up_status,"next_follow_up_date"=>$next_follow_date,"next_follow_up_time" =>$enter_next_follow_time,"reason"=>$follow_up_reason,"comment" =>$follow_comment,"follow_up_created_date"=>$follow_up_created_date);
	        $res = $this->lm->edit_follow_up_details($data,$id);
	    }
   }
   
  // Generate policy //
  
  public function generate_policy()
  {
        if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
    	{    		
		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
		   	$data["users"] = $this->lm->fetch_users();
		   	$data["client_type"] = $this->lm->fetch_client_type();
		   	$data["business"] = $this->lm->fetch_business_type();
		   	$data["class"] = $this->lm->fetch_list_of_policy_type();
		   	$data["email_templates"] = $this->lm->fetch_email_templates();
		   	$data["company"] = $this->lm->fetch_company();
		   	$data["state"] = $this->lm->fetch_state();
		   	$data["premium_cover_type"] = $this->lm->fetch_premium_cover_type();
	   		$data["rto"] = $this->lm->fetch_rto();
		   	$data["agents_pos"] = $this->lm->fetch_agents_pos();
    		$this->load->view('header',$pro_data);
    		$this->load->view('create_policy',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else if($this->session->has_userdata('logged_in') && ($this->session->userdata('session_role') == "user" || $this->session->userdata('session_role') == "AI"))
	    {
	        $pro_data["project_info"] = $this->mm->fetch_project_info();
	        $data["users"] = $this->lm->fetch_users();
	        $data["client_type"] = $this->lm->fetch_client_type();
	        $data["business"] = $this->lm->fetch_business_type();
	        $data["class"] = $this->lm->fetch_list_of_policy_type();
	        $data["company"] = $this->lm->fetch_company();
		   	$data["state"] = $this->lm->fetch_state();
		   	$data["premium_cover_type"] = $this->lm->fetch_premium_cover_type();
	   		$data["rto"] = $this->lm->fetch_rto();
	        $data["agents_pos"] = $this->lm->fetch_agents_pos();
    		$this->load->view('header',$pro_data);
    		$this->load->view('create_policy',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else
	    {
	    	redirect("login");
	    }
  }
  
      public function upload_policy_document_files()
      {
          if($this->session->has_userdata('logged_in'))
        	    {
            	   $id = $this->input->post("id");
            	   $document_type = $this->input->post("document_type");
            	   
            	    if(isset($_FILES))
            		{
            			$config['upload_path'] = './datas/documents/';
            			$config['allowed_types'] = '*';
            			
            			$this->load->library('upload',$config);
            			$this->upload->initialize($config);
            			if(!$this->upload->do_upload('file'))
            			{
            				$file = '';
            				$file_path = "";
            			}
            			else
            			{
            				$file_path = base_url().'datas/documents/'.$this->upload->data('file_name');
            				$file = $this->upload->data('file_name');
            			}
            		}
            		
            		$data = array("lead_id" =>$id,"document_type"=>$document_type,"document" =>$file);
            		
            		$res = $this->lm->upload_policy_document_files($data);
            		
            		$html = "";
            		$html .="<tr>
            		           <td><a href='./datas/documents/".$res->document."'><i class='fa fa-file'></i></a></td>
            		           <td>".$res->document."</td>
            		           <td>".$res->document_type."</td>
            		           <td><i class='fa fa-edit' onclick=edit_data(".$res->id.")></i></td>
            		           <td><i class='fa fa-trash' onclick=delete_data(".$res->id.")></i></td>
            		         </tr>";
            		 echo $html;
        	    }	 
        	    
      }  
      
      public function fetch_policy_documents()
      {
         if($this->session->has_userdata('logged_in'))
    	 {
    	        
    	       $id = $this->input->post("lead_id");
    	       $res = $this->lm->fetch_policy_doc_files($id); 
    	       $html = "";
    	       
    	       foreach($res as $da)
    	       {
        		$html .="<tr>
        		           <td><a href='./datas/documents/".$da->document."'><i class='fa fa-file'></i></a></td>
        		           <td>".$da->document."</td>
        		           <td>".$da->document_type."</td>
        		           <td><i class='fa fa-edit' onclick=edit_data(".$da->id.")></i></td>
        		           <td><i class='fa fa-trash' onclick=delete_data(".$da->id.")></i></td>
        		         </tr>";
    	       }
    	  }
    	    
    	    echo $html;
      }
  
        public function save_generated_policy()
        {
            if($this->session->has_userdata('logged_in'))
            {
                $policy_no = $this->input->post("policy_no");
                $policy_source = $this->input->post("policy_source");
                $lead_created_by = $this->session->userdata('session_name');
                $category = $this->session->userdata('category');
                $ncb = $this->input->post("ncb"); 
                $total_premium = $this->input->post("total_premium");
                $lead_id = $this->input->post("lead_id");
                $policy_premium= $this->input->post("policy_premium");
                $commission_id = $this->input->post("commission_id");
                $policy_agency_pos = $this->input->post("policy_agency_pos");
                $company = $this->input->post("company");
                $class_type = $this->lm->get_class_type($lead_id);
                $agent_commission = 0;
                $company_com = 0;
                $add_ons_1  = $this->input->post("add_ons_1");
                $add_ons_2  = $this->input->post("add_ons_2");
                $add_ons_3  = $this->input->post("add_ons_3");
                $add_ons_4  = $this->input->post("add_ons_4");
                $add_ons_5  = $this->input->post("add_ons_5");
                $add_ons_1_details  = $this->input->post("add_ons_1_details");
                $add_ons_2_details  = $this->input->post("add_ons_2_details");
                $add_ons_3_details  = $this->input->post("add_ons_3_details");
                $add_ons_4_details  = $this->input->post("add_ons_4_details");
                $add_ons_5_details  = $this->input->post("add_ons_5_details");
                $own_damage = $this->input->post("total_own_damage");
                $tp = $this->input->post("tot_liability_premium");
                $own_damage = $this->input->post("total_own_damage");
                $cpa = $this->input->post("cpa");
                
                $commission_type = "";
                $status = "0";
       
                  if($class_type->class == "1")
                  {
                        $get_lead_info = $this->lm->get_lead_info($lead_id);
                        $bussiness_type = $get_lead_info->business_type;
                        $policy_class = $get_lead_info->class;
                        $policy_type =  $get_lead_info->policy_type;
                        $fuel_type = $get_lead_info->vechi_fuel_type;
                        $cc  = $get_lead_info->vechi_cc;
                        $v_gvw = $get_lead_info->vechi_gvw;
                        $make = $get_lead_info->vechi_make;
                        $model = $get_lead_info->vechi_model;
                        $Varient = $get_lead_info->vechi_varient;
                  }
                  else if($class_type->class == "2")
                  {
                       $bussiness_type = $class_type->business_type;
                       $policy_class = $class_type->class;
                       $policy_type =  $class_type->policy_type;
                       $state = "";
                       $age ="";
                       $rto = "";
                       
                        $disease_husband= $this->input->post("disease_husband");
                        $husband_file= $this->input->post("husband_file");
                        $disease_wife= $this->input->post("disease_husband");
                        $wife_file= $this->input->post("husband_file");
                        $daughter_count = $this->input->post("daughter_count");
                        $son_count = $this->input->post("son_count");
                        $disease_daug_1= $this->input->post("disease_daug_1");
                        $disease_daug_2= $this->input->post("disease_daug_2");
                        $disease_daug_3= $this->input->post("disease_daug_3");
                        $daug_1_file= $this->input->post("daug_1_file");
                        $daug_2_file= $this->input->post("daug_2_file");
                        $daug_2_file= $this->input->post("daug_2_file");
                        $disease_son_1= $this->input->post("disease_son_1");
                        $disease_son_2= $this->input->post("disease_son_2");
                        $disease_son_3= $this->input->post("disease_son_3");
                        $son_1_file= $this->input->post("son_1_file");
                        $son_2_file= $this->input->post("son_2_file");
                        $son_3_file= $this->input->post("son_3_file");
                        $disease_father= $this->input->post("disease_father");
                        $disease_mother= $this->input->post("disease_mother");
                        $father_file= $this->input->post("father_file");
                        $mother_file= $this->input->post("mother_file");
                  }
                
                    if($class_type->class == "1")
                    {
                        $res = $this->lm->fetch_policy_info($commission_id);
                        $commission_type = $res->commission_type;
                        
                        if($res != null && $res->commission_type == "2" || $res->commission_type == "3" || $res->commission_type == "1")
                        {
                                if($res->is_ncb == "Yes" && $no_claim_bonus == "Yes")
                                {
                                          $status = "1";
                                          $company_com = $total_premium * ($res->ncb_percentage)/100;
                                          $agent_status = $this->lm->fetch_agent_category($policy_agency_pos);
                                     
                                          if($agent_status->commission_category == "A")
                                          {
                                              $agent_commission = ($total_premium * $res->a_ncb)/100;
                                          }
                                          else if($agent_status->commission_category == "B")
                                          {
                                                $agent_commission = ($total_premium * $res->b_ncb)/100;
                                          }
                                          else if($agent_status->commission_category == "C")
                                          {
                                                $agent_commission = ($total_premium * $res->c_ncb)/100;
                                          }
                                          else if($agent_status->commission_category == "D")
                                          {
                                                $agent_commission = ($total_premium * $res->d_ncb)/100;
                                          }
                                }
                                else
                                {
                                    if($res->on_net != "0")
                                    {
                                        $own_od = "";
                                        $own_tp = "";
                                        $company_com = $total_premium * ($res->on_net)/100;
                                        $on_net = $company_com;
                                    }
                                    else if($res->own_od != "0" && $res->own_tp != "0")
                                    {
                                        $own_od = $own_damage * ($res->own_od)/100;
                                        $own_tp = $tp * ($res->own_tp)/100;
                                        $company_com = $own_od+$own_tp;
                                        $on_net = "";
                                    }
                                    else if($res->own_od != "0")
                                    {
                                        $on_net = ""; 
                                        $own_tp = "";
                                        $company_com = $own_damage * ($res->own_od)/100;
                                        $own_od = $company_com;
                                    }
                                    else if($res->own_tp != "0")
                                    {
                                        $own_od = ""; 
                                        $on_net = "";
                                        $company_com = $tp * ($res->own_tp)/100;
                                        $own_tp = $company_com;
                                    }
                                
                                      $agent_status = $this->lm->fetch_agent_category($policy_agency_pos);
                                      
                                      if($res->agn_com_type == "OD")
                                      {
                                          if($agent_status->commission_category == "A")
                                          {
                                              $agent_commission = ($own_damage * $res->a_od)/100;
                                          }
                                          else if($agent_status->commission_category == "B")
                                          {
                                              $agent_commission = ($own_damage * $res->b_od)/100;
                                          }
                                          else if($agent_status->commission_category == "C")
                                          {
                                              $agent_commission = ($own_damage * $res->c_od)/100;
                                          }
                                          else if($agent_status->commission_category == "D")
                                          {
                                              $agent_commission = ($own_damage * $res->d_od)/100;
                                          }
                                      }
                                      else if($res->agn_com_type == "TP")
                                      {
                                          if($agent_status->commission_category == "A")
                                          {
                                              $agent_commission = ($tp * $res->a_tp)/100;
                                          }
                                          else if($agent_status->commission_category == "B")
                                          {
                                              $agent_commission = ($tp * $res->b_tp)/100;
                                          }
                                          else if($agent_status->commission_category == "C")
                                          {
                                              $agent_commission = ($tp * $res->c_tp)/100;
                                          }
                                          else if($agent_status->commission_category == "D")
                                          {
                                              $agent_commission = ($tp * $res->d_tp)/100;
                                          }
                                      }
                                      else if($res->agn_com_type == "ON-NET")
                                      {
                                          if($agent_status->commission_category == "A")
                                          {
                                              $agent_commission = ($total_premium * $res->a_net)/100;
                                          }
                                          else if($agent_status->commission_category == "B")
                                          {
                                              $agent_commission = ($total_premium * $res->b_net)/100;
                                          }
                                          else if($agent_status->commission_category == "C")
                                          {
                                              $agent_commission = ($total_premium * $res->c_net)/100;
                                          }
                                          else if($agent_status->commission_category == "D")
                                          {
                                              $agent_commission = ($total_premium * $res->d_net)/100;
                                          }
                                      }
                                      else if($res->agn_com_type == "OD_AND_TP")
                                      {
                                          if($agent_status->commission_category == "A")
                                          {
                                              $agent_od = ($own_damage * $res->a_od)/100;
                                              $agent_tp = ($tp * $res->a_tp)/100;
                                              $agent_commission = $agent_od+$agent_tp;
                                          }
                                          else if($agent_status->commission_category == "B")
                                          {
                                              $agent_od = ($own_damage * $res->b_od)/100;
                                              $agent_tp = ($tp * $res->a_tp)/100;
                                              $agent_commission = $agent_od+$agent_tp;
                                          }
                                          else if($agent_status->commission_category == "C")
                                          {
                                              $agent_od = ($own_damage * $res->c_od)/100;
                                              $agent_tp = ($tp * $res->a_tp)/100;
                                              $agent_commission = $agent_od+$agent_tp;
                                          }
                                          else if($agent_status->commission_category == "D")
                                          {
                                              $agent_od = ($own_damage * $res->d_od)/100;
                                              $agent_tp = ($tp * $res->a_tp)/100;
                                              $agent_commission = $agent_od+$agent_tp;
                                          }
                                     }
                                }
                        }
                    }
                    else
                    {
                        $res = $this->lm->fetch_policy_info($commission_id);
                        $commission_type = $res->commission_type;
                    
                        if($res != null && $res->commission_type == "3" || $res->commission_type == "1")
                        {
                                if($res->is_ncb == "Yes" && $no_claim_bonus == "Yes")
                                {
                                          $company_com = $total_premium * ($res->ncb_percentage)/100;
                                          $agent_status = $this->lm->fetch_agent_category($policy_agency_pos);
                                     
                                          if($agent_status->commission_category == "A")
                                          {
                                              $agent_commission = ($total_premium * $res->a_ncb)/100;
                                          }
                                          else if($agent_status->commission_category == "B")
                                          {
                                                $agent_commission = ($total_premium * $res->b_ncb)/100;
                                          }
                                          else if($agent_status->commission_category == "C")
                                          {
                                                $agent_commission = ($total_premium * $res->c_ncb)/100;
                                          }
                                          else if($agent_status->commission_category == "D")
                                          {
                                                $agent_commission = ($total_premium * $res->d_ncb)/100;
                                          }
                                }
                                else 
                                {
                                    if($res->on_net != "0")
                                    {
                                        $own_od = "";
                                        $own_tp = "";
                                        $company_com = $total_premium * ($res->on_net)/100;
                                        $on_net = $company_com;
                                    }
                                    
                                     $agent_status = $this->lm->fetch_agent_category($policy_agency_pos);
                                     
                                          if($agent_status->commission_category == "A")
                                          {
                                              $agent_commission = ($total_premium * $res->a_net)/100;
                                          }
                                          else if($agent_status->commission_category == "B")
                                          {
                                              $agent_commission = ($total_premium * $res->b_net)/100;
                                          }
                                          else if($agent_status->commission_category == "C")
                                          {
                                              $agent_commission = ($total_premium * $res->c_net)/100;
                                          }
                                          else if($agent_status->commission_category == "D")
                                          {
                                              $agent_commission = ($total_premium * $res->d_net)/100;
                                          }
                                }
                        }
                    }
    
        	        $data = array(
                        "lead_id" =>$this->input->post("lead_id"),
                        "policy_client_ref_no"=> $this->input->post("policy_client_ref_no"),
                        "policy_cover_note_no"=> $this->input->post("policy_cover_note_no"),
                        "policy_no"=> $this->input->post("policy_no"),
                        "policy_s_date"=> $this->input->post("policy_s_date"),
                        "policy_ex_date"=> $this->input->post("policy_ex_date"),
                        "policy_premium"=> $this->input->post("policy_premium"),
                        "policy_terms"=> $this->input->post("policy_terms"),
                        "payment_frequency"=> $this->input->post("payment_frequency"),
                        "next_due_date"=> $this->input->post("next_due_date"),
                        "renewable_flag"=> $this->input->post("renewable_flag"),
                        "add_ons_opted"=> $this->input->post("add_ons_opted"),
                        "add_ons_not_opt" =>$this->input->post("add_ons_not_opt"),
                        "lead_type" =>"2",
                        "sum_insured"=> $this->input->post("sum_insured"),
                        "discount_percent"=> $this->input->post("discount_percent"),
                        "no_claim_bonus"=> $this->input->post("no_claim_bonus"),
                        "no_claim_bonus_val"=> $this->input->post("no_claim_bonus_val"),
                        "cpa"=> $this->input->post("cpa"),
                        "total_own_damage"=> $this->input->post("total_own_damage"),
                        "tot_add_on_premium"=> $this->input->post("tot_add_on_premium"),
                        "commisson_base_premium"=> $this->input->post("commisson_base_premium"),
                        "basic_tp"=> $this->input->post("basic_tp"),
                        "owner_driver_pa"=> $this->input->post("owner_driver_pa"),
                        "owner_diver_amt"=> $this->input->post("owner_diver_amt"),
                        "no_of_year_own_drv"=> $this->input->post("no_of_year_own_drv"),
                        "fuel_kit"=> $this->input->post("fuel_kit"),
                        "fuel_kit_amt"=> $this->input->post("fuel_kit_amt"),
                        "geograpical"=> $this->input->post("geograpical"),
                        "geograpical_amt"=> $this->input->post("geograpical_amt"),
                        "un_named_passenger_pa"=> $this->input->post("un_named_passenger_pa"),
                        "un_named_passenger_amt"=> $this->input->post("un_named_passenger_amt"),
                        "no_seats_per_person"=> $this->input->post("no_seats_per_person"),
                        "no_seats_per_person_amt"=> $this->input->post("no_seats_per_person_amt"),
                        "LL_paid "=> $this->input->post("llp"),
                        "LL_paid_amt"=> $this->input->post("llp_amt"),
                        "no_drv_emp"=> $this->input->post("no_drv_emp"),
                        "pa_paid_drv"=> $this->input->post("pa_paid_drv"),
                        "pa_paid_drv_amt"=> $this->input->post("pa_paid_drv_amt"),
                        "no_seats_per_person1"=> $this->input->post("no_seats_per_person1"),
                        "no_seats_per_person_amt1"=> $this->input->post("no_seats_per_person_amt1"),
                        "tot_liability_premium"=> $this->input->post("tot_liability_premium"),
                        "total_premium"=> $this->input->post("total_premium"),
                        "gst"=> $this->input->post("gst"),
                        "premium_gst"=> $this->input->post("premium_gst"),
                        "policy_issue_date"=> $this->input->post("policy_issue_date"),
                        "policy_agency_pos"=> $this->input->post("policy_agency_pos"),
                        "policy_source"=> $this->input->post("policy_source"),
                        "policy_user"=> $this->input->post("policy_user"),
                        "policy_location"=> $this->input->post("policy_location"),
                        "previous_policy_no"=> $this->input->post("previous_policy_no"),
                        "previous_insurer"=> $this->input->post("previous_insurer"),
                        "previous_insurance_plan"=> $this->input->post("previous_insurance_plan"),
                        "previous_agency_pos"=> $this->input->post("previous_agency_pos"),
                        "previous_source"=> $this->input->post("previous_source"),
                        "dectable_details"=> $this->input->post("dectable_details"),
                        "policy_additional_info"=> $this->input->post("policy_additional_info"),
                        "reference_no"=> $this->input->post("reference_no"),
                        "other_reference_no"=> $this->input->post("other_reference_no"),
                        "policy_received"=> $this->input->post("policy_received"),
                        "policy_verified"=> $this->input->post("policy_verified"),
                        "policy_verified_info"=> $this->input->post("policy_verified_info"),
                        "policy_cancelled"=> $this->input->post("policy_cancelled"),
                        "policy_cancelled_info"=> $this->input->post("policy_cancelled_info"),
                        "commisson_generation"=> $this->input->post("commisson_generation"),
                        "payment_type"=> $this->input->post("payment_type"),
                        "pay_ref_no"=> $this->input->post("pay_ref_no"),
                        "bank_name"=> $this->input->post("bank_name"),
                        "payment_check_date"=> $this->input->post("payment_check_date"),
                        "payment_and_check_no"=> $this->input->post("payment_and_check_no"),
                        "remarks"=> $this->input->post("remarks"),
                        //"payment_collected_date"=> $this->input->post("payment_collected_date"),
                        "add_ons_1" =>$add_ons_1,
                        "add_ons_2" =>$add_ons_2,
                        "add_ons_3" =>$add_ons_3,
                        "add_ons_4" =>$add_ons_4,
                        "add_ons_5" =>$add_ons_5,
                        "add_ons_1_details" =>$add_ons_1_details,
                        "add_ons_2_details" =>$add_ons_2_details,
                        "add_ons_3_details" =>$add_ons_3_details,
                        "add_ons_4_details" =>$add_ons_4_details,
                        "add_ons_5_details" =>$add_ons_5_details,
                        "commission_id" =>$commission_id,
                        "company"=> $this->input->post("company"),
                        "commission_type"=> $commission_type,
                        "agent_commission_amt"=> $agent_commission,
                        "own_commission_amt"=> $company_com,
                        //"remarks"=> $this->input->post("remarks"),
                        "created_by"=> $this->session->userdata('session_id'),
                        "created_at"=> date("Y-m-d H:i:s"),
                        "com_trigger_status" => "1",
                        "com_trigger_date" =>date("Y-m-d"),
                        "calc_com_status" =>"1",
                        );
                    if($class_type->class == "2")
                    {
                        
                            if(isset($_FILES))
                    		{
                    			$config['upload_path'] = './datas/Health_declaration/';
                    			$config['allowed_types'] = '*';
                    			
                    			$this->load->library('upload',$config);
                    			$this->upload->initialize($config);
                    			if(!$this->upload->do_upload('husband_file'))
                    			{
                    				$husband_file = "";
                    			}
                    			else
                    			{
                    				$husband_file = $this->upload->data('file_name');
                    			}
                    		} 
                    		
                    		if(isset($_FILES))
                    		{
                    			$config['upload_path'] = './datas/Health_declaration/';
                    			$config['allowed_types'] = '*';
                    			
                    			$this->load->library('upload',$config);
                    			$this->upload->initialize($config);
                    			if(!$this->upload->do_upload('wife_file'))
                    			{
                    				$wife_file = "";
                    			}
                    			else
                    			{
                    				$wife_file = $this->upload->data('file_name');
                    			}
                    		} 
                    		
                    		
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                if(!$this->upload->do_upload('father_file'))
                                {
                                        $father_file = "";
                                }
                                else
                                {
                                        $father_file = $this->upload->data('file_name');
                                }
                            } 
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('mother_file'))
                                {
                                    $mother_file = "";
                                }
                                else
                                {
                                    $mother_file = $this->upload->data('file_name');
                                }
                            } 
                            
                           
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('daug_1_file'))
                                {
                                    $daug_1_file = "";
                                }
                                else
                                {
                                    $daug_1_file = $this->upload->data('file_name');
                                }
                            }
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('daug_2_file'))
                                {
                                    $daug_2_file = "";
                                }
                                else
                                {
                                    $daug_2_file = $this->upload->data('file_name');
                                }
                            }
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('daug_3_file'))
                                {
                                    $daug_3_file = "";
                                }
                                else
                                {
                                    $daug_3_file = $this->upload->data('file_name');
                                }
                            }
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('son_1_file'))
                                {
                                    $son_1_file = "";
                                }
                                else
                                {
                                    $son_1_file = $this->upload->data('file_name');
                                }
                            }
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('son_2_file'))
                                {
                                    $son_2_file = "";
                                }
                                else
                                {
                                    $son_2_file = $this->upload->data('file_name');
                                }
                            }
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('son_3_file'))
                                {
                                    $son_3_file = "";
                                }
                                else
                                {
                                    $son_3_file = $this->upload->data('file_name');
                                }
                            }
                             $id = $this->input->post("lead_id");
                        
                       $health_details = array(
                            "disease_husband" => ($disease_husband == "undefined") ? ""  : $disease_husband,
                            "husband_file" => ($husband_file == "undefined") ? ""  : $husband_file,
                            "disease_wife" =>($disease_wife == "undefined") ? ""  : $disease_wife,
                            "wife_file" =>($wife_file == "undefined") ? ""  : $wife_file,
                            "disease_daug_1" =>($disease_daug_1 == "undefined") ? ""  : $disease_daug_1,
                            "disease_daug_2" =>($disease_daug_2 == "undefined") ? ""  : $disease_daug_2 ,
                            "disease_daug_3" =>($disease_daug_3 == "undefined") ? ""  : $disease_daug_3,
                            "daug_1_file" =>($daug_1_file == "undefined") ? ""  : $daug_1_file,
                            "daug_2_file" =>($daug_2_file == "undefined") ? ""  : $daug_2_file,
                            "daug_3_file" =>($daug_3_file == "undefined") ? ""  : $daug_3_file,
                            "disease_son_1" =>($disease_son_1 == "undefined") ? ""  : $disease_son_1,
                            "disease_son_2" =>($disease_son_2 == "undefined") ? ""  : $disease_son_2,
                            "disease_son_3" =>($disease_son_3 == "undefined") ? ""  : $disease_son_3,
                            "son_1_file" =>($son_1_file == "undefined") ? ""  : $son_1_file,
                            "son_2_file" =>($son_2_file == "undefined") ? ""  : $son_2_file,
                            "son_3_file" =>($son_3_file == "undefined") ? ""  : $son_3_file ,
                            "disease_father" =>($disease_father == "undefined") ? ""  : $disease_father,
                            "disease_mother" =>($disease_mother == "undefined") ? ""  : $disease_mother,
                            "father_file" =>($father_file == "undefined") ? ""  : $father_file,
                            "mother_file" =>($mother_file == "undefined") ? ""  : $mother_file,
                        );
                        
                        $res = $this->lm->update_health_policy_details($health_details,$id);
                    }
                    
                    if(!$this->lm->check_policy_this_no_already_exits($policy_no))
                    {
                        if(!$this->lm->check_lead_id_already_exits_in_policy($lead_id))
                        {
                            $res = $this->lm->save_generated_policy($data);
                            
                            if($res)
                            {
                                $id = $this->input->post("lead_id");
                                $arr = array("lead_type" =>"2","lead_status"=>"completed");
                                $data_1 = $this->lm->update_lead_type_status($arr,$id);
                                
                                $this->acc_own_commission($id);
                                $this->acc_agn_commission($id);
                                
                            }
                            $activity_log = array("lead_id"=>$id,"action"=>"New Policy Generated","action_type"=>"generate_policy","created_by"=>$this->session->userdata('session_name'),"time"=>date("Y-m-d H:i:s"));
                            $add_activity = $this->lm->add_activity_log($activity_log);
                            echo "success";
                        }
                        else
                        {
                             echo "Lead Id Already Exits";
                        }
                    }
                    else
                    {
                        echo "Policy No Already Exits";
                    }
           }
    }
    
     public function update_generated_policy()
        {
            if($this->session->has_userdata('logged_in'))
            {
                $policy_no = $this->input->post("policy_no");
                $policy_source = $this->input->post("policy_source");
                $lead_created_by = $this->session->userdata('session_name');
                $category = $this->session->userdata('category');
                $ncb = $this->input->post("ncb"); 
                $total_premium = $this->input->post("total_premium");
                $lead_id = $this->input->post("lead_id");
                $policy_premium= $this->input->post("policy_premium");
                $commission_id = $this->input->post("commission_id");
                $policy_agency_pos = $this->input->post("policy_agency_pos");
                $company = $this->input->post("company");
                
                $class_type = $this->lm->get_class_type($lead_id);
                
                 
                $add_ons_1  = $this->input->post("add_ons_1");
                $add_ons_2  = $this->input->post("add_ons_2");
                $add_ons_3  = $this->input->post("add_ons_3");
                $add_ons_4  = $this->input->post("add_ons_4");
                $add_ons_5  = $this->input->post("add_ons_5");
                $add_ons_1_details  = $this->input->post("add_ons_1_details");
                $add_ons_2_details  = $this->input->post("add_ons_2_details");
                $add_ons_3_details  = $this->input->post("add_ons_3_details");
                $add_ons_4_details  = $this->input->post("add_ons_4_details");
                $add_ons_5_details  = $this->input->post("add_ons_5_details");
                $own_damage = $this->input->post("total_own_damage");
                $tp = $this->input->post("tot_liability_premium");
                    
                    
        	      $data = array(
        	        "company" => $company,
        	        "policy_client_ref_no"=> $this->input->post("policy_client_ref_no"),
                    "policy_cover_note_no"=> $this->input->post("policy_cover_note_no"),
                    "policy_no"=> $this->input->post("policy_no"),
                    "policy_s_date"=> $this->input->post("policy_s_date"),
                    "policy_ex_date"=> $this->input->post("policy_ex_date"),
                    "policy_premium"=> $this->input->post("policy_premium"),
                    "policy_terms"=> $this->input->post("policy_terms"),
                    "payment_frequency"=> $this->input->post("payment_frequency"),
                    "next_due_date"=> $this->input->post("next_due_date"),
                    "renewable_flag"=> $this->input->post("renewable_flag"),
                    "add_ons_opted"=> $this->input->post("add_ons_opted"),
                    "add_ons_not_opt" =>$this->input->post("add_ons_not_opt"),
                    "lead_type" =>"2",
                    "sum_insured"=> $this->input->post("sum_insured"),
                    "discount_percent"=> $this->input->post("discount_percent"),
                    "no_claim_bonus"=> $this->input->post("no_claim_bonus"),
                    "no_claim_bonus_val"=> $this->input->post("no_claim_bonus_val"),
                    "total_own_damage"=> $this->input->post("total_own_damage"),
                    "tot_add_on_premium"=> $this->input->post("tot_add_on_premium"),
                    "commisson_base_premium"=> $this->input->post("commisson_base_premium"),
                    "basic_tp"=> $this->input->post("basic_tp"),
                    "owner_driver_pa"=> $this->input->post("owner_driver_pa"),
                    "owner_diver_amt"=> $this->input->post("owner_diver_amt"),
                    "no_of_year_own_drv"=> $this->input->post("no_of_year_own_drv"),
                    "fuel_kit"=> $this->input->post("fuel_kit"),
                    "fuel_kit_amt"=> $this->input->post("fuel_kit_amt"),
                    "geograpical"=> $this->input->post("geograpical"),
                    "geograpical_amt"=> $this->input->post("geograpical_amt"),
                    "un_named_passenger_pa"=> $this->input->post("un_named_passenger_pa"),
                    "un_named_passenger_amt"=> $this->input->post("un_named_passenger_amt"),
                    "no_seats_per_person"=> $this->input->post("no_seats_per_person"),
                    "no_seats_per_person_amt"=> $this->input->post("no_seats_per_person_amt"),
                    "LL_paid "=> $this->input->post("llp"),
                    "LL_paid_amt"=> $this->input->post("llp_amt"),
                    "no_drv_emp"=> $this->input->post("no_drv_emp"),
                    "pa_paid_drv"=> $this->input->post("pa_paid_drv"),
                    "pa_paid_drv_amt"=> $this->input->post("pa_paid_drv_amt"),
                    "no_seats_per_person1"=> $this->input->post("no_seats_per_person1"),
                    "no_seats_per_person_amt1"=> $this->input->post("no_seats_per_person_amt1"),
                    "tot_liability_premium"=> $this->input->post("tot_liability_premium"),
                    "total_premium"=> $this->input->post("total_premium"),
                    "gst"=> $this->input->post("gst"),
                    "premium_gst"=> $this->input->post("premium_gst"),
                    "policy_issue_date"=> $this->input->post("policy_issue_date"),
                    "policy_agency_pos"=> $this->input->post("policy_agency_pos"),
                    "policy_source"=> $this->input->post("policy_source"),
                    "policy_user"=> $this->input->post("policy_user"),
                    "policy_location"=> $this->input->post("policy_location"),
                    "previous_policy_no"=> $this->input->post("previous_policy_no"),
                    "previous_insurer"=> $this->input->post("previous_insurer"),
                    "previous_insurance_plan"=> $this->input->post("previous_insurance_plan"),
                    "previous_agency_pos"=> $this->input->post("previous_agency_pos"),
                    "previous_source"=> $this->input->post("previous_source"),
                    "dectable_details"=> $this->input->post("dectable_details"),
                    "policy_additional_info"=> $this->input->post("policy_additional_info"),
                    "reference_no"=> $this->input->post("reference_no"),
                    "other_reference_no"=> $this->input->post("other_reference_no"),
                    "policy_received"=> $this->input->post("policy_received"),
                    "policy_verified"=> $this->input->post("policy_verified"),
                    "policy_verified_info"=> $this->input->post("policy_verified_info"),
                    "policy_cancelled"=> $this->input->post("policy_cancelled"),
                    "policy_cancelled_info"=> $this->input->post("policy_cancelled_info"),
                    "commisson_generation"=> $this->input->post("commisson_generation"),
                    "payment_type"=> $this->input->post("payment_type"),
                    "pay_ref_no"=> $this->input->post("pay_ref_no"),
                    "bank_name"=> $this->input->post("bank_name"),
                    "payment_check_date"=> $this->input->post("payment_check_date"),
                    "payment_and_check_no"=> $this->input->post("payment_and_check_no"),
                    "remarks"=> $this->input->post("remarks"),
                   "add_ons_1" =>$add_ons_1,
                   "add_ons_2" =>$add_ons_2,
                   "add_ons_3" =>$add_ons_3,
                   "add_ons_4" =>$add_ons_4,
                   "add_ons_5" =>$add_ons_5,
                   "add_ons_1_details" =>$add_ons_1_details,
                   "add_ons_2_details" =>$add_ons_2_details,
                   "add_ons_3_details" =>$add_ons_3_details,
                   "add_ons_4_details" =>$add_ons_4_details,
                   "add_ons_5_details" =>$add_ons_5_details,
                   "updated_by"=> $this->session->userdata('session_id'),
                   "updated_at"=> date("Y-m-d H:i:s"),
                    );
                    
                    if($class_type->class == "2")
                    {
                            if(isset($_FILES))
                    		{
                    			$config['upload_path'] = './datas/Health_declaration/';
                    			$config['allowed_types'] = '*';
                    			
                    			$this->load->library('upload',$config);
                    			$this->upload->initialize($config);
                    			if(!$this->upload->do_upload('husband_file'))
                    			{
                    				$husband_file = "";
                    			}
                    			else
                    			{
                    				$husband_file = $this->upload->data('file_name');
                    			}
                    		} 
                    		
                    		if(isset($_FILES))
                    		{
                    			$config['upload_path'] = './datas/Health_declaration/';
                    			$config['allowed_types'] = '*';
                    			
                    			$this->load->library('upload',$config);
                    			$this->upload->initialize($config);
                    			if(!$this->upload->do_upload('wife_file'))
                    			{
                    				$wife_file = "";
                    			}
                    			else
                    			{
                    				$wife_file = $this->upload->data('file_name');
                    			}
                    		} 
                    		
                    		
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                if(!$this->upload->do_upload('father_file'))
                                {
                                        $father_file = "";
                                }
                                else
                                {
                                        $father_file = $this->upload->data('file_name');
                                }
                            } 
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('mother_file'))
                                {
                                    $mother_file = "";
                                }
                                else
                                {
                                    $mother_file = $this->upload->data('file_name');
                                }
                            } 
                            
                           
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('daug_1_file'))
                                {
                                    $daug_1_file = "";
                                }
                                else
                                {
                                    $daug_1_file = $this->upload->data('file_name');
                                }
                            }
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('daug_2_file'))
                                {
                                    $daug_2_file = "";
                                }
                                else
                                {
                                    $daug_2_file = $this->upload->data('file_name');
                                }
                            }
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('daug_3_file'))
                                {
                                    $daug_3_file = "";
                                }
                                else
                                {
                                    $daug_3_file = $this->upload->data('file_name');
                                }
                            }
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('son_1_file'))
                                {
                                    $son_1_file = "";
                                }
                                else
                                {
                                    $son_1_file = $this->upload->data('file_name');
                                }
                            }
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('son_2_file'))
                                {
                                    $son_2_file = "";
                                }
                                else
                                {
                                    $son_2_file = $this->upload->data('file_name');
                                }
                            }
                            
                            if(isset($_FILES))
                            {
                                $config['upload_path'] = './datas/Health_declaration/';
                                $config['allowed_types'] = '*';
                                
                                $this->load->library('upload',$config);
                                $this->upload->initialize($config);
                                
                                if(!$this->upload->do_upload('son_3_file'))
                                {
                                    $son_3_file = "";
                                }
                                else
                                {
                                    $son_3_file = $this->upload->data('file_name');
                                }
                            }
                            
                            $id = $this->input->post("lead_id");
                            
                            $health_details = array(
                            "disease_husband" => ($disease_husband == "undefined") ? ""  : $disease_husband,
                            "husband_file" => ($husband_file == "undefined") ? ""  : $husband_file,
                            "disease_wife" =>($disease_wife == "undefined") ? ""  : $disease_wife,
                            "wife_file" =>($wife_file == "undefined") ? ""  : $wife_file,
                            "disease_daug_1" =>($disease_daug_1 == "undefined") ? ""  : $disease_daug_1,
                            "disease_daug_2" =>($disease_daug_2 == "undefined") ? ""  : $disease_daug_2 ,
                            "disease_daug_3" =>($disease_daug_3 == "undefined") ? ""  : $disease_daug_3,
                            "daug_1_file" =>($daug_1_file == "undefined") ? ""  : $daug_1_file,
                            "daug_2_file" =>($daug_2_file == "undefined") ? ""  : $daug_2_file,
                            "daug_3_file" =>($daug_3_file == "undefined") ? ""  : $daug_3_file,
                            "disease_son_1" =>($disease_son_1 == "undefined") ? ""  : $disease_son_1,
                            "disease_son_2" =>($disease_son_2 == "undefined") ? ""  : $disease_son_2,
                            "disease_son_3" =>($disease_son_3 == "undefined") ? ""  : $disease_son_3,
                            "son_1_file" =>($son_1_file == "undefined") ? ""  : $son_1_file,
                            "son_2_file" =>($son_2_file == "undefined") ? ""  : $son_2_file,
                            "son_3_file" =>($son_3_file == "undefined") ? ""  : $son_3_file ,
                            "disease_father" =>($disease_father == "undefined") ? ""  : $disease_father,
                            "disease_mother" =>($disease_mother == "undefined") ? ""  : $disease_mother,
                            "father_file" =>($father_file == "undefined") ? ""  : $father_file,
                            "mother_file" =>($mother_file == "undefined") ? ""  : $mother_file,
                            );
                            $res = $this->lm->update_health_policy_details($health_details,$id);
                    }
               
                    $res = $this->lm->update_generated_policy($data,$lead_id);
                    
                     $activity_log = array("lead_id"=>$lead_id,"action"=>"Policy Updated","action_type"=>"Policy Updated","created_by"=>$this->session->userdata('session_name'),"time"=>date("Y-m-d H:i:s"));
                     $add_activity = $this->lm->add_activity_log($activity_log);
                     echo "success";
        }
    }
    
    public function add_health_details()
    {
      if($this->session->has_userdata('logged_in'))
       {
        $created_id=$this->input->post("created_id");
         $lead_id=$this->input->post("lead_id");
         $h_gender=$this->input->post("h_gender");
          $Husband=$this->input->post("Husband");
          $Wife=$this->input->post("Wife");
          $Son=$this->input->post("Son");
          $Daughter=$this->input->post("Daughter");
          $Father=$this->input->post("Father");
          $Mother=$this->input->post("Mother");
          $Husband_age=$this->input->post("Husband_age");
          $Wife_age=$this->input->post("Wife_age");
          $num_daughters=$this->input->post("num_daughters");
          $num_sons=$this->input->post("num_sons");
           $son_1_age=$this->input->post("son_1_age");
           $son_2_age=$this->input->post("son_2_age");
           $son_3_age=$this->input->post("son_3_age");
           $son_4_age=$this->input->post("son_4_age");
           $daughter_1_age=$this->input->post("daughter_1_age");
           $daughter_2_age=$this->input->post("daughter_2_age");
           $daughter_3_age=$this->input->post("daughter_3_age");
           $daughter_4_age=$this->input->post("daughter_4_age");
          $father_age=$this->input->post("father_age");
          $mother_age=$this->input->post("mother_age");
          $date = date("Y-m-d"); 
          
           $son_name_1=$this->input->post("son_name_1");
           $son_name_2=$this->input->post("son_name_2");
           $son_name_3=$this->input->post("son_name_3");
           $son_name_4=$this->input->post("son_name_4");
           
           $son_dob_1=$this->input->post("son_dob_1");
           $son_dob_2=$this->input->post("son_dob_2");
           $son_dob_3=$this->input->post("son_dob_3");
           $son_dob_4=$this->input->post("son_dob_4");
           
           
           $daughter_name_1=$this->input->post("daughter_name_1");
           $daughter_name_2=$this->input->post("daughter_name_2");
           $daughter_name_3=$this->input->post("daughter_name_3");
           $daughter_name_4=$this->input->post("daughter_name_4");
           
           $daughter_dob_1=$this->input->post("daughter_dob_1");
           $daughter_dob_2=$this->input->post("daughter_dob_2");
           $daughter_dob_3=$this->input->post("daughter_dob_3");
           $daughter_dob_4=$this->input->post("daughter_dob_4");
           
           
           $Husband_name = $this->input->post("Husband_name");
           $Husband_dob = $this->input->post("Husband_dob");
           $Wife_name = $this->input->post("Wife_name");
           $Wife_dob = $this->input->post("Wife_dob");
           
           $father_name = $this->input->post("father_name");
           $father_dob = $this->input->post("father_dob");
           $mother_name = $this->input->post("mother_name");
           $dob_mother = $this->input->post("dob_mother");
           
          
        
            
            $data = array(
                "husband"=>$Husband,
                "wife"=>$Wife,"father"=>$Father,
                "mother"=>$Mother,"son"=>$Son,
                "duaghter"=>$Daughter,
                "father_age" =>$father_age,
                "mother_age"=>$mother_age,
                "husband_age"=>$Husband_age,
                "wife_age"=>$Wife_age,
                "son_count"=>$num_sons,
                "duaghter_count"=>$num_daughters,
                "son1_age"=>$son_1_age,
                "son2_age"=>$son_2_age,
                "son3_age"=>$son_3_age,
                "son4_age"=>$son_4_age,
                "daughter1_age"=>$daughter_1_age,
                "daughter2_age"=>$daughter_2_age,
                "daughter3_age"=>$daughter_3_age,
                "daughter4_age"=>$daughter_4_age,
                "gender"=>$h_gender,
                "daughter_name_1" => $daughter_name_1,
               "daughter_name_2" => $daughter_name_2,
               "daughter_name_3" => $daughter_name_3,
               "daughter_name_4" => $daughter_name_4,
               "daughter_dob_1" => $daughter_dob_1,
               "daughter_dob_2" => $daughter_dob_2,
               "daughter_dob_3" => $daughter_dob_3,
               "daughter_dob_4" => $daughter_dob_4,
                "son_name_1" =>$son_name_1,
                "son_name_2" =>$son_name_2,
                "son_name_3" =>$son_name_3,
                "son_name_4" =>$son_name_4,
                "son_dob_1" =>$son_dob_1,
                "son_dob_2" =>$son_dob_2,
                "son_dob_3" =>$son_dob_3,
                "son_dob_4" =>$son_dob_4,
                "father_name" =>$father_name,
                "father_dob" =>$father_dob,
                "mother_name" =>$mother_name,
                "mother_dob" =>$dob_mother,
                "husband_name" =>$Husband_name,
                "husband_dob" =>$Husband_dob,
                "wife_name" =>$Wife_name,
                "wife_dob" =>$Wife_dob,
                "lead_id"=>$lead_id,
                "created_at"=>$date,
                "created_by"=>$created_id
                );
            
            $res = $this->lm->add_health_details($data);
            }
    }
    
    public function get_receiver_email_id()
    {
        if($this->session->has_userdata('logged_in'))
        {
            $lead_id = $this->input->post("id");
            $res = $this->lm->get_receiver_email_id($lead_id);
            $data = $this->lm->get_receiver_email_by_id($res->client_id);
            echo json_encode($data);
        }
    }
    
    public function fetch_email_content()
    {
        if($this->session->has_userdata('logged_in'))
        {
            $template_id = $this->input->post("template_id");
            $lead_id = $this->input->post("lead_id");
            
            $res = $this->lm->fetch_email_content($template_id);
            $data = $this->lm->get_policy_details($lead_id);
            
            $arr = array("res"=>$res,"data"=>$data);
            echo json_encode($arr);
        }
    }
    
    public function get_uploaded_documents()
    {
        if($this->session->has_userdata('logged_in'))
        {
            $lead_id = $this->input->post("lead_id");
            
            $res = $this->lm->get_vechile_documents($lead_id);
            
            $data = $this->lm->get_policy_documents($lead_id);
            
            $html ="";
            
            foreach($res as $da)
            {
                 $html .="<tr>
                      <td><input type='checkbox' name='document_file' class='form-check-input check_file' value='".$da->document_file."'></td>
                      <td>".$da->document_type."</td>
                      <td>".$da->document_file."</td>
                     </tr>";
            }
            
            foreach($data as $da)
            {
                $html .="<tr>
                      <td><input type='checkbox' name='document_file' class='form-check-input check_file'  value='".$da->document."'></td>
                      <td>".$da->document_type."</td>
                      <td>".$da->document."</td>
                     </tr>";
            }
            
            echo $html;
        }
    }
    
    public function send_mail()
    {
        if($this->session->has_userdata('logged_in'))
        {
          $lead_id = $this->input->post("lead_id");
          $sender_email_id=$this->input->post("sender_email_id");
          $sender_name=$this->input->post("sender_name");
          $receiver_email_id=$this->input->post("receiver_email_id");
          $email_subject="Policy Document"; //$this->input->post("subject");
          $email_message = $this->input->post("content");
          $arr=$this->input->post("arr");
          
            $this->load->library('email');
        
        	$this->email->from("$sender_email_id", "$sender_name");
        	$this->email->to("$receiver_email_id");
        	
        	for($i=0;$i<count($arr);$i++)
        	{
        	    $this->email->attach('./datas/documents/'.$arr[$i]);
        	}
        	$this->email->set_mailtype("html");
        	$this->email->subject("$email_subject");
        	$this->email->message("$email_message");
        	$this->email->send();
        	
    		$activity_log = array("lead_id"=>$lead_id,"action"=>"Send Policy Email","action_type"=>"policy_email","created_by"=>$this->session->userdata('session_name'),"time"=>date("Y-m-d h:i:sa"));
            $add_activity = $this->lm->add_activity_log($activity_log);
        }
    }
    
    public function fetch_followup_log()
    {
        if($this->session->has_userdata('logged_in'))
        {
            $id = $this->input->post("id");
            $res = $this->lm->fetch_all_followups($id);
            
            $html = "";
            
            foreach($res as $da)
            {
                $html .="<tr>
                             <td>".date_format(date_create($da->next_follow_up_date),"d-m-Y")."</td>
                             <td>".date_format(date_create($da->next_follow_up_time),"h:i:sa")."</td>
                             <td>".$da->reason."</td>
                             <td>".$da->comment."</td>
                       </tr>";
            }
            
            echo $html;
        }
    }
    
   
    // Manual Generate policy //
  
  public function manual_generate_policy()
  {
        if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
    	{    		
		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
		   	$data["users"] = $this->lm->fetch_users();
		   	$data["client_type"] = $this->lm->fetch_client_type();
		   	$data["fuel_type"] = $this->lm->fetch_fuel_type();
		   	$data["business"] = $this->lm->fetch_business_type();
		   	$data["class"] = $this->lm->fetch_list_of_policy_type();
		   	$data["agents_pos"] = $this->lm->fetch_agents_pos();
		   	$data["policy_type"] = $this->lm->fetch_list_of_policy_type_motor();
		   	$data["email_templates"] = $this->lm->fetch_email_templates();
		   	$data["company"] = $this->lm->fetch_company();
		   	$data["state"] = $this->lm->fetch_state();
		   	$data["premium_cover_type"] = $this->lm->fetch_premium_cover_type();
	   		$data["rto"] = $this->lm->fetch_rto();
    		$this->load->view('header',$pro_data);
    		$this->load->view('manual_generate_policy',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else if($this->session->has_userdata('logged_in') && ($this->session->userdata('session_role') == "user" || $this->session->userdata('session_role') == "AI"))
	    {
	         $check_user_i = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));
	         
	        if($check_user_i->policy_view == "1")
	        {
    	        $pro_data["project_info"] = $this->mm->fetch_project_info();
    	        $data["users"] = $this->lm->fetch_users();
    	        $data["client_type"] = $this->lm->fetch_client_type();
    	        $data["business"] = $this->lm->fetch_business_type();
    	        $data["class"] = $this->lm->fetch_list_of_policy_type();
    	        $data["agents_pos"] = $this->lm->fetch_agents_pos();
    		   	$data["policy_type"] = $this->lm->fetch_list_of_policy_type_motor();
    		   	$data["email_templates"] = $this->lm->fetch_email_templates();
    		   	$data["company"] = $this->lm->fetch_company();
    		   	$data["state"] = $this->lm->fetch_state();
    		   	$data["fuel_type"] = $this->lm->fetch_fuel_type();
    		   	$data["premium_cover_type"] = $this->lm->fetch_premium_cover_type();
    		   	$data["rto"] = $this->lm->fetch_rto();
        		$this->load->view('header',$pro_data);
        		$this->load->view('manual_generate_policy',$data);
        		$this->load->view('footer',$pro_data);
	        }
	        else
	        {
	            echo "<script>alert('Permission Denied');window.location.href='home';</script>";
	        }
	    }
	    else
	    {
	    	redirect("login");
	    }
    }
    
    public function manual_upload_policy_document_files()
      {
          if($this->session->has_userdata('logged_in'))
          {
    	      $check_user_i = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));
    	         
    	        if($check_user_i->policy_add == "1")
    	        {
                	   $id = $this->input->post("id");
                	   $document_type = $this->input->post("document_type");
                	   
                	    if(isset($_FILES))
                		{
                			$config['upload_path'] = './datas/documents/';
                			$config['allowed_types'] = '*';
                			
                			$this->load->library('upload',$config);
                			$this->upload->initialize($config);
                			if(!$this->upload->do_upload('file'))
                			{
                				$file = '';
                				$file_path = "";
                			}
                			else
                			{
                				$file_path = base_url().'datas/documents/'.$this->upload->data('file_name');
                				$file = $this->upload->data('file_name');
                			}
                		}
                		
                		
                		
                		if($id == "")
                		{
                		    $data1 = array("lead_status" => "cancelled");
                		    $id = $this->lm->add_lead_details($data1);
                		}
                		$data = array("lead_id" =>$id,"document_type"=>$document_type,"document" =>$file);
                		
                		$res = $this->lm->upload_policy_document_files($data);
                		
                		$html = "";
                // 		$html .="<tr>
                // 		           <td><a href='./datas/documents/".$res->document."'><i class='fa fa-file'></i></a></td>
                // 		           <td>".$res->document."</td>
                // 		           <td>".$res->document_type."</td>
                // 		           <td><i class='fa fa-edit' onclick=edit_data(".$res->id.")></i></td>
                // 		           <td><i class='fa fa-trash' onclick=delete_data(".$res->id.")></i></td>
                // 		         </tr>";
                $html .="<tr>
                		           <td><a href='./datas/documents/".$res->document."'><i class='fa fa-file'></i></a></td>
                		           <td>".$res->document."</td>
                		           <td>".$res->document_type."</td>
                		         </tr>";
                		 echo json_encode(array("html" => $html,"id" => $id));
            	    }
        	    else
        	    {
        	        echo "<script>alert('Permission Denied');window.location.href='home';</script>";
        	    }
       }
     }
    
      public function save_manual_generated_policy()
        {
             if($this->session->has_userdata('logged_in'))
            {
                
              $check_user_i = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));
    	        if($check_user_i->policy_add == "1")
    	        {   
                   $policy_no = $this->input->post("policy_no");
                   $client_type = $this->input->post("client_type");
                   $client_name = $this->input->post("client_name");
                   $mobile_no = $this->input->post("mobile_no");
                   $pin = $this->input->post("pin_code");
                   $policy_source = $this->input->post("policy_source");
                   $bussiness_type = $this->input->post("bussiness_type");
                   $policy_class = $this->input->post("policy_class");
                   $policy_type = $this->input->post("policy_type");
                   $policy_agency_pos = $this->input->post("policy_agency_pos");
                   $lead_created_by = $this->session->userdata('session_name');
                   
                   $state = $this->input->post("state");
                   $company = $this->input->post("company");
                   $rto = $this->input->post("rto");
                   $commission_type = $this->input->post("commission_type");
                   $age = $this->input->post("age");
                   $category = $this->session->userdata('category');
                   $vehicle_classification = $this->input->post("vehicle_classification");
                   $lead_id = $this->input->post("lead_id");
                   $nominee_name = $this->input->post("nominee_name");
                   $adharcard_no = $this->input->post("adharcard_no");
                   $n_mobile_no = $this->input->post("n_mobile_no");
                   $n_adhar_card_upload = $this->input->post("n_adhar_card_upload");
                   
                   $make = $this->input->post("vechi_make");
                   $model = $this->input->post("vechi_model");
                   $Varient = $this->input->post("vechi_varient");
                   $cc  = $this->input->post("vechi_cc");
                   $v_gvw = $this->input->post("v_gvw");
                   $register_no = $this->input->post("vechi_register_no");
                   $year_of_manu = $this->input->post("vechi_manu_year");
                   $engine_num = $this->input->post("vechi_engine_num");
                   $commission_id = $this->input->post("commission_id");
                   $fuel_type = $this->input->post("fuel_type");
                   $ncb = $this->input->post("ncb"); 
                   $total_premium = $this->input->post("total_premium");
                   
              
                   
                   $agent_commission = 0;
                   $company_com = 0;
                   
                   if($commission_id != "")
                   {
                       if($policy_class == 1)
                        {
                            $res = $this->lm->fetch_policy_info($commission_id);
                            
                            if($res != null && $res->commission_type == "2")
                            {
                                if($res->commission_type == "2" && $res->type == "Excluding")
                                {
                                    if($res->is_ncb == "Yes" && $this->input->post("no_claim_bonus") == "Yes")
                                    {
                                        $company_com = $total_premium * ($res->ncb_percentage)/100;
                                        
                                         $agent_status = $this->lm->fetch_agent_category($policy_agency_pos);
                                         
                                               if($agent_status->commission_category == "A")
                                               {
                                                   $agent_commission = ($company_com * $res->a_ncb)/100;
                                               }
                                               else if($agent_status->commission_category == "B")
                                               {
                                                    $agent_commission = ($company_com * $res->a_ncb)/100;
                                               }
                                               else if($agent_status->commission_category == "C")
                                               {
                                                    $agent_commission = ($company_com * $res->a_ncb)/100;
                                               }
                                               else if($agent_status->commission_category == "D")
                                               {
                                                    $agent_commission = ($company_com * $res->a_ncb)/100;
                                               }
                                    }
                                    else if($res->is_ncb == "Yes" && $this->input->post("no_claim_bonus") == "No" || $this->input->post("no_claim_bonus") == "")
                                    {
                                        $irda_od = $total_premium * ($res->irda_od)/100;
                                        $irda_tp = $total_premium * ($res->irda_tp)/100;
                                        $company_com = $irda_od + $irda_tp;
                                        $agent_status = $this->lm->fetch_agent_category($policy_agency_pos);
                                        
                                       if($res->agn_com_type == "OD")
                                       {
                                           if($agent_status->commission_category == "A")
                                           {
                                               $agent_commission = ($irda_od * $res->a_od)/100;
                                           }
                                           else if($agent_status->commission_category == "B")
                                           {
                                               $agent_commission = ($irda_od * $res->b_od)/100;
                                           }
                                           else if($agent_status->commission_category == "C")
                                           {
                                               $agent_commission = ($irda_od * $res->c_od)/100;
                                           }
                                           else if($agent_status->commission_category == "D")
                                           {
                                               $agent_commission = ($irda_od * $res->d_od)/100;
                                           }
                                       }
                                       else if($res->agn_com_type == "TP")
                                       {
                                           if($agent_status->commission_category == "A")
                                           {
                                               $agent_commission = ($irda_tp * $res->a_tp)/100;
                                           }
                                           else if($agent_status->commission_category == "B")
                                           {
                                               $agent_commission = ($irda_tp * $res->b_tp)/100;
                                           }
                                           else if($agent_status->commission_category == "C")
                                           {
                                               $agent_commission = ($irda_tp * $res->c_tp)/100;
                                           }
                                           else if($agent_status->commission_category == "D")
                                           {
                                               $agent_commission = ($irda_tp * $res->d_tp)/100;
                                           }
                                       }
                              }
                              
                                      if($res->on_net != "0")
                                        {
                                            $own_od = "";
                                            $own_tp = "";
                                            $company_com = $total_premium * ($res->on_net)/100;
                                            $on_net = $company_com;
                                        }
                                        else if($res->own_od != "" && $res->own_tp != "")
                                        {
                                            $own_od = $total_premium * ($res->own_od)/100;
                                            $own_tp = $total_premium * ($res->own_tp)/100;
                                            $company_com = $own_od+$own_tp;
                                            $on_net = "";
                                        }
                                        else if($res->own_od != "")
                                        {
                                            $on_net = ""; 
                                            $own_tp = "";
                                            $company_com = $total_premium * ($res->own_od)/100;
                                            $own_od = $company_com;
                                        }
                                        else if($res->own_tp != "")
                                        {
                                            $own_od = ""; 
                                            $on_net = "";
                                            $company_com = $total_premium * ($res->own_tp)/100;
                                            $own_tp = $company_com;
                                        }
                         }
                                else if($res->commission_type == "2" && $res->type == "including")
                                {
                                        if($res->on_net != "")
                                        {
                                            $own_od = "";
                                            $own_tp = "";
                                            $company_com = $total_premium * ($res->on_net)/100;
                                            $on_net = $company_com;
                                        }
                                        else if($res->own_od != "" && $res->own_tp != "")
                                        {
                                            $own_od = $total_premium * ($res->own_od)/100;
                                            $own_tp = $total_premium * ($res->own_tp)/100;
                                            $company_com = $own_od+$own_tp;
                                            $on_net = "";
                                        }
                                        else if($res->own_od != "")
                                        {
                                            $on_net = ""; 
                                            $own_tp = "";
                                            $company_com = $total_premium * ($res->own_od)/100;
                                            $own_od = $company_com;
                                        }
                                        else if($res->own_tp != "")
                                        {
                                            $own_od = ""; 
                                            $on_net = "";
                                            $company_com = $total_premium * ($res->own_tp)/100;
                                            $own_tp = $company_com;
                                        }
                                }       
                                        $agent_status = $this->lm->fetch_agent_category($policy_agency_pos);
                                   
                                   if($res->agn_com_type == "OD")
                                   {
                                       if($agent_status->commission_category == "A")
                                       {
                                           $agent_commission = ($own_od * $res->a_od)/100;
                                       }
                                       else if($agent_status->commission_category == "B")
                                       {
                                           $agent_commission = ($own_od * $res->b_od)/100;
                                       }
                                       else if($agent_status->commission_category == "C")
                                       {
                                           $agent_commission = ($own_od * $res->c_od)/100;
                                       }
                                       else if($agent_status->commission_category == "D")
                                       {
                                           $agent_commission = ($own_od * $res->d_od)/100;
                                       }
                                   }
                                   else if($res->agn_com_type == "TP")
                                   {
                                       if($agent_status->commission_category == "A")
                                       {
                                           $agent_commission = ($own_tp * $res->a_tp)/100;
                                       }
                                       else if($agent_status->commission_category == "B")
                                       {
                                           $agent_commission = ($own_tp * $res->b_tp)/100;
                                       }
                                       else if($agent_status->commission_category == "C")
                                       {
                                           $agent_commission = ($own_tp * $res->c_tp)/100;
                                       }
                                       else if($agent_status->commission_category == "D")
                                       {
                                           $agent_commission = ($own_tp * $res->d_tp)/100;
                                       }
                                   }
                                       
                                   else if($res->agn_com_type == "ON-NET")
                                   {
                                       if($agent_status->commission_category == "A")
                                       {
                                           $agent_commission = ($on_net * $res->a_net)/100;
                                       }
                                       else if($agent_status->commission_category == "B")
                                       {
                                           $agent_commission = ($on_net * $res->b_net)/100;
                                       }
                                       else if($agent_status->commission_category == "C")
                                       {
                                           $agent_commission = ($on_net * $res->c_net)/100;
                                       }
                                       else if($agent_status->commission_category == "D")
                                       {
                                           $agent_commission = ($on_net * $res->d_net)/100;
                                       }
                                   }
                                       
                                   else if($res->agn_com_type == "OD_AND_TP")
                                   {
                                       if($agent_status->commission_category == "A")
                                       {
                                           $agent_od = ($own_od * $res->a_od)/100;
                                           $agent_tp = ($own_tp * $res->a_tp)/100;
                                           $agent_commission = $agent_od+$agent_tp;
                                       }
                                       else if($agent_status->commission_category == "B")
                                       {
                                           $agent_od = ($own_od * $res->b_od)/100;
                                           $agent_tp = ($own_tp * $res->a_tp)/100;
                                           $agent_commission = $agent_od+$agent_tp;
                                       }
                                       else if($agent_status->commission_category == "C")
                                       {
                                           $agent_od = ($own_od * $res->c_od)/100;
                                           $agent_tp = ($own_tp * $res->a_tp)/100;
                                           $agent_commission = $agent_od+$agent_tp;
                                       }
                                       else if($agent_status->commission_category == "D")
                                       {
                                           $agent_od = ($own_od * $res->d_od)/100;
                                           $agent_tp = ($own_tp * $res->a_tp)/100;
                                           $agent_commission = $agent_od+$agent_tp;
                                       }
                                 }
                              
                           }
                           else
                           {
                               $res = $this->lm->fetch_policy_info($commission_id);
                            
                            if($res != null)
                            {
                                if($res->commission_type == "1" && $res->type == "Excluding")
                                {
                                    if($res->is_ncb == "Yes" && $this->input->post("no_claim_bonus") == "Yes")
                                    {
                                        $company_com = $total_premium * ($res->ncb_percentage)/100;
                                        
                                         $agent_status = $this->lm->fetch_agent_category($policy_agency_pos);
                                         
                                               if($agent_status->commission_category == "A")
                                               {
                                                   $agent_commission = ($company_com * $res->a_ncb)/100;
                                               }
                                               else if($agent_status->commission_category == "B")
                                               {
                                                    $agent_commission = ($company_com * $res->a_ncb)/100;
                                               }
                                               else if($agent_status->commission_category == "C")
                                               {
                                                    $agent_commission = ($company_com * $res->a_ncb)/100;
                                               }
                                               else if($agent_status->commission_category == "D")
                                               {
                                                    $agent_commission = ($company_com * $res->a_ncb)/100;
                                               }
                                    }
                                    else if($res->is_ncb == "Yes" && $this->input->post("no_claim_bonus") == "No" || $this->input->post("no_claim_bonus") == "")
                                    {
                                        $irda_od = $total_premium * ($res->irda_od)/100;
                                        $irda_tp = $total_premium * ($res->irda_tp)/100;
                                        $company_com = $irda_od + $irda_tp;
                                        $agent_status = $this->lm->fetch_agent_category($policy_agency_pos);
                                        
                                       if($res->agn_com_type == "OD")
                                       {
                                           if($agent_status->commission_category == "A")
                                           {
                                               $agent_commission = ($irda_od * $res->a_od)/100;
                                           }
                                           else if($agent_status->commission_category == "B")
                                           {
                                               $agent_commission = ($irda_od * $res->b_od)/100;
                                           }
                                           else if($agent_status->commission_category == "C")
                                           {
                                               $agent_commission = ($irda_od * $res->c_od)/100;
                                           }
                                           else if($agent_status->commission_category == "D")
                                           {
                                               $agent_commission = ($irda_od * $res->d_od)/100;
                                           }
                                       }
                                       else if($res->agn_com_type == "TP")
                                       {
                                           if($agent_status->commission_category == "A")
                                           {
                                               $agent_commission = ($irda_tp * $res->a_tp)/100;
                                           }
                                           else if($agent_status->commission_category == "B")
                                           {
                                               $agent_commission = ($irda_tp * $res->b_tp)/100;
                                           }
                                           else if($agent_status->commission_category == "C")
                                           {
                                               $agent_commission = ($irda_tp * $res->c_tp)/100;
                                           }
                                           else if($agent_status->commission_category == "D")
                                           {
                                               $agent_commission = ($irda_tp * $res->d_tp)/100;
                                           }
                                       }
                              }
                         }
                        else if($res->commission_type == "1" && $res->type == "including")
                        {
                                if($res->on_net != "")
                                {
                                    $own_od = "";
                                    $own_tp = "";
                                    $company_com = $total_premium * ($res->on_net)/100;
                                    $on_net = $company_com;
                                }
                                else if($res->own_od != "" && $res->own_tp != "")
                                {
                                    $own_od = $total_premium * ($res->own_od)/100;
                                    $own_tp = $total_premium * ($res->own_tp)/100;
                                    $company_com = $own_od+$own_tp;
                                    $on_net = "";
                                }
                                else if($res->own_od != "")
                                {
                                    $on_net = ""; 
                                    $own_tp = "";
                                    $company_com = $total_premium * ($res->own_od)/100;
                                    $own_od = $company_com;
                                }
                                else if($res->own_tp != "")
                                {
                                    $own_od = ""; 
                                    $on_net = "";
                                    $company_com = $total_premium * ($res->own_tp)/100;
                                    $own_tp = $company_com;
                                }
                                
                                $agent_status = $this->lm->fetch_agent_category($policy_agency_pos);
                           
                           if($res->agn_com_type == "OD")
                           {
                               if($agent_status->commission_category == "A")
                               {
                                   $agent_commission = ($own_od * $res->a_od)/100;
                               }
                               else if($agent_status->commission_category == "B")
                               {
                                   $agent_commission = ($own_od * $res->b_od)/100;
                               }
                               else if($agent_status->commission_category == "C")
                               {
                                   $agent_commission = ($own_od * $res->c_od)/100;
                               }
                               else if($agent_status->commission_category == "D")
                               {
                                   $agent_commission = ($own_od * $res->d_od)/100;
                               }
                           }
                           else if($res->agn_com_type == "TP")
                           {
                               if($agent_status->commission_category == "A")
                               {
                                   $agent_commission = ($own_tp * $res->a_tp)/100;
                               }
                               else if($agent_status->commission_category == "B")
                               {
                                   $agent_commission = ($own_tp * $res->b_tp)/100;
                               }
                               else if($agent_status->commission_category == "C")
                               {
                                   $agent_commission = ($own_tp * $res->c_tp)/100;
                               }
                               else if($agent_status->commission_category == "D")
                               {
                                   $agent_commission = ($own_tp * $res->d_tp)/100;
                               }
                           }
                               
                           else if($res->agn_com_type == "ON-NET")
                           {
                               if($agent_status->commission_category == "A")
                               {
                                   $agent_commission = ($on_net * $res->a_net)/100;
                               }
                               else if($agent_status->commission_category == "B")
                               {
                                   $agent_commission = ($on_net * $res->b_net)/100;
                               }
                               else if($agent_status->commission_category == "C")
                               {
                                   $agent_commission = ($on_net * $res->c_net)/100;
                               }
                               else if($agent_status->commission_category == "D")
                               {
                                   $agent_commission = ($on_net * $res->d_net)/100;
                               }
                           }
                               
                           else if($res->agn_com_type == "OD_AND_TP")
                           {
                               if($agent_status->commission_category == "A")
                               {
                                   $agent_od = ($own_od * $res->a_od)/100;
                                   $agent_tp = ($own_tp * $res->a_tp)/100;
                                   $agent_commission = $agent_od+$agent_tp;
                               }
                               else if($agent_status->commission_category == "B")
                               {
                                   $agent_od = ($own_od * $res->b_od)/100;
                                   $agent_tp = ($own_tp * $res->a_tp)/100;
                                   $agent_commission = $agent_od+$agent_tp;
                               }
                               else if($agent_status->commission_category == "C")
                               {
                                   $agent_od = ($own_od * $res->c_od)/100;
                                   $agent_tp = ($own_tp * $res->a_tp)/100;
                                   $agent_commission = $agent_od+$agent_tp;
                               }
                               else if($agent_status->commission_category == "D")
                               {
                                   $agent_od = ($own_od * $res->d_od)/100;
                                   $agent_tp = ($own_tp * $res->a_tp)/100;
                                   $agent_commission = $agent_od+$agent_tp;
                               }
                         }
                      }
                   }
                   }
                }
                   }
                   
                    $data = array( 
    	             "client_type_id" =>$client_type,
    	             "client_name" =>$client_name,
    	             "mobile_no" =>$mobile_no,
    	             "pin_code" => $pin,
    	             );
    	             $res = $this->lm->add_client_details($data);
    	             if($res != "")
    	             {
        	             $arr = array( 
        	             "client_id" =>$res,
        	             "business_type" =>$bussiness_type,
        	             "class"=>$policy_class,
        	             "policy_type" => $policy_type,
        	             "lead_generated_date" => date("Y-m-d"),
        	             "source"=>$policy_source,
        	             "lead_status"=>"completed",
        	             "agency_and_pos" => $policy_agency_pos,
        	             "lead_created_by" =>$lead_created_by,
        	             "created_date"=>date("Y-m-d"),
        	             "updated_date"=>date("Y-m-d"));
        	             
        	             if($lead_id == "")
        	             {
        	                 $lead_id = $this->lm->add_lead_details($arr);
        	             }
        	             else
        	             {
        	                 $this->lm->update_follow_up_details($arr,$lead_id);
        	             }
        	             
    	             }
    	             
                     $activity_log = array("lead_id"=>$lead_id,"action"=>"Created <b>New Lead</b>","action_type"=>"new_lead_creation","created_by"=>$lead_created_by,"time"=>date("Y-m-d"));
                     
                     $add_activity = $this->lm->add_activity_log($activity_log);
                         

                    //  add vechicle details start             
                 
                     $vechi_info = array( 
                                          "lead_id" =>$lead_id,
                                          "vechile_type" =>"1",
                                          "policy_type" => $policy_type,
                                          "vechi_make" => $make,
                                          "vechi_model" => $model,
                                          "vechi_varient" => $Varient,
                                          "vechi_cc" => $cc,
                                          "vechi_gvw" =>$v_gvw,
                                          "vechi_register_no" => $register_no,
                                          "vechi_manu_year" => $year_of_manu,
                                          "vechi_engine_num" => $engine_num,
                                          "vechi_fuel_type"=>$fuel_type,
                                          "rto" =>$rto,
                                          "state" =>$state,
                                        );
                                           
                                $res = $this->lm->add_vechicle_detail($vechi_info);  
                                
                             //  add vechicle details start 
                                       
                 
            	  $data = array(
            	        "lead_id" =>$lead_id,
            	        "policy_client_ref_no"=> $this->input->post("policy_client_ref_no"),
                        "policy_cover_note_no"=> $this->input->post("policy_cover_note_no"),
                        "policy_no"=> $this->input->post("policy_no"),
                        "policy_s_date"=> $this->input->post("policy_s_date"),
                        "policy_ex_date"=> $this->input->post("policy_ex_date"),
                        "policy_premium"=> $this->input->post("policy_premium"),
                        "policy_terms"=> $this->input->post("policy_terms"),
                        "payment_frequency"=> $this->input->post("payment_frequency"),
                        "next_due_date"=> $this->input->post("next_due_date"),
                        "renewable_flag"=> $this->input->post("renewable_flag"),
                        "add_ons_opted"=> $this->input->post("add_ons_opted"),
                        "add_ons_not_opt" =>$this->input->post("add_ons_not_opt"),
                        "lead_type" =>"2",
                        "agent_commission_amt" => $agent_commission,
                        "own_commission_amt" => $company_com,
                        "sum_insured"=> $this->input->post("sum_insured"),
                        "discount_percent"=> $this->input->post("discount_percent"),
                        "no_claim_bonus"=> $this->input->post("no_claim_bonus"),
                        "total_own_damage"=> $this->input->post("total_own_damage"),
                        "tot_add_on_premium"=> $this->input->post("tot_add_on_premium"),
                        "commisson_base_premium"=> $this->input->post("commisson_base_premium"),
                        "basic_tp"=> $this->input->post("basic_tp"),
                        "owner_driver_pa"=> $this->input->post("owner_driver_pa"),
                        "owner_diver_amt"=> $this->input->post("owner_diver_amt"),
                        "no_of_year_own_drv"=> $this->input->post("no_of_year_own_drv"),
                        "fuel_kit"=> $this->input->post("fuel_kit"),
                        "fuel_kit_amt"=> $this->input->post("fuel_kit_amt"),
                        "geograpical"=> $this->input->post("geograpical"),
                        "geograpical_amt"=> $this->input->post("geograpical_amt"),
                        "un_named_passenger_pa"=> $this->input->post("un_named_passenger_pa"),
                        "un_named_passenger_amt"=> $this->input->post("un_named_passenger_amt"),
                        "no_seats_per_person"=> $this->input->post("no_seats_per_person"),
                        "no_seats_per_person_amt"=> $this->input->post("no_seats_per_person_amt"),
                        "LL_paid "=> $this->input->post("llp"),
                        "LL_paid_amt"=> $this->input->post("llp_amt"),
                        "no_drv_emp"=> $this->input->post("no_drv_emp"),
                        "pa_paid_drv"=> $this->input->post("pa_paid_drv"),
                        "pa_paid_drv_amt"=> $this->input->post("pa_paid_drv_amt"),
                        "no_seats_per_person1"=> $this->input->post("no_seats_per_person1"),
                        "no_seats_per_person_amt1"=> $this->input->post("no_seats_per_person_amt1"),
                        "tot_liability_premium"=> $this->input->post("tot_liability_premium"),
                        "total_premium"=> $this->input->post("total_premium"),
                        "gst"=> $this->input->post("gst"),
                        "premium_gst"=> $this->input->post("premium_gst"),
                        "policy_issue_date"=> $this->input->post("policy_issue_date"),
                        "policy_agency_pos"=> $this->input->post("policy_agency_pos"),
                        "policy_source"=> $this->input->post("policy_source"),
                        "policy_user"=> $this->input->post("policy_user"),
                        "policy_location"=> $this->input->post("policy_location"),
                        "previous_policy_no"=> $this->input->post("previous_policy_no"),
                        "previous_insurer"=> $this->input->post("previous_insurer"),
                        "previous_insurance_plan"=> $this->input->post("previous_insurance_plan"),
                        "previous_agency_pos"=> $this->input->post("previous_agency_pos"),
                        "previous_source"=> $this->input->post("previous_source"),
                        "dectable_details"=> $this->input->post("dectable_details"),
                        "policy_additional_info"=> $this->input->post("policy_additional_info"),
                        "reference_no"=> $this->input->post("reference_no"),
                        "other_reference_no"=> $this->input->post("other_reference_no"),
                        "policy_received"=> $this->input->post("policy_received"),
                        "policy_verified"=> $this->input->post("policy_verified"),
                        "policy_verified_info"=> $this->input->post("policy_verified_info"),
                        "policy_cancelled"=> $this->input->post("policy_cancelled"),
                        "policy_cancelled_info"=> $this->input->post("policy_cancelled_info"),
                        "commisson_generation"=> $this->input->post("commisson_generation"),
                        "payment_type"=> $this->input->post("payment_type"),
                        "pay_ref_no"=> $this->input->post("pay_ref_no"),
                        "bank_name"=> $this->input->post("bank_name"),
                        "payment_check_date"=> $this->input->post("payment_check_date"),
                        "payment_and_check_no"=> $this->input->post("payment_and_check_no"),
                        "state"=> $this->input->post("state"),
                        "commission_id" =>$commission_id,
                        "company"=> $this->input->post("company"),
                        "rto"=> $this->input->post("rto"),
                        "commission_type"=> $this->input->post("commission_type"),
                        "age"=> $this->input->post("age"),
                        "no_claim_bonus" =>$ncb,
                        "remarks"=> $this->input->post("remarks"),
                        "created_by"=> $this->session->userdata('session_id'),
                        "created_at"=> date("Y-m-d H:i:s"),
                        //"payment_collected_date"=> $this->input->post("payment_collected_date")
                        );
                        
                        $res = $this->lm->save_generated_policy($data);
                        if($res)
                        {
                            $id = $lead_id;
                            $arr = array(
                                "lead_type" =>"2",
                                 "lead_status"=>"completed",
                            );
                            $data_1 = $this->lm->update_lead_type_status($arr,$id);
                        }
                     
                    $activity_log = array("lead_id"=>$id,"action"=>"New Policy Generated","action_type"=>"generate_policy","created_by"=>$this->session->userdata('session_name'),"time"=>date("Y-m-d H:i:s"));
                    
                    
              $countfiles = count($_FILES['files']['name']);
              for($i=0;$i<$countfiles;$i++)
              {
                    if(!empty($_FILES['files']['name'][$i])){
                      $_FILES['file']['name'] = $_FILES['files']['name'][$i];
                      $_FILES['file']['type'] = $_FILES['files']['type'][$i];
                      $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
                      $_FILES['file']['error'] = $_FILES['files']['error'][$i];
                      $_FILES['file']['size'] = $_FILES['files']['size'][$i];
             
                      $config['upload_path'] = './datas/spot_photos/'; 
                      $config['allowed_types'] = '*';
                      $config['file_name'] = $_FILES['files']['name'][$i];
              
                      $this->load->library('upload',$config); 
                      $arr = array('msg' => 'something went wrong', 'success' => false);
                      
                      if($this->upload->do_upload('file'))
                      {
                       $data = $this->upload->data(); 
                       $data = array("lead_id"=>$id,"document_type"=>"Policy","document"=>$data['file_name'],"uploaded_date"=>date("Y-m-d H:i:s"));
                       $res = $this->lm->add_policy_documents($data);
                      }
                    }
                  }
                     
                    if(isset($_FILES))
            		{
            			$config['upload_path'] = './datas/nominee_documents/';
            			$config['allowed_types'] = '*';
            			
            			$this->load->library('upload',$config);
            			$this->upload->initialize($config);
            			if(!$this->upload->do_upload('n_adhar_card_upload'))
            			{
            				$file = '';
            			}
            			else
            			{
            				$file = $this->upload->data('file_name');
            			}
            		}
    	
                    $nominee_details = array("lead_id"=>$id,"name" =>$nominee_name,"adharcard_no"=>$adharcard_no,"mobile_no"=>$n_mobile_no,"file"=>$file,"created_by"=>$this->session->userdata('session_id'),"created_date"=>date("Y-m-d H:i:s"));
                    $add_nominee_details = $this->lm->add_nominee_details($nominee_details);
                    $add_activity = $this->lm->add_activity_log($activity_log);
                    echo "success";
    	        }
    	        else
    	        {
    	            echo "<script>alert('Permission Denied');window.location.href='home';</script>";
    	        }
        }
    }
    
    public function commission_type_load()
    {
        if($this->session->has_userdata('logged_in'))
        {
            $state = $this->input->post("state");
            $company = $this->input->post("company");
            $rto = $this->input->post("rto");
            $policy_class = $this->input->post("policy_class");
            $bussiness_type = $this->input->post("bussiness_type");
            $policy_premium = $this->input->post("policy_premium");
            
            $commission_type = [];
            $res = $this->lm->commission_type_load($state,$company,$policy_class,$bussiness_type,$policy_premium,$rto);
            
            $arr = [];
            
            foreach($res as $r)
            {
                $is_exist = false;
                foreach($commission_type as $ct)
                {
                    if($ct->id == $r->commission_type)
                    {
                          $is_exist = true;  
                    }
                } 
                if(!$is_exist)
                {
                    $commission_type [] = $this->lm->fetch_commission_type($r->commission_type);
                }
            }
            
            echo json_encode($commission_type);
        }
    }
    
     public function fetch_health_commission_company()
    {
         if($this->session->has_userdata('logged_in'))
        {
            $policy_premium = $this->input->post("policy_premium");
            $res = $this->lm->fetch_health_commission_company($policy_premium);
            $option = "";
            $temp = "";
            $commission_type = [];
            $count = 0;
            foreach($res as $r)
            {
                 $is_exist = false;
                 foreach($commission_type as $ct)
                {
                    if($ct->id == $r->commission_type)
                    {
                          $is_exist = true;  
                    }
                } 
                if(!$is_exist)
                {
                    $count++;
                    $temp .= "<option value='".$r->id."'>".$r->company_name."</option>";
                }
                $commission_type[] = $r->id;
            }
            if($count != 1)
            {
                $option .= "<option value=''>Select Insurance Company</option>";
            }
            echo $option.$temp;
        }
    }
    
    
    public function commission_category_load()
    {
        if($this->session->has_userdata('logged_in'))
        {
            $state = $this->input->post("state");
            $company = $this->input->post("company");
            $rto = $this->input->post("rto");
            $policy_class = $this->input->post("policy_class");
            $bussiness_type = $this->input->post("bussiness_type");
            $policy_premium = $this->input->post("policy_premium");
            $age = $this->input->post("age");
            $commission_type = [];
            $res = $this->lm->commission_category_load($state,$company,$policy_class,$bussiness_type,$policy_premium,$rto);
            $arr = [];
            foreach($res as $r)
            {
                $is_exist = false;
                foreach($commission_type as $ct)
                {
                    if($ct->id == $r->category)
                    {
                          $is_exist = true;  
                    }
                }
                if($r->commission_type == 2)
                {
                    if(!$is_exist && $r->vehicle_age_min <= $age && $r->vehicle_age_max >= $age)
                    {
                        $commission_type [] = $this->lm->fetch_commission_category($r->category);
                    }
                }
                else
                {
                    if(!$is_exist)
                    {
                        $commission_type [] = $this->lm->fetch_commission_category($r->category);
                    }
                }
            }
            
            echo json_encode($commission_type);
        }
    }
    
    public function vehicle_classification_load()
    {
        if($this->session->has_userdata('logged_in'))
        {
            $state = $this->input->post("state");
            $company = $this->input->post("company");
            $rto = $this->input->post("rto");
            $policy_class = $this->input->post("policy_class");
            $bussiness_type = $this->input->post("bussiness_type");
            $policy_premium = $this->input->post("policy_premium");
            $age = $this->input->post("age");
            $category = $this->input->post("category");
            $commission_type = [];
            $res = $this->lm->vehicle_classification_load($state,$company,$policy_class,$bussiness_type,$policy_premium,$rto,$category);
            $arr = [];
            foreach($res as $r)
            {
                $is_exist = false;
                foreach($commission_type as $ct)
                {
                    if($ct->id == $r->product)
                    {
                          $is_exist = true;  
                    }
                }
                if($r->commission_type == 2)
                {
                    if(!$is_exist && $r->vehicle_age_min <= $age && $r->vehicle_age_max >= $age)
                    {
                        $commission_type [] = $this->lm->fetch_commission_product($r->product);
                    }
                }
                else
                {
                    if(!$is_exist)
                    {
                        $commission_type [] = $this->lm->fetch_commission_product($r->product);
                    }
                }
            }
            
            echo json_encode($commission_type);
        }
    }
    public function generate_policy1()
    {
        if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
    	{    		
		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
		   	$data["users"] = $this->lm->fetch_users();
		   	$data["client_type"] = $this->lm->fetch_client_type();
		   	$data["business"] = $this->lm->fetch_business_type();
		   	$data["class"] = $this->lm->fetch_list_of_policy_type();
    		$this->load->view('header',$pro_data);
    		$this->load->view('generate_policy',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else if($this->session->has_userdata('logged_in') && ($this->session->userdata('session_role') == "user" || $this->session->userdata('session_role') == "AI"))
	    {
	        $check_user_i = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));
	        
	        if($check_user_i->policy_view == "1")
	        {
    	        $session_id = $this->session->userdata('session_id');
    	        $pro_data["project_info"] = $this->mm->fetch_project_info();
    	        $data["users"] = $this->lm->fetch_users_by_user($session_id);
    	        $data["client_type"] = $this->lm->fetch_client_type();
    	        $data["business"] = $this->lm->fetch_business_type();
    	        $data["class"] = $this->lm->fetch_list_of_policy_type();
        		$this->load->view('header',$pro_data);
        		$this->load->view('generate_policy',$data);
        		$this->load->view('footer',$pro_data);
	        }
	        else
	        {
	            echo "<script>alert('Permission Denied');window.location.href='home';</script>";
	        }
	    }
	    else
	    {
	    	redirect("login");
	    }
    }
    
    public function fetch_generate_policy()
    {
       $draw = intval($this->input->post("draw"));
	   $res = array();
       $session_id = 0;
       
		if($this->session->has_userdata('logged_in')) 
    	{
    	    $check_user_i = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));

            	    if($this->session->userdata('session_role') == "user")
            	    {
            	        $session_id = $this->session->userdata('session_id');
            	        $res = $this->lm->fetch_generate_policy($session_id);
            	    }
            	    else
            	    {
        			    $res = $this->lm->fetch_generate_policy($session_id);
            	    }

		}
		
		$own_od = "";
		$own_tp = "";
		$on_net = "";
	
		
    		$arr = [];
            $a = $_POST['start'];
        
            foreach($res as $da)
            {
            	$a++;
          
          
              $action = "";
              
               if($this->session->userdata("session_role") == "admin")
               {
                 $action = "<a class='btn btn-info btn-xs' href='generate_policy?id=".$da->c_lead_id."&&sec=ap'><i class='fa fa-pencil-square-o'></i> </a>";
               }
            	
            	$client_name = "<a href='#' onclick=view_data(".$da->c_lead_id.")>".$da->client_name."</a>";

                $arr[] = array(
                    $a,
                    $client_name,
                    $da->mobile_no,
                    $da->agent_pos_code,
                    $da->policy_no,
                    $da->company_name,
                    "<span class='pull-right'>".number_format($da->total_own_damage,2)."</span>",
                    "<span class='pull-right'>".number_format($da->tot_liability_premium,2)."</span>",
                    "<span class='pull-right'>".number_format($da->total_premium,2)."</span>",
                    "<span class='pull-right'>".number_format($da->gst,2)."</span>",
                    "<span class='pull-right'>".number_format($da->own_commission_amt,2)."</span>",
                    "<span class='pull-right'>".number_format($da->agent_commission_amt,2)."</span>",
                    $da->business_name,
                    $da->class_name,
                    $da->policy_type,
                    date("d-m-Y",strtotime($da->policy_s_date)),
                    date("d-m-Y",strtotime($da->policy_ex_date)),
                    $da->policy_premium_name,
                    $action
                );
            }
    
            $result = array(
            			"draw"=> $draw,
    				    "recordsTotal"=> $this->lm->get_all_generate_policy_count($session_id),
    				    "recordsFiltered"=> $this->lm->get_filtered_generate_policy_count($session_id),
    				    "data"=>$arr,
    				);
            echo json_encode($result);

    }
    
    
    public function fetch_generate_policy_health()
    {
        $draw = intval($this->input->post("draw"));
	   $res = array();
       $session_id = 0;
       
		if($this->session->has_userdata('logged_in')) 
    	{
    	    $check_user_i = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));

            	    if($this->session->userdata('session_role') == "user")
            	    {
            	        $session_id = $this->session->userdata('session_id');
            	        $res = $this->lm->fetch_generate_policy_health($session_id);
            	    }
            	    else
            	    {
        			    $res = $this->lm->fetch_generate_policy_health($session_id);
            	    }

		}
		
		$own_od = "";
		$own_tp = "";
		$on_net = "";
	
		
    		$arr = [];
            $a = $_POST['start'];
        
            foreach($res as $da)
            {
            	$a++;

                $arr[] = array(
                    $a,
                    $da->client_name,
                    $da->mobile_no,
                    $da->agent_pos_code,
                    $da->policy_no,
                    $da->company_name,
                    "<span class='pull-right'>".number_format($da->total_premium,2)."</span>",
                    "<span class='pull-right'>".number_format($da->gst,2)."</span>",
                    "<span class='pull-right'>".number_format($da->own_commission_amt,2)."</span>",
                    "<span class='pull-right'>".number_format($da->agent_commission_amt,2)."</span>",
                    $da->business_name,
                    $da->class_name,
                    $da->policy_type,
                    date("d-m-Y",strtotime($da->policy_s_date)),
                    date("d-m-Y",strtotime($da->policy_ex_date)),
                );
            }
    
            $result = array(
            			"draw"=> $draw,
    				    "recordsTotal"=> $this->lm->get_all_generate_policy_count_health($session_id),
    				    "recordsFiltered"=> $this->lm->filter_gen_policy_count_health($session_id),
    				    "data"=>$arr,
    				);
            echo json_encode($result);
    }
    
    
    public function fetch_generate_policy_sme()
    {
        $draw = intval($this->input->post("draw"));
        $res = array();
        $session_id = 0;
       
            if($this->session->has_userdata('logged_in')) 
            {
                $check_user_i = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));
            
                if($this->session->userdata('session_role') == "user")
                {
                    $session_id = $this->session->userdata('session_id');
                    
                    $res = $this->lm->fetch_generate_policy_sme($session_id);
                }
                else
                {
            	    $res = $this->lm->fetch_generate_policy_sme($session_id);
                }
            
            }
		
            $own_od = "";
            $own_tp = "";
            $on_net = "";
          
            $arr = [];
            $a = $_POST['start'];
            
            foreach($res as $da)
            {
            	$a++;
            	
            	$sub_agn_1 = $this->lm->get_agent_name($da->sub_agn_1);
            	$sub_agn_2 = $this->lm->get_agent_name($da->sub_agn_2);
            	
            	if($sub_agn_1 != "" || $sub_agn_1 != null)
            	{
            	    $agn_1_name = $sub_agn_1->name;
            	}
            	else 
            	{
            	    $agn_1_name = "";
            	}
            	
            	if($sub_agn_2 != "" || $sub_agn_2 != null)
            	{
            	    $agn_2_name = $sub_agn_2->name;
            	}
            	else 
            	{
            	    $agn_2_name = "";
            	}
            	
            	$client_name = "<a href='#' onclick=view_data(".$da->c_lead_id.")>".$da->client_name."</a>";

                $arr[] = array(
                    $a,
                    $client_name,
                    $da->mobile_no,
                    $da->agent_pos_code,
                    $da->policy_no,
                    $da->company_name,
                    "<span class='pull-right'>".number_format($da->total_premium,2)."</span>",
                    "<span class='pull-right'>".number_format($da->gst,2)."</span>",
                    "<span class='pull-right'>".number_format($da->own_commission_amt,2)."</span>",
                    "<span class='pull-right'>".number_format($da->agent_commission_amt,2)."</span>",
                    "<span class='pull-right'>".number_format($da->ai_com,2)."</span>",
                    $agn_1_name,
                    "<span class='pull-right'>".number_format($da->sub_agn_amt_1,2)."</span>",
                    $agn_2_name,
                    "<span class='pull-right'>".number_format($da->sub_agn_amt_2,2)."</span>",
                    $da->business_name,
                    $da->class_name,
                    $da->policy_type,
                    date("d-m-Y",strtotime($da->policy_s_date)),
                    date("d-m-Y",strtotime($da->policy_ex_date)),
                );
            }
    
            $result = array(
            			"draw"=> $draw,
    				    "recordsTotal"=> $this->lm->get_all_generate_policy_count_sme($session_id),
    				    "recordsFiltered"=> $this->lm->get_filtered_generate_policy_count_sme($session_id),
    				    "data"=>$arr,
    				);
            echo json_encode($result);
    }
    
    // customers //
    
    public function customers()
    {
        if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
    	{    	
    	    $data["permission"] = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));  
		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
		   	$data["users"] = $this->lm->fetch_users();
		   	$data["client_type"] = $this->lm->fetch_client_type();
		   	$data["business"] = $this->lm->fetch_business_type();
		   	$data["class"] = $this->lm->fetch_list_of_policy_type();
    		$this->load->view('header',$pro_data);
    		$this->load->view('customers',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else if($this->session->has_userdata('logged_in') && ($this->session->userdata('session_role') == "user" || $this->session->userdata('session_role') == "AI"))
	    {
	        
	      $data["permission"] = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));  
	        $pro_data["project_info"] = $this->mm->fetch_project_info();
	        $data["users"] = $this->lm->fetch_users();
	        $data["client_type"] = $this->lm->fetch_client_type();
	        $data["business"] = $this->lm->fetch_business_type();
	        $data["class"] = $this->lm->fetch_list_of_policy_type();
    		$this->load->view('header',$pro_data);
    		$this->load->view('customers',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else
	    {
	    	redirect("login");
	    }
    }
    
    public function fetch_customers()
    {
        if($this->session->has_userdata('logged_in'))
    	 {
    	     $draw = intval($this->input->post("draw"));
    	     
    	     $lead_type = $this->input->post("lead_type");
    	     $class = $this->input->post("class_type");
    	     $a = $_POST['start'];
    	     $res = $this->lm->fetch_all_customers($lead_type,$class);
    	     $arr = [];
    	     
             foreach($res as $da)
             {
                    $a++;
                    
                    $action = "<a href='create_lead?id=".$da->id."' class='btn btn-warning btn-xs'><i class='fa fa-eye'></i></a>";
                    
                    
                    $client_name = "<a href='#' onclick=view_data(".$da->id.")>".$da->client_name."</a>";
                    
                    $arr[] =array(
                           $a,
                           $client_name,
                           $da->mobile_no,
                           $da->lclass,
                           $da->p_type,
                           $da->policy_no,
                           $da->pre_name,
                           date_format(date_create($da->policy_ex_date),"d-m-Y"),
                           $action,
                        );
                }
                
    	        $result = array(
            			"draw"=> $draw,
    				    "recordsTotal"=> $this->lm->get_all_customer_datas_count($lead_type,$class),
    				    "recordsFiltered"=> $this->lm->get_customer_filtered_datas_count($lead_type,$class),
    				    "data"=>$arr,
    				);
            echo json_encode($result);
    	 }
    }
    
    public function fetch_renewals()
    {
         if($this->session->has_userdata('logged_in'))
    	 {
            	    $draw = intval($this->input->post("draw"));
        		    $due_date = $this->input->post("due_date");
        		    $lead_type = $this->input->post("lead_type");
            	     
                    if($due_date == "Overdue")
            		{
            		     $from_date = "all";
                         $to_date = date("Y-m-d",strtotime("-1 days"));
            		}
            		else if($due_date == "7 days")
            		{
            		     $from_date = date("Y-m-d");
                         $to_date = date('Y-m-d',strtotime("7 days"));
            		}
            		else if($due_date == "8-15 days")
            		{
            		    $from_date = date('Y-m-d',strtotime("8 days"));
                        $to_date = date('Y-m-d',strtotime("15 days"));
            		}
            		else if($due_date == "16-30 days")
            		{
            		    $from_date = date('Y-m-d',strtotime("16 days"));
                        $to_date = date('Y-m-d',strtotime("30 days"));
            		}
            		else if($due_date == "31-45 days")
            		{
            		     $from_date = date('Y-m-d',strtotime("31 days"));
                         $to_date = date('Y-m-d',strtotime("45 days"));
            		}
            		
            		if($this->session->has_userdata('session_role') == "user")
            	    {
            	        $user_id = $this->session->userdata('session_id');
            	    }
            	    
        			$res = $this->lm->fetch_renewals($lead_type,$user_id,$from_date,$to_date);
        			
        			$arr = [];
                    $a = 0 ;
                    
                  $a = $_POST['start'];
                
                foreach($res as $da)
                {
                	$a++;
        
                    $action = "<a onclick=renewal(".$da->id.") class='btn btn-success btn-xs'><i class='fa fa-refresh'></i>  Renew Now</a>";
            	    
            	    
            	     $client_name = "<a href='#' onclick=view_data(".$da->id.")>".$da->client_name."</a>";
            	 
                    $arr[] = array(
                                   $a,
                                   $client_name,
                                   $da->mobile_no,
                                   $da->lclass,
                                   $da->p_type,
                                   $da->policy_no,
                                   $da->pre_name,
                                   date_format(date_create($da->policy_ex_date),"d-m-Y"),
                                   $action,
                                );
                }
        
                $result = array(
                			"draw"=> $draw,
        				     "recordsTotal"=> $this->lm->get_all_renewal_datas_count($lead_type,$user_id,$from_date,$to_date),
            				"recordsFiltered"=> $this->lm->get_renewal_filtered_datas_count($lead_type,$user_id,$from_date,$to_date),
        				    "data"=>$arr,
        				);
                echo json_encode($result);
        	
            	 }
    }
    
    // UPDATE //
    
    public function update_client_details()
    {
         if($this->session->has_userdata('logged_in'))
    	 {
    	    $lead_id = $this->input->post("lead_id");
    	    $client_type = $this->input->post("client_type");
	        $client_name = $this->input->post("client_name");
	        $mobile_no = $this->input->post("mobile_no");
	        $other_contact_details = $this->input->post("other_contact_details");
	        $landline_no = $this->input->post("landline_no");
	        $address = $this->input->post("address");
	        $email_id = $this->input->post("email_id");
	        $contact_person_name = $this->input->post("contact_person_name");
	        $contact_person_des = $this->input->post("contact_person_des");
	        $dob = $this->input->post("dob");
	        $age = $this->input->post("age");
	        $area = $this->input->post("area");
	        $pin_code = $this->input->post("pin_code");
	        
	        $client_id = $this->lm->fetch_client_id_by_lead_id($lead_id);
	       
    	       $data = array( 
	             "client_type_id" =>$client_type,
	             "client_name" =>$client_name,
	             "mobile_no" =>$mobile_no,
	             "other_contact_details"=>$other_contact_details,
	             "landline_no" => $landline_no,
	             "address" =>$address,
	             "email" =>$email_id,
	             "contact_person_name" =>$contact_person_name,
	             "contact_person_designation"=>$contact_person_des,
	             "date_of_birth" => $dob,
	             "age" =>$age,
	             "area" =>$area,
	             "pin_code" =>$pin_code,
	             );
	             
	           $res = $this->lm->update_client_details($client_id,$data);

            	$activity_log = array("lead_id"=>$lead_id,"action"=>"Client Details Updated","action_type"=>"client_update","created_by"=>$this->session->userdata('session_name'),"time"=>date("Y-m-d h:i:sa"));
                $add_activity = $this->lm->add_activity_log($activity_log);
	           echo "success";   
    	 }
    }
    
    public function update_requirement_details()
    {
        if($this->session->has_userdata('logged_in'))
    	 {
    	    $lead_id = $this->input->post("lead_id");
    	    $bussiness_type = $this->input->post("bussiness_type");
	        $class = $this->input->post("policy_class");
	        $policy_type = $this->input->post("policy_type");
	        $lead_generated_date =  $this->input->post("lead_generated_date");
	        $due_date =  $this->input->post("due_date");
	        $broken_policy =  $this->input->post("broken_policy");
	        $location=  $this->input->post("location");
	        $classification =  $this->input->post("classification");
	        $source =  $this->input->post("source");
	        $agent_pos = $this->input->post("agent_pos");
	        $assign_to_user =  $this->input->post("assign_to_user");
	        $area_incharge  = $this->input->post("area_incharge");
	        $v_regn_no = $this->input->post("v_regn_no");
	        $region = $this->lm->fetch_agent_region($agent_pos);
	        
	        $region_id = "";
	        
	        if($region != null)
	        {
	            $region_id = $region->region;
	        }
	        
	        
	        $remarks = $this->input->post("remarks");
	        $updated_date = date("Y-m-d h:i:s");
	        
    	    $arr = array( 
    	        
    	             "business_type" =>$bussiness_type,
    	             "class"=>$class,
    	             "policy_type" => $policy_type,
    	             "lead_generated_date" => $lead_generated_date,
    	             "due_date" =>$due_date,
    	             "broken_policy" => $broken_policy,
    	             "location" =>$location,
    	             "classfication" =>$classification,
    	             "source"=>$source,
    	             "lead_status"=>"open",
    	             "agency_and_pos" => $agent_pos,
    	             "assigned_user" => $assign_to_user,
    	             "area_incharge" =>$area_incharge,
    	             "region_id" =>$region_id,
    	             "remarks" =>$remarks,
    	             "updated_date"=>$updated_date);
    	             $data = $this->lm->update_requirement_details($arr,$lead_id);
    	             
    	             if($class == "1")
    	             {
    	                  $v_info = array("vechi_register_no" =>$v_regn_no);
                           $update_v_info = $this->lm->update_vechicle_regn_no($v_info,$lead_id);   
    	             }
    	             
    	             	$activity_log = array("lead_id"=>$lead_id,"action"=>"Requirement Details Updated","action_type"=>"requirement_details_update","created_by"=>$this->session->userdata('session_name'),"time"=>date("Y-m-d h:i:sa"));
                        $add_activity = $this->lm->add_activity_log($activity_log);
    	             echo "success";
	             }
    	 }
    	 
    	 // Edit Vechicle Details // 
    	 
    	 public function fetch_edit_vechicle_details()
    	 {
        	 if($this->session->has_userdata('logged_in'))
        	 {
        	     $lead_id = $this->input->post("lead_id");
        	     $res = $this->lm->fetch_edit_vechicle_details($lead_id);
        	     echo json_encode($res);
        	 }
    	 }
    	 
    	 public function get_vechicle_make()
    	 {
    	     if($this->session->has_userdata('logged_in'))
        	 {
        	     
        	 }
    	 }
    	 
        public function get_uploaded_vechicle_documents()
        {
            if($this->session->has_userdata('logged_in'))
            {
                $lead_id = $this->input->post("lead_id");
                $res = $this->lm->get_vechicle_uploaded_documents($lead_id);
                
                $html = "";
                foreach($res as $da)
                {
        		$html .="<tr>
        		           <td><a target='_blank' href='./datas/documents/".$da->document_file."'><i class='fa fa-file'></i></a></td>
        		           <td>".$da->document_file."</td>
        		           <td>".$da->document_type."</td>
        		           <td><a class='fa fa-edit fa-2x' onclick=edit_vechi_data(".$da->id.")></a></td>
        		           <td><a class='fa fa-trash fa-2x' style='color:red;' onclick=delete_vechi_data(".$da->id.")></a></td>
        		         </tr>";
                }
                echo $html;
            }
        }
        
        public function get_vechicle_uploaded_file_by_id()
        {
            if($this->session->has_userdata('logged_in'))
            {
                 $id = $this->input->post("id");
                $res = $this->lm->get_vechicle_uploaded_file_by_id($id);
                echo json_encode($res);
            }
        }
        
        public function edit_vehicle_documents()
        {
            if($this->session->has_userdata('logged_in'))
            {
                $id = $this->input->post("id");
                $document_type = $this->input->post("document_type");
                
                       if(isset($_FILES))
                		{
                			$config['upload_path'] = './datas/documents/';
                			$config['allowed_types'] = '*';
                			
                			$this->load->library('upload',$config);
                			$this->upload->initialize($config);
                			if(!$this->upload->do_upload('file'))
                			{
                			   $date = date("Y-m-d H:i:s"); 
                			   $data = array("document_type" =>$document_type,"updated_time" =>$date);
                			}
                			else
                			{
                			    $res = $this->lm->get_vechicle_uploaded_file_by_id($id);  
			                    $old_file = $res->document_file;
                               unlink("./datas/documents/".$old_file);
                			   $file = $this->upload->data('file_name');
                			   $date = date("Y-m-d H:i:s"); 
                			   $data = array("document_type" =>$document_type,"document_file"=>$file,"updated_time" =>$date);
                			}
                			
                			$res = $this->lm->update_vechicle_documents($data,$id);
                			
                			$get_docs = $this->lm->get_vechicle_uploaded_documents($res->lead_id);
                			
                			$html = "";
                			
                            foreach($get_docs as $da)
                                {
                                $html .="<tr>
                                <td><a target='_blank' href='./datas/documents/".$da->document_file."'><i class='fa fa-file'></i></a></td>
                                <td>".$da->document_file."</td>
                                <td>".$da->document_type."</td>
                                <td><a class='fa fa-edit fa-2x' onclick=edit_vechi_data(".$da->id.")></a></td>
                                <td><a class='fa fa-trash fa-2x' style='color:red;' onclick=delete_vechi_data(".$da->id.")></a></td>
                                </tr>";
                            }
                            echo $html;
                		}
            }
        }
        
        public function delete_vechicle_documents($id)
        {
            if($this->session->has_userdata('logged_in'))
            {
                $id = $this->input->post("id");
                $res = $this->lm->get_vechicle_uploaded_file_by_id($id);  
			    $old_file = $res->document_file;
			    
			    unlink("./datas/documents/".$old_file);
			    
			    $data = $this->lm->delete_vechicle_documents($id);
			    
			    if($data->lead_id !="")
			    {
			        $get_docs = $this->lm->get_vechicle_uploaded_documents($data->lead_id);
			        
			        foreach($get_docs as $da)
                    {
                    $html .="<tr>
                    <td><a target='_blank' href='./datas/documents/".$da->document_file."'><i class='fa fa-file'></i></a></td>
                    <td>".$da->document_file."</td>
                    <td>".$da->document_type."</td>
                    <td><a class='fa fa-edit fa-2x' onclick=edit_vechi_data(".$da->id.")></a></td>
                    <td><a class='fa fa-trash fa-2x' style='color:red;' onclick=delete_vechi_data(".$da->id.")></a></td>
                    </tr>";
                    }
                      echo $html;
			    }
			    else
			    {
			         $html = "";
			    }
            }
        }
        
        public function update_vechicle_details()
        {
            if($this->session->has_userdata('logged_in'))
    	    {
                  $id = $this->input->post("id");
            	  $vechile_type =$this->input->post("vechile_type");
                  $vechi_make =$this->input->post("vechi_make");
                  $vechi_model =$this->input->post("vechi_model");
                  $vechi_varient =$this->input->post("vechi_varient");
                  $vechi_cc =$this->input->post("vechi_cc");
                  $vechi_manu_month =$this->input->post("vechi_manu_month");
                  $vechi_manu_year =$this->input->post("vechi_manu_year");
                  $vechi_seating =$this->input->post("vechi_seating");
                  $vechi_classfication =$this->input->post("vechi_classfication");
                  $vechi_fuel_type =$this->input->post("vechi_fuel_type");
                  $vechi_gvw =$this->input->post("vechi_gvw");
                  $passenger_carrying =$this->input->post("passenger_carrying");
                  $vechi_engine_num =$this->input->post("vechi_engine_num");
                  $vechi_chassis_num =$this->input->post("vechi_chassis_num");
                  $vechi_hypothecation =$this->input->post("vechi_hypothecation");
                  $vechi_agency_pos =$this->input->post("vechi_agency_pos");
                  $vechi_remarks =$this->input->post("vechi_remarks");
                  $regn_date =$this->input->post("regn_date");
                  $register_no =$this->input->post("register_no"); 
                  $rto =$this->input->post("rto");
                  $zone =$this->input->post("zone");
                  $regn_address =$this->input->post("regn_address");
                  $state =$this->input->post("state");
                  $city =$this->input->post("city");
                  $pincode =$this->input->post("pincode");
                  $vechi_user_name =$this->input->post("vechi_user_name");
                  $vechi_user_cont =$this->input->post("vechi_user_cont");
                  $date = date("Y-m-d");
                  
                  $data = array(
                        "vechile_type" =>$vechile_type,
                        "vechi_make" =>$vechi_make,
                        "vechi_model" =>$vechi_model,
                        "vechi_varient" =>$vechi_varient,
                        "vechi_cc" =>$vechi_cc,
                        "vechi_manu_month" =>$vechi_manu_month,
                        "vechi_manu_year" =>$vechi_manu_year,
                        "vechi_seating" =>$vechi_seating,
                        "vechi_classfication" =>$vechi_classfication,
                        "vechi_fuel_type" =>$vechi_fuel_type,
                        "vechi_gvw" =>$vechi_gvw,
                        "passenger_carrying" =>$passenger_carrying,
                        "vechi_engine_num" =>$vechi_engine_num,
                        "vechi_chassis_num" =>$vechi_chassis_num,
                        "vechi_hypothecation" =>$vechi_hypothecation,
                        "created_by" =>$vechi_agency_pos,
                        "vechi_remarks" =>$vechi_remarks,
                        "regn_date" =>$regn_date,
                        "vechi_register_no" =>$register_no,
                        "rto" =>$rto,
                        "zone" =>$zone,
                        "regn_address" =>$regn_address,
                        "state" =>$state,
                        "city" =>$city,
                        "pincode" =>$pincode,
                        "vechi_user_name" =>$vechi_user_name,
                        "vechi_user_cont" =>$vechi_user_cont,
                        "updated_at" =>$date,
                      );
                  
                  $res = $this->lm->update_vechicle_details($data,$id);
                  
                  $arr = $this->lm->fetch_vechicle_lead_id($id);
                  
                  $activity_log = array("lead_id"=>$arr->lead_id,"action"=>"Vechicle Details Updated","action_type"=>"vechicle_update","created_by"=>$this->session->userdata('session_name'),"time"=>date("Y-m-d H:i:s"));
                 $add_activity = $this->lm->add_activity_log($activity_log);
                  
                  
    	    }
        }
        
        public function get_recent_activities()
        {
            if($this->session->has_userdata('logged_in'))
    	    {
    	        $lead_id = $this->input->post("lead_id");
    	        $res = $this->lm->get_recent_activities($lead_id);
    	       
    	        $html = "";
    	        
    	        foreach($res as $da)
    	        {
    	            if($da->action_type == "new_lead_creation")
    	            {
    	                $icon = "fa fa-bullseye";
    	                $html .=" <tr>
                        <td class = 'no_mar_pad'><i class='".$icon."' style='padding-right:10px;'></i><a href='leads'>
                        <span style='color:#444'><b>".$da->created_by."</b> ".$da->action."</span>
                                    <span style='color:#444'> at ".date("h:i:s a", strtotime($da->time))."</span></a></td>
                                </tr><p></p>";
    	            }
    	            else if($da->action_type == "Follow_up")
    	            {
    	                $icon = "fa fa-clock-o";
    	              
    	                $html .=" <tr>
                                    <td class='no_mar_pad'><i class='".$icon."' style='padding-right:10px;'></i><a href='followups'>
                                     <span style='color:#444'><b>".$da->created_by."</b> ".$da->action." </span></a></td>
                                </tr><p></p>";
    	            }
    	            else if($da->action_type == "client_update")
    	            {
    	                 $icon = "fa fa-bullseye";
    	              
    	                $html .=" <tr>
                                    <td class='no_mar_pad'><i class='".$icon."' style='padding-right:10px;'></i><a href='leads'>
                                     <span style='color:#444'><b>".$da->created_by."</b> ".$da->action." </span>
                                     <span style='color:#444'> at ".date("d-m-Y h:i:s a", strtotime($da->time))."</span></a></td>
                                </tr><p></p>";
    	            }
    	            else if($da->action_type == "requirement_details_update")
    	            {
    	                 $icon = "fa fa-bullseye";
    	              
    	                $html .=" <tr>
                                    <td class='no_mar_pad'><i class='".$icon."' style='padding-right:10px;'></i><a href='leads'>
                                     <span style='color:#444'><b>".$da->created_by."</b> ".$da->action." </span>
                                     <span style='color:#444'> at ".date("d-m-Y h:i:s a", strtotime($da->time))."</span></a></td>
                                </tr><p></p>";
    	            }
    	            else if($da->action_type == "vechicle_update")
    	            {
    	                $icon = "fa fa-car";
    	              
    	                $html .=" <tr>
                                    <td class='no_mar_pad'><i class='".$icon."' style='padding-right:10px;'></i><a href='leads'>
                                     <span style='color:#444'><b>".$da->created_by."</b> ".$da->action." </span>
                                     <span style='color:#444'> at ".date("d-m-Y h:i:s a", strtotime($da->time))."</span></a></td>
                                </tr><p></p>";
    	            }
    	            else if($da->action_type =="add_vechicle")
    	            {
    	                $icon = "fa fa-car";
    	              
    	                $html .=" <tr>
                                    <td class='no_mar_pad'><i class='".$icon."' style='padding-right:10px;'></i><a href='leads'>
                                     <span style='color:#444'><b>".$da->created_by."</b> ".$da->action." </span>
                                     <span style='color:#444'> at ".date("d-m-Y h:i:s a", strtotime($da->time))."</span></a></td>
                                </tr><p></p>";
    	            }
    	            else if($da->action_type =="prospect")
    	            {
    	                $icon = "fa fa-diamond";
    	              
    	                $html .=" <tr>
                                    <td class='no_mar_pad'><i class='".$icon."' style='padding-right:10px;'></i><a href='leads'>
                                     <span style='color:#444'><b>".$da->created_by."</b> ".$da->action." </span>
                                     <span style='color:#444'> at ".date("d-m-Y h:i:s a", strtotime($da->time))."</span></a></td>
                                </tr><p></p>";
    	            }
    	            else if($da->action_type =="generate_policy")
    	            {
    	                 $icon = "fa fa-file-text";
    	              
    	                $html .=" <tr>
                                    <td class='no_mar_pad'><i class='".$icon."' style='padding-right:10px;'></i><a href='leads'>
                                     <span style='color:#444'><b>".$da->created_by."</b> ".$da->action." </span>
                                     <span style='color:#444'> at ".date("d-m-Y h:i:s a", strtotime($da->time))."</span></a></td>
                                </tr><p></p>";
    	            }
    	            else if($da->action_type =="policy_email")
    	            {
    	                 $icon = "fa fa-envelope";
    	              
    	                $html .=" <tr>
                                    <td class='no_mar_pad'><i class='".$icon."' style='padding-right:10px;'></i><a href='leads'>
                                     <span style='color:#444'><b>".$da->created_by."</b> ".$da->action." </span>
                                     <span style='color:#444'> at ".date("d-m-Y h:i:s a", strtotime($da->time))."</span></a></td>
                                </tr><p></p>";
    	            }
    	        }
    	        echo $html;
    	    }
        }
        
        // create quotation //
        
        public function get_basic_informations()
        {
            if($this->session->has_userdata('logged_in'))
    	    {
    	        $lead_id = $this->input->post("lead_id");
    	        $res = $this->lm->get_basic_informations($lead_id);
    	        
    	        if($res != "")
    	        {
    	            $policy_type = $res->policy_type;
    	            
    	            if($policy_type == "1")
    	            {
    	                  $data = $this->lm->get_car_details($lead_id);  
    	            }
    	            else if($policy_type == "2")
    	            {
    	                  $data = $this->lm->get_bike_details($lead_id); 
    	            }
    	            else if($policy_type == "3")
    	            {
    	                  $data = $this->lm->get_car_details($lead_id);  
    	            }
    	            else if($policy_type == "4")
    	            {
    	                  $data = $this->lm->get_bike_details($lead_id); 
    	            }
    	        }
    	        echo json_encode(array("basic_details"=>$res,"vechi_details"=>$data));
    	    }
        }
        
        public function add_quotations()
        {
            if($this->session->has_userdata('logged_in'))
    	    {
    	    $data = array(
    	    "lead_id" => $this->input->post("lead_id"),
    	    "policy_co_cover_type" => $this->input->post("policy_co_cover_type"),
            "policy_term"=>$this->input->post("q_policy_term"),
            "policy_s_date"=>$this->input->post("q_policy_s_date"),
            "policy_ex_date"=>$this->input->post("q_policy_ex_date"),
            "insurer"=>$this->input->post("q_insurer"),
            "insurer_branch"=>$this->input->post("q_insurer_branch"),
            "idv"=>$this->input->post("q_idv"),
            "elec_access_value"=>$this->input->post("q_elec_access_value"),
            "non_elec_access_value"=>$this->input->post("q_non_elec_access_value"),
            "lpg_cng"=>$this->input->post("q_lpg_cng"), 
            "sum_insured"=>$this->input->post("q_sum_insured"),
            "make_model"=>$this->input->post("q_make_model"),
            "vechi_age"=>$this->input->post("q_vechi_age"),
            "rto_code"=>$this->input->post("q_rto_code"),
            "zone"=>$this->input->post("q_zone"),
            "cubic_capactiy"=>$this->input->post("q_cubic_capactiy"),
            "vechi_classification"=> $this->input->post("q_vechi_classification"),
			"basic_od_percentage"=>$this->input->post("q_basic_od_percentage"),
            "basic_od_amount"=>$this->input->post("q_basic_od_amount"),
            "spl_dis_per"=>$this->input->post("q_spl_dis_per"),
            "spl_dis_amount"=>$this->input->post("q_spl_dis_amount"),
            "spl_loading_per"=>$this->input->post("q_spl_loading_per"),
            "spl_loading_amount"=>$this->input->post("q_spl_loading_amount"),
            "non_basic_od"=>$this->input->post("q_non_basic_od"),
            "non_elec_acc_amount"=>$this->input->post("q_non_elec_acc_amount"),
            "bi_fuel_kit"=>$this->input->post("q_bi_fuel_kit"),
            "basic_od1"=>$this->input->post("q_basic_od1"),
            "geographical_area"=>$this->input->post("q_geographical_area"),
            "geographical_amount"=>$this->input->post("q_geographical_amount"),
            "emp_loading"=>$this->input->post("q_emp_loading"), 
            "emp_loading_amount"=>$this->input->post("q_emp_loading_amount"),
            "fiber_class_tank"=>$this->input->post("q_fiber_class_tank"), 
            "fiber_class_tank_amount"=>$this->input->post("q_fiber_class_tank_amount"),
            "driving_tuitions"=>$this->input->post("q_driving_tuitions"), 
            "driving_tuitions_amount"=>$this->input->post("q_driving_tuitions_amount"), 
            "basic_od2"=>$this->input->post("q_basic_od2"),
            "basic_od2_amount"=>$this->input->post("q_basic_od2_amount"),
			"anti_theft"=>$this->input->post("q_anti_theft"),
            "anti_theft_amount"=>$this->input->post("q_anti_theft_amount"),
            "anti_handicap"=>$this->input->post("q_anti_handicap"),
            "anti_handicap_amount"=>$this->input->post("q_anti_handicap_amount"),
            "aai"=>$this->input->post("q_aai"),
            "aai_amount"=>$this->input->post("q_aai_amount"),
            "voluntary_deductable"=>$this->input->post("q_voluntary_deductable"),
            "voluntary_deductable_amount"=>$this->input->post("q_voluntary_deductable_amount"),
            "basic_od_3"=>$this->input->post("q_basic_od_3"),
            "ncb_percentage"=>$this->input->post("q_ncb_percentage"),
            "ncb_percentage_amount"=>$this->input->post("q_ncb_percentage_amount"),
            "basic_tp"=>$this->input->post("q_basic_tp"),
            "fuel_kit_amt"=>$this->input->post("q_fuel_kit_amt"),
            "basic_tp1"=>$this->input->post("q_basic_tp1"),
            "geograpical_amt"=>$this->input->post("q_geograpical_amt"),
            "owner_diver_amt"=>$this->input->post("q_owner_diver_amt"),
            "no_of_year_own_drv"=>$this->input->post("q_no_of_year_own_drv"),
            "un_named_passenger_pa"=>$this->input->post("q_un_named_passenger_pa"),
            "un_named_passenger_amt"=>$this->input->post("q_un_named_passenger_amt"),
            "no_seats_per_person"=>$this->input->post("q_no_seats_per_person"),
            "no_seats_per_person_amt"=>$this->input->post("q_no_seats_per_person_amt"),
            "total_od_premium"=>$this->input->post("q_tot_od_premium"),
            "llp"=>$this->input->post("q_llp"),
            "llp_amt"=>$this->input->post("q_llp_amt"),
            "no_drv_emp"=>$this->input->post("q_no_drv_emp"),
            "pa_paid_drv"=>$this->input->post("q_pa_paid_drv"),
            "pa_paid_drv_amt"=>$this->input->post("q_pa_paid_drv_amt"),
            "no_seats_per_person1"=>$this->input->post("q_no_seats_per_person1"),
            "no_seats_per_person_amt1"=>$this->input->post("q_no_seats_per_person_amt1"),
            "tot_tp_premium"=>$this->input->post("q_tot_tp_premium"),
			"q_add_on_combo_premium"=>$this->input->post("q_add_on_combo_premium"),
            "q_add_on_plan_premium_percentage"=>$this->input->post("q_add_on_plan_premium_percentage"),
            "q_add_on_plan_premium_amt" =>$this->input->post("q_add_on_plan_premium_amt"),
            "q_zero_depreciation_check"=>$this->input->post("q_zero_depreciation_check"),
            "q_zero_depreciation_percentage"=>$this->input->post("q_zero_depreciation_percentage"),
            "q_zero_depreciation_amt"=>$this->input->post("q_zero_depreciation_amt"),
            "q_addtional_addons_check"=>$this->input->post("q_addtional_addons_check"),
            "q_addtional_addons_amt"=>$this->input->post("q_addtional_addons_amt"),
            "q_consumbles_check"=>$this->input->post("q_consumbles_check"),
            "q_consumbles_percentage"=>$this->input->post("q_consumbles_percentage"),
            "q_consumbles_amt"=>$this->input->post("q_consumbles_amt"),
            "q_tyre_cover"=>$this->input->post("q_tyre_cover"),
            "q_tyre_cover_percentage"=>$this->input->post("q_tyre_cover_percentage"),
            "q_tyre_cover_amt"=>$this->input->post("q_tyre_cover_amt"),
            "q_ncb_protection_check"=>$this->input->post("q_ncb_protection_check"),
            "q_ncb_protection_amt"=>$this->input->post("q_ncb_protection_amt"),
            "q_engine_protector_check"=>$this->input->post("q_engine_protector_check"),
            "q_engine_protector_percentage"=>$this->input->post("q_engine_protector_percentage"),
            "q_engine_protector_amt" => $this->input->post("q_engine_protector_amt"),
            "q_return_to_invoice_check"=>$this->input->post("q_return_to_invoice_check"),
            "q_return_to_invoice_percentage"=>$this->input->post("q_return_to_invoice_percentage"),
            "q_return_to_invoice_amt"=>$this->input->post("q_return_to_invoice_amt"),
            "key_replacement_check" => $this->input->post("q_key_replacement_check"),
			"key_replacement_percentage" => $this->input->post("q_key_replacement_percentage"),
			"key_replacement_amt" => $this->input->post("q_key_replacement_amt"),
			"daily_allow_check" => $this->input->post("q_daily_allow_check"), 
			"daily_allow_percentage" => $this->input->post("q_daily_allow_percentage"),
			"daily_allow_amt" => $this->input->post("q_daily_allow_amt"),
			"loss_of_belong_check" => $this->input->post("q_loss_of_belong_check"), 
			"loss_of_belong_percentage" => $this->input->post("q_loss_of_belong_percentage"),
			"loss_of_belong_amt" => $this->input->post("q_loss_of_belong_amt"),
			"hotel_trvl_check" => $this->input->post("q_hotel_trvl_check"),
			"hotel_trvl_percentage" => $this->input->post("q_hotel_trvl_percentage"),
			"hotel_trvl_amt" => $this->input->post("q_hotel_trvl_amt"),
			"wind_shield_check" => $this->input->post("q_wind_shield_check"), 
			"wind_shield_percentage" => $this->input->post("q_wind_shield_percentage"),
			"wind_shield_amt" => $this->input->post("q_wind_shield_amt"),
			"baggage_ins_check" => $this->input->post("q_baggage_ins_check"), 
			"baggage_ins_percentage" => $this->input->post("q_baggage_ins_percentage"),
			"baggage_ins_amt" => $this->input->post("q_baggage_ins_amt"),
			"other_add_on_coverag_per" => $this->input->post("q_other_add_on_coverag_per"),
			"other_add_on_coverage_amt" => $this->input->post("q_other_add_on_coverage_amt"),
			"value_added_services" => $this->input->post("q_value_added_services"),
			"net_addon_cover_premium" => $this->input->post("q_net_addon_cover_premium"),
			"add_on_discount_percentage" => $this->input->post("q_add_on_discount_percentage"),
			"add_on_discount_amt" => $this->input->post("q_add_on_discount_amt"),
			"tot_add_on_cover_premium" => $this->input->post("q_tot_add_on_cover_premium"),
			"total_premium" => $this->input->post("q_total_premium"),
			"gst" => $this->input->post("q_gst"),
			"total_payable" => $this->input->post("q_total_payable"),
			"commission_base_premium" => $this->input->post("q_commission_base_premium"),
			"created_user" => $this->session->userdata('session_name'),
			"created_date" => date("Y-m-d H:i:s")
            );
            
            $res = $this->lm->add_quotations($data);
    	    
    	    }
        }
      
       
       public function get_all_quotes()
       {
           if($this->session->has_userdata('logged_in'))
    	    {
    	        $lead_id = $this->input->post("lead_id");
    	        
    	        $res =$this->lm->get_all_quotes($lead_id);
    	        
    	       $html = "";
    	       
    	       foreach($res as $da)
    	       {
    	           
    	           if($da->insurer == "1")
    	           {
    	               $da->insurer = "TATA AIG";
    	           }
    	           else
    	           {
    	               $da->insurer = "RELAINCE GENERAL";
    	           }
    	           $html .="<tr>
    	                     <td><input type='checkbox' class='form-check-input select_checkbox'></td>
    	                     <td>".$da->insurer."</td>
    	                     <td>".$da->total_premium."</td>
    	                     <td>".date_format(date_create($da->policy_s_date),"d-m-Y")."</td>
    	                     <td>".$da->created_user."</td>
    	                     <td><a href='generate_quotation?id=".$da->id."&lead_id=".$da->lead_id."' target='_blank'><i class='fa fa-file-text-o'></i></a></td>
    	                     <td><i class='fa fa-envelope'></i></td>
    	                     <td><i class='fa fa-comment'></i></td>
    	               </tr>";
    	       }
    	       echo $html;
    	    }
       }
       
         
       public function generate_quotation()
       {
           if($this->session->has_userdata('logged_in'))
    	    {
    	        $id = $this->input->get("id");
    	        $lead_id = $this->input->get("lead_id");
    	        
    	        $company_id = 1;
    	        
	            $company_info = $this->lm->fetch_single_company_settings($company_id);
    	        $res = $this->lm->get_basic_informations($lead_id);
    	        $usr_details = $this->lm->get_user_details($this->session->userdata('session_id'));
    	        $quote_details =$this->lm->get_single_quote_details($id);
    	        
    	        $data = "";
    	        
    	        if($res != "")
    	        {
    	            $policy_type = $res->policy_type;
    	            
    	            if($policy_type == "1")
    	            {
    	                  $data = $this->lm->get_car_details($lead_id);  
    	            }
    	            else if($policy_type == "2")
    	            {
    	                  $data = $this->lm->get_bike_details($lead_id); 
    	            }
    	            else if($policy_type == "3")
    	            {
    	                  $data = $this->lm->get_car_details($lead_id);  
    	            }
    	            else if($policy_type == "4")
    	            {
    	                  $data = $this->lm->get_bike_details($lead_id); 
    	            }
    	        }
    	        
    	        $manu_date = "01-".$data->vechi_manu_month."-".$data->vechi_manu_year;
    	        
    	          if($quote_details->insurer == "1")
    	           {
    	               $quote_details->insurer = "TATA AIG";
    	           }
    	           else
    	           {
    	               $quote_details->insurer = "RELAINCE GENERAL";
    	           }
    	        
    	        $content = "<!DOCTYPE html>
                        <html>
                        <head>
                            <title>Generate Quotation : ".$res->client_name." </title>
                            <style>
                                *{
                                    padding:1px;
                                    margin:0px;
                                    font-family: 'Courier';
                                    font-size:12px;
                                }
                            </style>
                        </head>
                        <body style='border:1px solid #aaa;padding:10px;margin: 8px;'>
                        
                      <center><p style='font-size:20px;padding-top:0px;'>Quotation Worksheet For Motor Insurance</p></center>
                       
                       <p style='padding:3px;'><b>Dear, Mr.".$res->client_name."</b></p>
                       
                      <table style='width:100%;padding:20px 2px;padding-top:5px;'>
                                <tr>
                                    <td style='background-color:#dff0d8;padding:5px;width:20%;text-align: left;'>Make & Model</td>
                                    <td style='background-color:#dff0d8;padding:5px;width:20%;text-align: left;'>Registration No</td>
                                    <td style='background-color:#dff0d8;padding:5px;width:20%;text-align: left;'>MFG Year</td>
                                    <td style='background-color:#dff0d8;padding:5px;width:20%;text-align: left;'>Cubic Capacity</td>
                                    <td style='background-color:#dff0d8;padding:5px;width:20%;text-align: left;'>Expiry Date</td>
                                </tr>
                                
                                <tr>
                                    <td style='padding:5px;'>
                                        <p>".$data->brand_name." ".$data->model_name." ".$data->vechi_fuel_type."</p>
                                    </td>
                                     <td style='padding:5px;'>
                                        <p>".$data->vechi_register_no."</p>
                                    </td>
                                    <td style='padding:5px;'>
                                       <p> ".date('M',strtotime($manu_date))." ".date('Y',strtotime($manu_date))."</p>
                                    </td>
                                     <td style='padding:5px;'>
                                       <p>".$quote_details->cubic_capactiy."</p>
                                    </td>
                                    <td style='padding:5px;'>
                                       <p>".date_format(date_create($quote_details->policy_ex_date),"d-m-Y")."</p>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td style='background-color:#dff0d8;padding:5px;width:20%;text-align: left;'>Registration Date</td>
                                    <td style='background-color:#dff0d8;padding:5px;width:20%;text-align: left;'>Engine No</td>
                                    <td style='background-color:#dff0d8;padding:5px;width:20%;text-align: left;'>Chassis No</td>
                                    <td style='background-color:#dff0d8;padding:5px;width:20%;text-align: left;'>Seating Capacity</td>
                                    <td style='background-color:#dff0d8;padding:5px;width:20%;text-align: left;'>Hypothecation</td>
                                </tr>
                                
                                 <tr>
                                    <td style='padding:5px;'>
                                        <p>".date_format(date_create($data->regn_date),"d-m-Y")."</p>
                                    </td>
                                     <td style='padding:5px;'>
                                        <p>".$data->vechi_engine_num."</p>
                                    </td>
                                    <td style='padding:5px;'>
                                       <p> ".$data->vechi_chassis_num."</p>
                                    </td>
                                     <td style='padding:5px;'>
                                       <p>".$data->vechi_seating."</p>
                                    </td>
                                    <td style='padding:5px;'>
                                       <p>".$data->vechi_hypothecation."</p>
                                    </td>
                                </tr>
                      </table>
                     
                      <table style='width:100%;border-spacing: 0px;border-collapse: collapse;margin-top: -17px; !important' border='1'>
                                <tr>
                                    <td style='background-color:#094;width:40%;padding:5px;text-align: left;'> </td>
                                    <td style='background-color:#094;width:60%;color:#fff;padding:5px;text-align: left;'><p><b>".$quote_details->insurer." &nbsp; (".$quote_details->policy_term.")</b><p>
                                 </tr>
                                 
                                  <tr>
                                     <td style='padding:3px;text-align: left;background-color:#dff0d8;'>Insured Declared Value (IDV)</td>
                                     <td style='padding:3px;text-align: right;'></td>
                                 </tr>
                                 
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>IDV</td>
                                     <td style='padding:3px;text-align: right;'>₹".$quote_details->idv."</td>
                                 </tr>
                                 
                                 <tr>
                                     <td style='padding:3px;text-align: left;background-color:#dff0d8;'>Own Damage Premium</td>
                                     <td style='padding:3px;text-align: right;'></td>
                                 </tr>";
                                 
                                 if($quote_details->basic_od_amount != "")
                                 {
                                     $basic_own_damage_premium = "₹".number_format($quote_details->basic_od_amount,2);
                                 }
                                 else
                                 {
                                     $basic_own_damage_premium = "-";
                                 }
                                 
                                 if($quote_details->total_od_premium != "")
                                 {
                                     $tot_od_premium = "₹".number_format($quote_details->total_od_premium,2);
                                 }
                                 else
                                 {
                                     $tot_od_premium = "-";
                                 }
                                 
                                 if($quote_details->basic_tp != "")
                                 {
                                     $basic_tp_premium = "₹".number_format($quote_details->basic_tp,2);
                                 }
                                 else
                                 {
                                     $basic_tp_premium = "-";
                                 }
                                 
                                 if($quote_details->owner_diver_amt != "")
                                 {
                                     $owner_driver_pa_cover = "₹".number_format($quote_details->owner_diver_amt,2);
                                 }
                                 else
                                 {
                                     $owner_driver_pa_cover = "-";
                                 }
                                 
                                 if($quote_details->un_named_passenger_amt != "")
                                 {
                                     $un_named_passenger_pa_cover = "₹".number_format($quote_details->un_named_passenger_amt,2);
                                 }
                                 else
                                 {
                                     $un_named_passenger_pa_cover = "-";
                                 }
                                 
                                 if($quote_details->llp_amt != "")
                                 {
                                     $llp_amt = "₹".number_format($quote_details->llp_amt,2);
                                 }
                                 else
                                 {
                                     $llp_amt = "-";
                                 }
                                 
                                  if($quote_details->tot_tp_premium != "")
                                 {
                                     $tot_tp_premium = "₹".number_format($quote_details->tot_tp_premium,2);
                                 }
                                 else
                                 {
                                     $tot_tp_premium = "-";
                                 }
                                 
                                 
                                 $net_premium = $quote_details->total_od_premium+$quote_details->tot_tp_premium;
                                 $gst_net_premium = $net_premium*18/100;
                                 $tot_policy_premium = $net_premium + $gst_net_premium;
                                 
                                 
                               $content .= "<tr>
                                     <td style='padding:3px;text-align: left;'>Basic Own Damage Premium</td>
                                     <td style='padding:3px;text-align: right;'>".$basic_own_damage_premium."</td>
                                 </tr>
                                  <tr>
                                     <td style='padding:3px;text-align: left;'>No claim Bonus</td>
                                     <td style='padding:3px;text-align: right;'>-</td>
                                 </tr>
                                 
                                  <tr>
                                     <td style='padding:3px;text-align: left;background-color:#094;color:#fff;'><b>Total Own Damage Premium (A)</b></td>
                                     <td style='padding:3px;text-align: right;background-color:#094;color:#fff;'><b>".$tot_od_premium."</b></td>
                                 </tr>
                                 
                                 <tr>
                                     <td style='padding:3px;text-align: left;background-color:#dff0d8;'><b>Third Party Premium</b></td>
                                     <td style='padding:3px;text-align: right;'></td>
                                 </tr>
                                 
                                  <tr>
                                     <td style='padding:3px;text-align: left;'>Basic Third Party Premium</td>
                                     <td style='padding:3px;text-align: right;'>".$basic_tp_premium."</td>
                                 </tr>
                                 
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Owner Driver PA Cover</td>
                                     <td style='padding:3px;text-align: right;'>".$owner_driver_pa_cover."</td>
                                 </tr>
                                 
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Unnamed Passenger PA Cover</td>
                                     <td style='padding:3px;text-align: right;'>".$un_named_passenger_pa_cover."</td>
                                 </tr>
                                 
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Legal Libility To Be Paid Drv / Emp</td>
                                     <td style='padding:3px;text-align: right;'>".$llp_amt."</td>
                                 </tr>
                                 
                                  <tr>
                                     <td style='padding:3px;text-align: left;background-color:#094;color:#fff;'><b>Total Third Party Premium (B)</b></td>
                                     <td style='padding:3px;text-align: right;background-color:#094;color:#fff;'><b>".$tot_tp_premium."</b></td>
                                 </tr>
                                 
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Net Premium (A+B)</td>
                                     <td style='padding:3px;text-align: right;'>₹".number_format($net_premium,2)."</td>
                                 </tr>
                                 
                                  <tr>
                                     <td style='padding:3px;text-align: left;'>Gst (18%)</td>
                                     <td style='padding:3px;text-align: right;'>₹".number_format($gst_net_premium,2)."</td>
                                 </tr>
                                 
                                 <tr>
                                     <td style='padding:3px;text-align: left;background-color:#094;color:#fff;'><b>".$quote_details->policy_co_cover_type." Policy premium</b></td>
                                     <td style='padding:3px;text-align: right;background-color:#094;color:#fff;'><b>₹".number_format($tot_policy_premium,2)."</b></td>
                                 </tr>
                                 
                                 <tr>
                                     <td style='padding:3px;text-align: left;background-color:#dff0d8;'><b>Add On Covers premium</b></td>
                                     <td style='padding:3px;text-align: right;'></td>
                                 </tr>
                                 
                                  <tr>
                                     <td style='padding:3px;text-align: left;'>Add On Plan</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->q_add_on_combo_premium."</td>
                                  </tr>";
                                  
                                  if($quote_details->q_add_on_plan_premium_amt != "")
                                  {
                                      $add_on_plan_premium = "₹".number_format($quote_details->q_add_on_plan_premium_amt,2);
                                  }
                                  else
                                  {
                                      $add_on_plan_premium = "-";
                                  }
                                  
                                  if($quote_details->q_zero_depreciation_amt != "")
                                  {
                                       $zero_depreciation_amt = "₹".number_format($quote_details->q_zero_depreciation_amt,2);
                                  }
                                  else
                                  {
                                      $zero_depreciation_amt = "-";
                                  }
                                  
                                  if($quote_details->q_addtional_addons_amt != "")
                                  {
                                       $q_addtional_addons_amt = "₹".number_format($quote_details->q_addtional_addons_amt,2);
                                  }
                                  else
                                  {
                                      $q_addtional_addons_amt = "-";
                                  }
                                  
                                  if($quote_details->q_consumbles_amt != "")
                                  {
                                       $q_consumbles_amt = "₹".number_format($quote_details->q_consumbles_amt,2);
                                  }
                                  else
                                  {
                                      $q_consumbles_amt = "-";
                                  }
                                  
                                  if($quote_details->q_tyre_cover_amt != "")
                                  {
                                       $q_tyre_cover_amt = "₹".number_format($quote_details->q_tyre_cover_amt,2);
                                  }
                                  else
                                  {
                                      $q_tyre_cover_amt = "-";
                                  }
                                  
                                  if($quote_details->q_ncb_protection_amt != "")
                                  {
                                       $q_ncb_protection_amt = "₹".number_format($quote_details->q_ncb_protection_amt,2);
                                  }
                                  else
                                  {
                                      $q_ncb_protection_amt = "-";
                                  }
                                  
                                  if($quote_details->q_engine_protector_amt != "")
                                  {
                                       $q_engine_protector_amt = "₹".number_format($quote_details->q_engine_protector_amt,2);
                                  }
                                  else
                                  {
                                      $q_engine_protector_amt = "-";
                                  }
                                  
                                   if($quote_details->q_return_to_invoice_amt != "")
                                  {
                                       $q_return_to_invoice_amt = "₹".number_format($quote_details->q_return_to_invoice_amt,2);
                                  }
                                  else
                                  {
                                      $q_return_to_invoice_amt = "-";
                                  }
                                  
                                  if($quote_details->key_replacement_amt != "")
                                  {
                                       $key_replacement_amt = "₹".number_format($quote_details->key_replacement_amt,2);
                                  }
                                  else
                                  {
                                      $key_replacement_amt = "-";
                                  }
                                  
                                  if($quote_details->daily_allow_amt != "")
                                  {
                                       $daily_allow_amt = "₹".number_format($quote_details->daily_allow_amt,2);
                                  }
                                  else
                                  {
                                      $daily_allow_amt = "-";
                                  }
                                  
                                  if($quote_details->loss_of_belong_amt != "")
                                  {
                                       $loss_of_belong_amt = "₹".number_format($quote_details->loss_of_belong_amt,2);
                                  }
                                  else
                                  {
                                      $loss_of_belong_amt = "-";
                                  }
                                  
                                   if($quote_details->hotel_trvl_amt != "")
                                  {
                                       $hotel_trvl_amt = "₹".number_format($quote_details->hotel_trvl_amt,2);
                                  }
                                  else
                                  {
                                      $hotel_trvl_amt = "-";
                                  }
                                  
                                  
                                  if($quote_details->wind_shield_amt != "")
                                  {
                                       $wind_shield_amt = "₹".number_format($quote_details->wind_shield_amt,2);
                                  }
                                  else
                                  {
                                      $wind_shield_amt = "-";
                                  }
                                  
                                $content .="<tr>
                                     <td style='padding:3px;text-align: left;'>Add On Plan Premium</td>
                                     <td style='padding:3px;text-align: right;'>".$add_on_plan_premium."</td>
                                  </tr>
                                 </table>";
                                  
                             $content .="<table style='width:100%;border-spacing:0px;border-collapse:collapse;!important' border='1'>
                                <tr>
                                    <td style='background-color:#dff0d8;width:40%;padding:5px;text-align: left;'><b>Add On Plan Details</b> </td>
                                    <td style='background-color:#dff0d8;width:20%;padding:5px;text-align: center;'></td>
                                    <td style='background-color:#dff0d8;width:40%;padding:5px;text-align: center;'></td>
                                 </tr>
                                 
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Zero Depreciation</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->q_zero_depreciation_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$zero_depreciation_amt."  </td>
                                </tr>
                                
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>RSA/Additional For Addons</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->q_addtional_addons_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$q_addtional_addons_amt."  </td>
                                </tr>
                                
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Consumbles</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->q_consumbles_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$q_consumbles_amt."  </td>
                                </tr>
                                
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Tyre Cover</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->q_tyre_cover." </td>
                                     <td style='padding:3px;text-align: right;'>".$q_tyre_cover_amt."  </td>
                                </tr>
                                
                                <tr>
                                     <td style='padding:3px;text-align: left;'>NCB Protection</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->q_ncb_protection_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$q_ncb_protection_amt."  </td>
                                </tr>
                                
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Engine Protector</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->q_engine_protector_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$q_engine_protector_amt."  </td>
                                </tr>
                                
                                <tr>
                                     <td style='padding:3px;text-align: left;'>Return To Invoice</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->q_return_to_invoice_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$q_return_to_invoice_amt."  </td>
                                </tr>
                                
                                <tr>
                                     <td style='padding:3px;text-align: left;'>Key And Lock Replacement</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->key_replacement_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$key_replacement_amt."  </td>
                                </tr>
                                
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Daily/Inconvinience Allowance</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->daily_allow_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$daily_allow_amt."  </td>
                                </tr>
                                
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Loss of Personal Blonggies</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->loss_of_belong_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$loss_of_belong_amt."  </td>
                                </tr>
                                
                                 <tr>
                                     <td style='padding:3px;text-align: left;'>Loss of Hotel & Travel Expenses</td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->hotel_trvl_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$hotel_trvl_amt."  </td>
                                </tr>
                                
                                <tr>
                                     <td style='padding:3px;text-align: left;'>Repair Glass Fiber Plastic </td>
                                     <td style='padding:3px;text-align: center;'>".$quote_details->wind_shield_check." </td>
                                     <td style='padding:3px;text-align: right;'>".$wind_shield_amt."  </td>
                                </tr>
                                
                                <tr>
                                     <td style='padding:3px;text-align: left;'>Zero Depreciation Allowed / Year </td>
                                     <td style='padding:3px;text-align: center;' colspan='2'>2</td>
                                </tr>
                                
                                 <tr>
                                     <td style='padding:3px;text-align: left;'><b>Total Add On Cover Premium (C) </b></td>
                                     <td style='padding:3px;text-align: right;' colspan='2'>₹".number_format($quote_details->tot_add_on_cover_premium,2)." </td>
                                </tr>
                                
                                <tr>
                                     <td style='padding:3px;text-align: left;background-color:#094;color:#fff;'><b>Total Premium (A+B+C) </b></td>
                                     <td style='padding:3px;text-align: right;background-color:#094;color:#fff;' colspan='2'><b>₹".$quote_details->total_premium."</b></td>
                                </tr>
                                
                                <tr>
                                     <td style='padding:3px;text-align: left;'>GST (18%)</td>
                                     <td style='padding:3px;text-align: right;' colspan='2'>₹".$quote_details->gst." </td>
                                </tr>
                                
                                <tr>
                                     <td style='padding:3px;text-align: left;background-color:#094;color:#fff;'><b>Total Premium Payable</b></td>
                                     <td style='padding:3px;text-align: right;background-color:#094;color:#fff;' colspan='2'><b>₹".$quote_details->total_payable."</b></td>
                                </tr>
                                 </table>";
    	                      $content .="<p style='padding:3px;'><b>Warm Regards,</b></p>
    	                      <p style='padding:3px;'>".$this->session->userdata('session_name')."</p>
    	                      <p style='padding:3px;'>Jayantha Insurance</p>
    	                      <p style='padding:3px;'>".$usr_details->phoneno.".</p>
    	                      <br>
    	                      <p style='padding:3px;text-align:center;'><i>".$company_info->address."</i></p>";
    	        //echo $content;
            	    $this->load->library('pdf');
                	$this->pdf->loadHtml($content);
                	$this->pdf->render();
                	$this->pdf->stream("Quotation".$id.".pdf", array("Attachment" => false));
    	    }
       }
       
       public function add_pet_details()
       {
            if($this->session->has_userdata('logged_in'))
    	    {
    	        $lead_id = $this->input->post("lead_id");
    	        $pet_gender = $this->input->post("pet_gender");
    	        $pet_name = $this->input->post("pet_name");
    	        $pet_age = $this->input->post("pet_age");
    	        $pet_height = $this->input->post("pet_height");
    	        $pet_weight = $this->input->post("pet_weight");
    	        
    	        $get_policy_type= $this->lm->get_policy_type_by_lead_id($lead_id);
    	       
    	       $data = array(  
    	                       "lead_id" => $lead_id,
                    	       "policy_type"=>$get_policy_type->policy_type,
                    	       "gender"=>$pet_gender,
                    	       "name"=>$pet_name,
                    	       "age_in_months"=>$pet_age,
                    	       "height_in_ft"=>$pet_height,
                    	       "weight_in_kg" =>$pet_weight,
                    	       "created_by"=>$this->session->userdata('session_id'),
    	       ); 
    	       
    	       $res = $this->lm->add_pet_details($data);
    	       
    	       $array = $this->lm->get_pet_details($res);
    	       echo json_encode($array);
    	       
    	    }
       }
       
       public function get_pet_details()
       {
           if($this->session->has_userdata('logged_in'))
    	    {
    	        $lead_id = $this->input->post("lead_id");
    	        $array = $this->lm->get_pet_details_by_lead_id($lead_id);
    	        echo json_encode($array);
    	    }
       }
       
    public function add_home_property()
	{
	    if($this->session->has_userdata('logged_in'))
    	    {
    	        $lead_id = $this->input->post("lead_id");
        	     $house_type = $this->input->post("house_type");
        	     $owner_type = $this->input->post("owner_type");
        	     $home_policy_tenure = $this->input->post("home_policy_tenure");
        	     $home_age_premises = $this->input->post("home_age_premises");
        	     $home_name = $this->input->post("home_name");
        	     $home_mobile = $this->input->post("home_mobile");
        	     $home_property_value = $this->input->post("home_property_value");
        	     $home_sqft = $this->input->post("home_sqft");
        	     $home_infuli = $this->input->post("home_infuli");
        	     $home_dgairmac = $this->input->post("home_dgairmac");
        	   
        	     $get_policy_type= $this->lm->get_policy_type_by_lead_id($lead_id);
        	     
        	   $data = array(
        	       "lead_id" => $lead_id,
        	       "policy_type" => $get_policy_type->policy_type,
        	       "house_type" => $house_type,
        	       "owner_type" => $owner_type,
        	       "home_policy_tenure" => $home_policy_tenure,
        	       "home_age_premises" => $home_age_premises,
        	       "home_property_value" => $home_property_value,
        	       "home_sqft" => $home_sqft,
        	       "home_interior" => $home_infuli,
        	       "home_ac" => $home_dgairmac,
        	       "created_by" =>$this->session->userdata('session_id'),
        	       "created_at" => date("Y-m-d H:i:s"),
        	       );
        	   $res = $this->lm->add_home_details($data);
        	   $get_home_details = $this->lm->get_home_details($res);
        	   echo json_encode($get_home_details);
                
    	    }
	}
	
	public function add_business_details()
	{
	    if($this->session->has_userdata('logged_in'))
    	 {
    	 $lead_id = $this->input->post("lead_id");
	     $business_profession = $this->input->post("business_profession");
	     $business_owner_type = $this->input->post("business_owner_type");
	     $business_age_premises = $this->input->post("business_age_premises");
	     $business_property_value = $this->input->post("business_property_value");
	     $business_sqft = $this->input->post("business_sqft");
	     $business_infuli = $this->input->post("business_infuli");
	     $business_dgairmac = $this->input->post("business_dgairmac");
	   
	     $get_policy_type= $this->lm->get_policy_type_by_lead_id($lead_id);
	     
        	   $data = array(
        	       "lead_id" => $lead_id,
        	       "owner_type" =>$business_owner_type,
        	       "policy_type" => $get_policy_type->policy_type,
        	       "profession" => $business_profession,
        	       "business_age_premises" => $business_age_premises,
        	       "business_property_value" => $business_property_value,
        	       "business_sqft" => $business_sqft,
        	       "business_interior" => $business_infuli,
        	       "business_ac" => $business_dgairmac,
        	       "created_by" => $this->session->userdata('session_id'),
        	       "created_at" => date("Y-m-d H:i:s"),
        	       );
	            $res = $this->lm->add_business_details($data);
	            
	            $array = $this->lm->get_business_details($res);
	            
	            echo json_encode($array);
    	 }
	}
	
	public function get_business_details()
	{
	    if($this->session->has_userdata('logged_in'))
    	 {
    	     $lead_id = $this->input->post("lead_id");
    	     $res = $this->lm->get_business_details_by_lead_id($lead_id);
    	     echo json_encode($res);
    	 }
	}
	
	public function get_home_details()
	{
	     if($this->session->has_userdata('logged_in'))
    	 {
    	      $lead_id = $this->input->post("lead_id");
    	      $res = $this->lm->get_home_details_by_lead_id($lead_id);
    	      echo json_encode($res);
    	 }
	}
	
	public function commodity_change_load_sub_commodity()
	{
	     if($this->session->has_userdata('logged_in'))
    	 {
        	    $commodity = $this->input->post("commodity");
        	    $res = $this->lm->commodity_change_load_sub_commodity($commodity);
        	    $option = "<option value=''>Select Sub Commodity</option>";
        	    foreach($res as $r)
        	    {
        	        $option.="<option value='".$r->id."'>".$r->name."</option>";
        	    }
        	    echo $option;
        	}
	}
	
	public function marine_submit()
	{
	     if($this->session->has_userdata('logged_in'))
    	 {
    	         $lead_id = $this->input->post("lead_id");
        	     $marine_company_name = $this->input->post("marine_company_name");
        	     $marine_city_name = $this->input->post("marine_city_name");
        	     $marine_transport = $this->input->post("marine_transport");
        	     $marine_cummodity = $this->input->post("marine_cummodity");
        	     $marine_sub_cummodity = $this->input->post("marine_sub_cummodity");
        	     $marine_invoice_val = $this->input->post("marine_invoice_val");
        	     $marine_invoice_10per_val = $this->input->post("marine_invoice_10per_val");
        	     $marine_type = $this->input->post("marine_type");
        	    
        	   $arr = array(
        	       "lead_id" => $lead_id,
        	       "company_name" => $marine_company_name,
        	       "city_name" => $marine_city_name,
        	       "policy_type" => 24,
        	       "transport_mode" => $marine_transport,
        	       "commodity" => $marine_cummodity,
        	       "sub_commodity" => $marine_sub_cummodity,
        	       "invoice_value" => $marine_invoice_val,
        	       "sum_invoice" => $marine_invoice_10per_val,
        	       "type" => $marine_type,
        	       "created_by" => $this->session->userdata('session_id'),
        	       "created_at" => date("Y-m-d H:i:s"),
        	       );
        	       
        	   $res = $this->lm->add_marine_details($arr);
        	   
        	   $get_maraine_details = $this->lm->get_maraine_details($res);
        	   $commodity = $get_maraine_details->commodity;
        	   $sub_commodity = $this->lm->commodity_change_load_sub_commodity($commodity);
        	   $option = "";
        	    
        	    foreach($sub_commodity as $r)
        	    {
        	        $option.="<option value='".$r->id."'>".$r->name."</option>";
        	    }
        	   $datas =  array("maraine_details"=>$get_maraine_details,"sub_commodity" =>$option);
        	   echo json_encode($datas);
              
    	 }
	}
	
	public function get_maraine_details()
	{
	    if($this->session->has_userdata('logged_in'))
    	 {
    	       $lead_id = $this->input->post("lead_id");
    	       $get_maraine_details = $this->lm->get_maraine_details_by_lead_id($lead_id);
        	   $commodity = $get_maraine_details->commodity;
        	   $sub_commodity = $this->lm->commodity_change_load_sub_commodity($commodity);
        	   
        	   $option = "";
        	    
        	    foreach($sub_commodity as $r)
        	    {
        	        $option.="<option value='".$r->id."'>".$r->name."</option>";
        	    }
        	   $datas =  array("maraine_details"=>$get_maraine_details,"sub_commodity" =>$option);
        	   echo json_encode($datas);
    	 }
	}
	
	// policy 
	
	public function get_policy_type()
	{
	    if($this->session->has_userdata('logged_in'))
    	 {
    	     $lead_id = $this->input->post("lead_id");
    	     $res = $this->lm->get_policy_type($lead_id);
    	     echo json_encode($res);
    	 }
	}
	
	
	// Renewal //
	
	public function renewal()
	{
	    if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
    	{    		
		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
		   	$data["users"] = $this->lm->fetch_users();
		   	$data["agents_pos"] = $this->lm->fetch_agents_pos();
		   	$data["policy_type"] = $this->lm->fetch_list_of_policy_type_motor();
		   	$data["client_type"] = $this->lm->fetch_client_type();
		   	$data["business"] = $this->lm->fetch_business_type();
		   	$data["class"] = $this->lm->fetch_list_of_class();
		   	
    		$this->load->view('header',$pro_data);
    		$this->load->view('renewal',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else if($this->session->has_userdata('logged_in') && ($this->session->userdata('session_role') == "user" || $this->session->userdata('session_role') == "AI"))
	    {
	        $pro_data["project_info"] = $this->mm->fetch_project_info();
	        $data["agents_pos"] = $this->lm->fetch_agents_pos();
	        $data["users"] = $this->lm->fetch_users();
	        $data["client_type"] = $this->lm->fetch_client_type();
	        $data["business"] = $this->lm->fetch_business_type();
	        $data["class"] = $this->lm->fetch_list_of_class();
	        $data["policy_type"] = $this->lm->fetch_list_of_policy_type_motor();
    		$this->load->view('header',$pro_data);
    		$this->load->view('renewal',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else
	    {
	    	redirect("login");
	    }
	}
	
	
	public function get_client_details_by_lead_id()
	{
	    if($this->session->has_userdata('logged_in')) 
    	{
    	    $lead_id = $this->input->post("lead_id");
    	    $res = $this->lm->get_client_details_by_lead_id($lead_id);
    	    echo json_encode($res);
    	}
	}
	
	public function add_renewal_lead_details()
	{
	    if($this->session->has_userdata('logged_in')) 
    	{
    	    $lead_id = $this->input->post("lead_id");
    	    $get_client_id = $this->lm->get_client_id($lead_id);
	        $bussiness_type = $this->input->post("bussiness_type");
	        $class = $this->input->post("policy_class");
	        $policy_type = $this->input->post("policy_type");
	        $lead_generated_date =  $this->input->post("lead_generated_date");
	        $due_date =  $this->input->post("due_date");
	        $broken_policy =  $this->input->post("broken_policy");
	        $location=  $this->input->post("location");
	        $classification =  $this->input->post("classification");
	        $source =  $this->input->post("source");
	        $agent_pos = $this->input->post("agent_pos");
	        $assign_to_user =  $this->input->post("assign_to_user");
	        $remarks = $this->input->post("remarks");
	        $lead_created_by = $this->session->userdata('session_name');
	        $created_date = date("Y-m-d H:i:sa");
	        $updated_date = date("Y-m-d H:i:sa");
	        
	        $client_id = $get_client_id->client_id;
	        
	        $arr = array( 
    	             "client_id" =>$client_id,
    	             "business_type" =>$bussiness_type,
    	             "class"=>$class,
    	             "policy_type" => $policy_type,
    	             "lead_generated_date" => $lead_generated_date,
    	             "due_date" =>$due_date,
    	             "broken_policy" => $broken_policy,
    	             "location" =>$location,
    	             "classfication" =>$classification,
    	             "source"=>$source,
    	             "lead_status"=>"open",
    	             "agency_and_pos" => $agent_pos,
    	             "assigned_user" => $assign_to_user,
    	             "remarks" =>$remarks,
    	             "lead_created_by" =>$lead_created_by,
    	             "created_date"=>$created_date,
    	             "updated_date"=>$updated_date
    	             );
    	     $data_1 = $this->lm->add_lead_details($arr);
    	     
    	     $date = date("Y-m-d");
    	     
    	     if($class == "1")
    	     {
    	         $res = $this->lm->add_motor_details($lead_id,$data_1,$date);
    	     }
    	     else if($class == "2")
    	     {
    	         $res = $this->lm->add_renew_health_details($lead_id,$data_1,$date);
    	     }
    	     else if($class == "4")
    	     {
    	         if($policy_type == "22")
    	         {
    	             $res = $this->lm->add_renew_health_details($lead_id,$data_1,$date);
    	         }
    	         else
    	         {
    	             $res = $this->lm->add_renew_business_details($lead_id,$data_1,$date);
    	         }
    	         
    	     }
    	     else if($class == "5")
    	     {
    	         $res = $this->lm->add_renew_maraine_details($lead_id,$data_1,$date);
    	     }
    	     else if($class == "4")
    	     {
    	         
    	     }
    	     
    	    $re_status = array("status"=>"1");
    	     
    	   $renewal_status = $this->lm->update_renewal_status($re_status,$lead_id);
    	     
    	   echo "success";
    	}
	}
	
	
	// lead details 
	
	public function view_lead_details()
	{
	    if($this->session->has_userdata('logged_in')) 
    	{
    	    $lead_id = $this->input->post("id");
    	    $res = $this->lm->view_lead_details($lead_id);
    	    $data = $this->lm->get_vechicle_details($lead_id);
    	    $client_id = $res->client_id;
    	    $get_leads_id = $this->lm->get_leads_id($client_id);
    	    
    	    
            $html = "";
            $content_1 = "";
            $v_info = [];
            
            if($data != null)
            {
                if($data->policy_type == "1" && $data->policy_type == "3")
                {
                  $v_info = $this->lm->get_car_details($lead_id);  
                }
                else if($data->policy_type == "2" && $data->policy_type == "4")
                {
                    $v_info = $this->lm->get_bike_details($lead_id);  
                }
                else if($data->policy_type == "7" || $data->policy_type == "12" || $data->policy_type == "13" || $data->policy_type == "14" || $data->policy_type == "59" || $data->policy_type == "60" || $data->policy_type == "65" || $data->policy_type == "66" || $data->policy_type == "68" || $data->policy_type == "69" || $data->policy_type == "70")
                {
                	$v_info = $this->lm->get_pc_details($lead_id,$data->policy_type);
                }
                else if($data->policy_type == "8" || $data->policy_type == "9" || $data->policy_type == "10" || $data->policy_type == "15" || $data->policy_type == "16" || $data->policy_type == "61")
                {
                	$v_info = $this->lm->get_gc_details($lead_id,$data->policy_type);
                }
                else if($data->policy_type == "20")
                {
                	$v_info = $this->lm->fetch_make_misc($lead_id);
                }
                else if($data->policy_type == "55")
                {
                	$v_info = $this->lm->fetch_make_scooter($lead_id);
                }
            }
            
            if($res->class == "1")
            {
                $html .="<h4 style='color:#2196f3;font-family: system-ui;'><u>Vehicle Documents</u></h4><div class='row'>";
            
                foreach($get_leads_id as $da)
                {
                      $documents = $this->lm->get_vechile_documents($da->id);
                      
                      foreach($documents as $doc)
                      {
                          $html .= "<div class='col-md-3'><div class='form-group'><a href='./datas/documents/".$doc->document_file."' target='_blank'><i class='fa fa-file-pdf-o' style='font-size:48px;color:red'></i></a></div></div>";
                      }
                }
                $html .="</div>";
            }
            else if($res->class == "10")
            {
                $content_1 .="<h4 style='color:#2196f3;font-family: system-ui;'><u>Policy Quotations</u></h4><div class='row'>";
                
                foreach($get_leads_id as $da)
                {
                      $documents = $this->lm->fetch_quote_files($da->id);
                      
                      foreach($documents as $doc)
                      {
                          $content_1 .= "<div class='col-md-3'><div class='form-group'><a href='./datas/documents/".$doc->file."' target='_blank'><i class='fa fa-file-pdf-o' style='font-size:48px;color:red'></i></a></div><span>&nbsp;".$doc->file_name."</span></div>";
                      }
                }
                
                $content_1 .="</div>";
            }
            
            $content = "";
            $policy_info = $this->lm->get_temp_policy_informations($lead_id);
            
            $content .="<div class='row'>";
            
            foreach($policy_info as $p)
            {
                $content .="<h4 style='color:#2196f3;font-family: system-ui;margin-left:15px;'><u>Policy Details - ".$p->business_name." </u></h4><div class='col-md-6'>
                             <div class='row'>
                                   <div class='col-md-4'>
                                    <label>Policy No  </label>
                                    </div>
                                    <div class='col-md-1'> :
                                    </div>
                                   <div class='col-md-7'>
                                       <p>".$p->policy_no."</p>
                                   </div>
                                 </div>
                               </div>
                               
            	               <div class='col-md-6'>
                	               <div class='row'>
                                       <div class='col-md-4'>
            	                          <label>Insurer Name</label>
            	                        </div>
            	                        <div class='col-md-1'> :</div>
                                   <div class='col-md-7'>
                                    <p>".$p->company_name."</p>
                                  </div>
                                 </div>
                               </div>
                               
                               <div class='col-md-6'>
                	               <div class='row'>
                                       <div class='col-md-4'>
                                          <label>Business Type</label>
                                      </div>
            	                        <div class='col-md-1'> :</div>
                	                   <div class='col-md-7'>
            	                          <p>".$p->business_name."</p>
            	                      </div>
                                 </div>
                               </div>
                               
                               
                               <div class='col-md-6'>
                	               <div class='row'>
                                       <div class='col-md-4'>
                                          <label>Premium Cover</label>
                                      </div>
            	                        <div class='col-md-1'> :</div>
                	                   <div class='col-md-7'>
            	                          <p>".$p->policy_premium_name."</p>
            	                      </div>
                                 </div>
                             </div>
                    
                               <div class='col-md-6'>
                	               <div class='row'>
                                       <div class='col-md-4'>
                                         <label>Class</label>
                                        </div>
                                         <div class='col-md-1'> :</div>
            	                    <div class='col-md-7'>
                                    <p>".$p->class_name."</p>
                                   </div>
                                 </div>
                               </div>
                               
                              <div class='col-md-6'>
                	               <div class='row'>
                                       <div class='col-md-4'>
                                            <label>Policy Type</label>
                                       </div>
                                      <div class='col-md-1'> :</div>
            	                    <div class='col-md-7'>
                                       <p>".$p->policy_type."</p>
                                    </div>
                                 </div>
                               </div>
                               
                               
                               <div class='col-md-6'>
                	               <div class='row'>
                                       <div class='col-md-4'>
                                          <label>Policy Start Date</label>
                                         </div>
                                     <div class='col-md-1'> :</div>
            	                       <div class='col-md-7'>
                                         <p>".date_format(date_create($p->policy_s_date),"d-M-Y")."</p>
                                  </div>
                                 </div>
                               </div>
                               
                               <div class='col-md-6'>
                	               <div class='row'>
                                       <div class='col-md-4'>
                                          <label>Policy Exp Date</label>
                                         </div>
                                     <div class='col-md-1'> :</div>
            	                       <div class='col-md-7'>
                                         <p>".date_format(date_create($p->policy_ex_date),"d-M-Y")."</p>
                                  </div>
                                 </div>
                               </div>
                               
                                <div class='col-md-6'>
                	               <div class='row'>
                                       <div class='col-md-4'>
                                          <label>Sum Insured</label>
                                         </div>
                                     <div class='col-md-1'> :</div>
            	                       <div class='col-md-7'>
                                         <p>".number_format($p->sum_insured,2)."</p>
                                  </div>
                                 </div>
                               </div>";
                               
                                  if($res->class == "1")
            	                   {
                    	                   $content .="<div class='col-md-6'>
                                	               <div class='row'>
                        	                           <div class='col-md-4'>
                        	                              <label>Total Own Damage</label>
                        	                             </div>
                        	                         <div class='col-md-1'> :</div>
                                	                   <div class='col-md-7'>
                            	                        <p>".number_format($p->total_own_damage,2)."</p>
                            	                       </div>
                        	                     </div>
                    	                       </div>
                    	                       
                    	                            
                    	                    <div class='col-md-6'>
                            	               <div class='row'>
                    	                           <div class='col-md-4'>
                    	                              <label>Total Tp</label>
                    	                           </div>
                    	                        <div class='col-md-1'> :</div>
                        	                       <div class='col-md-7'>
                    	                        <p>".number_format($p->basic_tp,2)."</p>
                    	                       </div>
                    	                     </div>
                	                       </div>";
            	                       }
                               
                    $content .=" <div class='col-md-6'>
                	               <div class='row'>
                                       <div class='col-md-4'>
                                           <label>Net Premium </label>
                                        </div>
                                    <div class='col-md-1'> :</div>
            	                       <div class='col-md-7'>
                                    <p>".number_format($p->total_premium,2)."</p>
                                  </div>
                                 </div>
                               </div>
                               
                               <div class='col-md-6'>
                	               <div class='row'>
                                     <div class='col-md-4'>
                                         <label>GST</label>
                                    </div>
                                    <div class='col-md-1'> :</div>
            	                       <div class='col-md-7'>
                                    <p>".number_format($p->gst,2)."</p>
                                   </div>
                                 </div>
                               </div>
                               
                               <div class='col-md-6'>
                	               <div class='row'>
                                     <div class='col-md-4'>
                                         <label>Agent/ Pos Code </label>
                                    </div>
                                    <div class='col-md-1'> :</div>
            	                       <div class='col-md-7'>
                                    <p>".$p->agent_pos_code."</p>
                                   </div>
                                 </div>
                               </div>
                               <hr/>";
            }
            
             $content .="</div>";
             
            $policy_docs ="<h4 style='color:#2196f3;font-family: system-ui;'><u>Policy Documents</u></h4>";
            
            $policy_docs .="<div class='row'>";
            
                  $documents = $this->lm->get_policy_documents($lead_id);
                  
                  foreach($documents as $doc)
                  {
                      $policy_docs .= "<div class='col-md-3'><div class='form-group'><a href='./datas/documents/".$doc->document."' target='_blank'><i class='fa fa-file-pdf-o' style='font-size:48px;color:red'></i></a></div></div>";
                  }
            $policy_docs .="</div>";
            echo json_encode(array("p_info"=>$res,"v_info" =>$v_info,"docs"=>$html,"sme_quote" =>$content_1,"policy_info"=>$content,"policy_docs" =>$policy_docs));
    	}
	}
	
	
	  public function check_commission_status()
      {
            if($this->session->has_userdata('logged_in')) 
        	{
        	    $check_user_i = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));
        	     
        	    if($check_user_i->policy_add == "1")
    	        {   
                    $policy_no = $this->input->post("policy_no");
                    $policy_source = $this->input->post("policy_source");
                    $policy_issue_date = $this->input->post("policy_issue_date");
                    $lead_created_by = $this->session->userdata('session_name');
                    $policy_premium= $this->input->post("policy_premium");
                    $policy_agency_pos = $this->input->post("policy_agency_pos");
                    $company = $this->input->post("company");
                    $total_premium =$this->input->post("total_premium");
                    $lead_id = $this->input->post("lead_id");
                    
                    $rto = "";
                    $age = "";
                    $lead_id = $this->input->post("lead_id");
                    $class_type = $this->lm->get_class_type($lead_id);
                    
                    $from_date_1 = date_format(date_create($policy_issue_date),"01-m-Y");
                    $to_date_1 = date_format(date_create($from_date_1),"t-m-Y");
                            
                   
                   if($class_type->class == "1")
                   {
                            $get_lead_info = $this->lm->get_lead_info($lead_id);
                            $bussiness_type = $get_lead_info->business_type;
                            $policy_class = $get_lead_info->class;
                            $policy_type =  $get_lead_info->policy_type;
                            $state = $get_lead_info->state;
                            $rto = $get_lead_info->rto;
                            $regndate =$get_lead_info->regn_date;
                            $today = date("Y-m-d");
                            $diff = date_diff(date_create($regndate), date_create($today));
                            $age = $diff->format('%y');
                            $fuel_type = $get_lead_info->vechi_fuel_type;
                            $cc  = $get_lead_info->vechi_cc;
                            $v_gvw = $get_lead_info->vechi_gvw;
                            $v_seating = $get_lead_info->passenger_carrying;
                            $make = $get_lead_info->vechi_make;
                            $model = $get_lead_info->vechi_model;
                            $Varient = $get_lead_info->vechi_varient;
                            
                           
                            $commission_id = [];
                            
                            $status = "0";
                            $make_status = "0";
                            $model_status = "0";
                            $varient_status = "0";
                            $rto_status = "0";
                            $gvw_status = "0";
                            $fuel_status = "0";
                            $state_status = "0";
                            $fuel_type_status = "0";
                            
                            $data1 = array("status" =>"Commission Slab Not Exits","commission_id"=>"");
                            
                            $check = $this->cm->check_commission($company,$policy_premium,$policy_class,$bussiness_type,$policy_type,$state,$from_date_1,$to_date_1);
                             
                            foreach($check as $da)
                            {
                                if($da->commission_type == "2")
                                {
                                    foreach($check as $da)
                                	{
                                            $temp_min = $da->vehicle_age_min;
                                            $temp_max = $da->vehicle_age_max;
                                            $g_status = "0";
                                            $fuel_status = "0";
                            		    
                                    	    if($temp_min <= $age && $temp_max >= $age)
                                    		{
                                    			$g_status = "1";
                                    		}
                                    		
                                            if($fuel_type == "1")
                                            {
                                            	if($da->fuel_type == "4" || $da->fuel_type == "5" || $da->fuel_type == "1" || $da->fuel_type == "6")
                                            	{
                                            	    $fuel_status = "1";
                                            	}
                                            }
                                            if($fuel_type == "2")
                                            {
                                                if($da->fuel_type == "5" || $da->fuel_type == "2" || $da->fuel_type == "6")
                                            	{
                                            	    $fuel_status = "1";
                                            	}
                                            }
                                            if($fuel_type == "5")
                                            {
                                                if($da->fuel_type == "5" || $da->fuel_type == "1" || $da->fuel_type == "2" || $da->fuel_type == "6")
                                            	{
                                            	    $fuel_status = "1";
                                            	}
                                            }
                                            if($fuel_type == "6")
                                            {
                                                if($da->fuel_type == "1" || $da->fuel_type == "2" || $da->fuel_type == "3" || $da->fuel_type == "4" || $da->fuel_type == "5" || $da->fuel_type == "6")
                                            	{
                                            	    $fuel_status = "1";
                                            	}
                                            }
                                            if($fuel_type == "7")
                                            {
                                                if($da->fuel_type == "7" || $da->fuel_type == "6")
                                            	{
                                            	    $fuel_status = "1";
                                            	}
                                            }
                                		   
                                			if($g_status == "1" && $fuel_status == "1")
                                			{
                                			    $commission_id[] = $da->id;
                                			    $status = "1";
                                                $fuel_type_status = "1";
                                			}
                            	      }
                            	      
                                    if($status == "1")
                                    {
                                        $check_state = $this->cm->check_state_by_commission_id(array_unique($commission_id));
                                        $commission_id = [];
                                        
                                        foreach($check_state as $da)
                                        {
                                            if($da->state == $state)
                                            {
                                                 $commission_id[] = $da->id;
                                                 $state_status = "1";
                                            }
                                            else if($da->state == "All")
                                            {
                                                $commission_id[] = $da->id;
                                                $state_status = "1";
                                            }
                                       }
                                       

                                         if($state_status == "1")
                                         {
                                            $classification = $this->cm->check_classification_by_commission_id(array_unique($commission_id));
                                            
                                            $temp_commission_id = [];
                                            $temp_commission_id = $commission_id;
                                            $commission_id = [];
                                           
                                            foreach($classification as $cl)
                                            {
                                                if($policy_type == "7" || $policy_type == "12" || $policy_type == "13" || $policy_type == "14" || $policy_type == "59" || $policy_type == "60" || $policy_type == "65" || $policy_type == "66" || $policy_type == "67" || $policy_type == "68" || $policy_type == "69" || $policy_type == "70")
                                                {
                                                    if($cl->classification != "")
                                                    {
                                                       $classification = $this->cm->check_seating($v_seating,$policy_type,$temp_commission_id);
                                                      
                                                        if(count($classification) > 0)
                                                        {
                                                            $gvw_status = "1";
                                                            foreach($classification as $da)
                                                            {
                                                                $commission_id[] = $cl->id;
                                                                $gvw_status = "1";
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $commission_id = $temp_commission_id;
                                                        $gvw_status = "1";
                                                    }
                                                }
                                                else if($policy_type == "1" || $policy_type == "2" || $policy_type == "3" || $policy_type == "4" || $policy_type == "55")
                                                {
                                                    if($cl->classification != "")
                                                    {
                                                        $classification = $this->lm->get_classification($cl->classification,$policy_type);
                                                     
                                                        if($classification != null || $classification != "")
                                                        {
                                                             $temp_min = $classification->from_gvw_cc;
                                                             $temp_max = $classification->to_gvw_cc;

                                                             if(($cc >= $temp_min && $cc <= $temp_max))
                                                             {
                                                                 $commission_id[] = $cl->id;
                                                                 $gvw_status = "1";
                                                             }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $gvw_status = "1";
                                                        $commission_id = $temp_commission_id;
                                                    }
                                                }
                                                else
                                                {
                                                    if($cl->classification != "")
                                                    {
                                                        $classification = $this->lm->get_classification($cl->classification,$policy_type);
                                                      
                                                        if($classification != null)
                                                        {
                                                            $temp_min = $classification->from_gvw_cc;
                                                            $temp_max = $classification->to_gvw_cc;
                                                            
                                                            if($v_gvw >= $temp_min && $v_gvw <= $temp_max)
                                                            {
                                                                $gvw_status = "1";
                                                                $commission_id[] = $cl->id;
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $gvw_status = "1";
                                                        $commission_id = $temp_commission_id;
                                                    }
                                                }
                                            }
                                            
                                           $check_make_1 = $this->cm->check_make_already_exits(array_unique($commission_id),$policy_type,$make);
                                            
                                            if(count($check_make_1) > 0)
                                            {
                                                    if(count($check_make_1) > 0)
                                                    {
                                                        $commission_id = [];
                                                        
                                                        foreach($check_make_1 as $da)
                                                        {
                                                             $commission_id[] = $da->commission_id;
                                                        }
                                                        $status = "1";
                                                        $make_status = "1";
                                                    }
                                                    else
                                                    {
                                                        $make_status = "0";
                                                    }
                                            }
                                            else
                                            {
                                                $check_make = $this->lm->check_make_all_already_exits(array_unique($commission_id),$policy_type);
                                                
                                                if(count($check_make) > 0)
                                                {
                                                    $commission_id = [];
                                                    
                                                    foreach($check_make as $da)
                                                    {
                                                      $commission_id[] = $da->id;
                                                    }
                                                    
                                                    $status = "1";
                                                    $make_status = "1";
                                                }
                                            }

                                            $check_model_1 = $this->lm->check_model_already_exits(array_unique($commission_id),$policy_type,$make,$model);
                                             
                                            if(count($check_model_1) > 0)
                                            {
                                                $commission_id = [];
                                                
                                                foreach($check_model_1 as $da)
                                                {
                                                   $commission_id[] = $da->commission_id;
                                                }
                                                
                                                $status = "1";
                                                $model_status = "1";
                                            }
                                            else
                                            {
                                                $check_model = $this->pm->check_model_all_already_exits(array_unique($commission_id),$policy_type);
                                                if(count($check_model) > 0)
                                                {
                                                        $commission_id = [];
                                                        foreach($check_model as $da)
                                                        {
                                                             $commission_id[] = $da->id;
                                                        }
                                                     $status = "1";
                                                     $model_status = "1";
                                                }
                                            }
                                            
                                            if($make_status == "1" && $model_status == "1")
                                            {
                                                $check_varient_1 = $this->cm->check_varient_already_exits(array_unique($commission_id),$policy_type,$make,$model,$Varient);
                                               
                                                if(count($check_varient_1) > 0) 
                                                {
                                                    $commission_id = [];
                                                    foreach($check_varient_1 as $da)
                                                    {
                                                      $commission_id[] = $da->commission_id;
                                                    }
                                                    $status = "1";
                                                    $varient_status = "1";
                                                }
                                                else
                                                {
                                                    $check_varient = $this->pm->check_varient_all_already_exits(array_unique($commission_id),$policy_type);
                                                    if(count($check_varient) > 0)
                                                    {
                                                        $commission_id = [];
                                                        
                                                        foreach($check_varient as $da)
                                                        {
                                                             $commission_id[] = $da->id;
                                                        }
                                                         $status = "1";
                                            	         $varient_status = "1";
                                                    }
                                                }
                                            }
                                            

                                            if($status == "1" && $state_status == "1" && $fuel_type_status == "1" && $gvw_status == "1" && $make_status == "1" && $model_status == "1" && $varient_status == "1")
                                            {
                                                 $check_rto = $this->cm->check_rto_already_exits_2(array_unique($commission_id),$rto);
                                                 
                                                    if(count($check_rto) > 0)
                                                    {
                                                        foreach($check_rto as $rt)
                                                        {
                                                            $com_id = $rt->commission_id;
                                                        }
                                                      
                                                        if(!$this->cm->check_policy_already_exits($lead_id))
                                                        {
                                                            if(!$this->cm->check_policy_no_already_exits($policy_no))
                                                            {
                                                                 $data1 = array("status" =>"success" ,"commission_id"=>$com_id);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $data1 = array("status" =>"Policy Already Exits","commission_id"=>"");
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $data1 = array("status" =>"RTO Mismatched","commission_id"=>"");
                                                    }
                                             }
                                            else if($state_status == "0")
                                            {
                                                $data1 = array("status" =>"State Mismacthed","commission_id"=>"");
                                            }
                                            else if($fuel_type_status == "0")
                                            {
                                                $data1 = array("status" =>"Fuel Type Mismacthed","commission_id"=>"");
                                            }
                                            else if($gvw_status == "0")
                                            {
                                                $data1 = array("status" =>"Classification Mismatched","commission_id"=>"");
                                            }
                                            else if($make_status == "0")
                                            {
                                                 $data1 = array("status" =>"Make Mismactched","commission_id"=>"");
                                            }
                                            else if($model_status == "0")
                                            {
                                                 $data1 = array("status" =>"Model Mismactched","commission_id"=>"");
                                            }
                                            else if($varient_status == "0")
                                            {
                                                 $data1 = array("status" =>"Varient Mismactched","commission_id"=>"");
                                            }
                                        }
                                         else
                                         {
                                             $data1 = array("status" =>"State Mismacthed","commission_id"=>"");
                                         }
                                     }
                                    else
                                    {
                                         $data1 = array("status" =>"Insurance company or Slab or Fuel Type Mismacthed","commission_id"=>"");
                                     }
                                 }
                                else if($da->commission_type == "1")
                                {
                                    $g_status = "0";
                                    $fuel_status = "0";
                                    
                                    foreach($check as $da)
                                	{
                                        $temp_min = $da->no_policy_min;
                                        $temp_max = $da->no_policy_max;
                                        

                                        if($temp_min <= 1 && $temp_max >= 1)
                                        {
                                             $g_status = "1";
                                             $commission_id[] = $da->id;
                                        }
                                        
                                        if($fuel_type == "1")
                                        {
                                        	if($da->fuel_type == "4" || $da->fuel_type == "5" || $da->fuel_type == "1" || $da->fuel_type == "6")
                                        	{
                                        	    $fuel_status = "1";
                                        	}
                                        }
                                        
                                        if($fuel_type == "2")
                                        {
                                            if($da->fuel_type == "5" || $da->fuel_type == "2" || $da->fuel_type == "6")
                                        	{
                                        	    $fuel_status = "1";
                                        	}
                                        }
                                        
                                        if($fuel_type == "5")
                                        {
                                            if($da->fuel_type == "5" || $da->fuel_type == "1" || $da->fuel_type == "2" || $da->fuel_type == "6")
                                        	{
                                        	    $fuel_status = "1";
                                        	}
                                        }
                                        
                                        if($fuel_type == "6")
                                        {
                                            if($da->fuel_type == "1" || $da->fuel_type == "2" || $da->fuel_type == "3" || $da->fuel_type == "4" || $da->fuel_type == "5" || $da->fuel_type == "6")
                                        	{
                                        	    $fuel_status = "1";
                                        	}
                                        }
                                        
                                        if($fuel_type == "7")
                                        {
                                            if($da->fuel_type == "7" || $da->fuel_type == "6")
                                        	{
                                        	    $fuel_status = "1";
                                        	}
                                        }
                            		   
                            			if($g_status == "1" && $fuel_status == "1")
                            			{
                            			    $commission_id[] = $da->id;
                            			    $status = "1";
                                            $fuel_type_status = "1";
                            			}
                                	}
                                	
                                    if($status == "1")
                                    {
                                        $check_state = $this->cm->check_state_by_commission_id(array_unique($commission_id));
                                        
                                        $commission_id = [];
                                        
                                        foreach($check_state as $da)
                                        {
                                            if($da->state == $state)
                                            {
                                                 $commission_id[] = $da->id;
                                                 $state_status = "1";
                                            }
                                            else if($da->state == "All")
                                            {
                                                $commission_id[] = $da->id;
                                                $state_status = "1";
                                            }
                                        }
                                        
                                        if($state_status == "1")
                                        {
                                            $classification = $this->cm->check_classification_by_commission_id(array_unique($commission_id));
                                            $temp_commission_id = [];
                                            $temp_commission_id = $commission_id;
                                            $commission_id = [];
                                        
                                            foreach($classification as $cl)
                                            {
                                                if($policy_type == "7" || $policy_type == "12" || $policy_type == "13" || $policy_type == "14" || $policy_type == "59" || $policy_type == "60" || $policy_type == "65" || $policy_type == "66" || $policy_type == "67" || $policy_type == "68" || $policy_type == "69" || $policy_type == "70")
                                                {
                                                    if($cl->classification != "")
                                                    {
                                                       $classification = $this->cm->check_seating($v_seating,$policy_type,$temp_commission_id);
                                                       
                                                        if(count($classification) > 0)
                                                        {
                                                            $gvw_status = "1";
                                                            
                                                            foreach($classification as $da)
                                                            {
                                                                $commission_id[] = $cl->id;
                                                                $gvw_status = "1";
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $commission_id = $temp_commission_id;
                                                        $gvw_status = "1";
                                                    }
                                                }
                                                else if($policy_type == "1" || $policy_type == "2" || $policy_type == "3" || $policy_type == "4" || $policy_type == "55")
                                                {
                                                    if($cl->classification != "")
                                                    {
                                                        $classification = $this->lm->get_classification($cl->classification,$policy_type);
                                                     
                                                        if($classification != null)
                                                        {
                                                             $temp_min = $classification->from_gvw_cc;
                                                             $temp_max = $classification->to_gvw_cc;
                                                             
                                                             if(($cc >= $temp_min && $cc <= $temp_max))
                                                             {
                                                                 $commission_id[] = $cl->id;
                                                                 $gvw_status = "1";
                                                             }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $gvw_status = "1";
                                                        $commission_id = $temp_commission_id;
                                                    }
                                                }
                                                else
                                                {
                                                    if($cl->classification != "")
                                                    {
                                                        $classification = $this->lm->get_classification($cl->classification,$policy_type);
                                                      
                                                        if($classification != null)
                                                        {
                                                            $temp_min = $classification->from_gvw_cc;
                                                            $temp_max = $classification->to_gvw_cc;
                                                            
                                                            if($v_gvw >= $temp_min && $v_gvw <= $temp_max)
                                                            {
                                                                $gvw_status = "1";
                                                                $commission_id[] = $cl->id;
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $gvw_status = "1";
                                                        $commission_id = $temp_commission_id;
                                                    }
                                                }
                                            }
                                        
                                            $check_make_1 = $this->cm->check_make_already_exits(array_unique($commission_id),$policy_type,$make);
                                            
                                            if(count($check_make_1) > 0)
                                            {
                                                    if(count($check_make_1) > 0)
                                                    {
                                                        $commission_id = [];
                                                        
                                                        foreach($check_make_1 as $da)
                                                        {
                                                             $commission_id[] = $da->commission_id;
                                                        }
                                                        $status = "1";
                                                        $make_status = "1";
                                                    }
                                                    else
                                                    {
                                                        $make_status = "0";
                                                    }
                                            }
                                            else
                                            {
                                                $check_make = $this->lm->check_make_all_already_exits(array_unique($commission_id),$policy_type);
                                                
                                                if(count($check_make) > 0)
                                                {
                                                    $commission_id = [];
                                                    
                                                    foreach($check_make as $da)
                                                    {
                                                      $commission_id[] = $da->id;
                                                    }
                                                    
                                                    $status = "1";
                                                    $make_status = "1";
                                                }
                                            }

                                            $check_model_1 = $this->lm->check_model_already_exits(array_unique($commission_id),$policy_type,$make,$model);
                                             
                                            if(count($check_model_1) > 0)
                                            {
                                                $commission_id = [];
                                                
                                                foreach($check_model_1 as $da)
                                                {
                                                   $commission_id[] = $da->commission_id;
                                                }
                                                
                                                $status = "1";
                                                $model_status = "1";
                                            }
                                            else
                                            {
                                                $check_model = $this->pm->check_model_all_already_exits(array_unique($commission_id),$policy_type);
                                                if(count($check_model) > 0)
                                                {
                                                        $commission_id = [];
                                                        foreach($check_model as $da)
                                                        {
                                                             $commission_id[] = $da->id;
                                                        }
                                                     $status = "1";
                                                     $model_status = "1";
                                                }
                                            }
                                            
                                            if($make_status == "1" && $model_status == "1")
                                            {
                                                $check_varient_1 = $this->cm->check_varient_already_exits(array_unique($commission_id),$policy_type,$make,$model,$Varient);
                                               
                                                if(count($check_varient_1) > 0) 
                                                {
                                                    $commission_id = [];
                                                    foreach($check_varient_1 as $da)
                                                    {
                                                      $commission_id[] = $da->commission_id;
                                                    }
                                                    $status = "1";
                                                    $varient_status = "1";
                                                }
                                                else
                                                {
                                                    $check_varient = $this->pm->check_varient_all_already_exits(array_unique($commission_id),$policy_type);
                                                    if(count($check_varient) > 0)
                                                    {
                                                        $commission_id = [];
                                                        
                                                        foreach($check_varient as $da)
                                                        {
                                                             $commission_id[] = $da->id;
                                                        }
                                                         $status = "1";
                                            	         $varient_status = "1";
                                                    }
                                                }
                                            }
                                
                                            if($status == "1" && $state_status == "1" && $fuel_type_status == "1" && $gvw_status == "1" && $make_status == "1" && $model_status == "1" && $varient_status == "1")
                                            {
                                                 $check_rto = $this->cm->check_rto_already_exits_2(array_unique($commission_id),$rto);
                                                 
                                                    if(count($check_rto) > 0)
                                                    {
                                                        foreach($check_rto as $rt)
                                                        {
                                                            $com_id = $rt->commission_id;
                                                        }
                                                        if(!$this->cm->check_policy_already_exits($lead_id))
                                                        {
                                                            if(!$this->cm->check_policy_no_already_exits($policy_no))
                                                            {
                                                                 $data1 = array("status" =>"success" ,"commission_id"=>$com_id);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $data1 = array("status" =>"Policy Already Exits","commission_id"=>"");
                                                        }
                                                    }
                                             }
                                            else if($fuel_type_status == "0")
                                            {
                                              $data1 = array("status" =>"Fuel Type Mismacthed","commission_id"=>"");
                                            }
                                            else if($gvw_status == "0")
                                            {
                                              $data1 = array("status" =>"Classification Mismatched","commission_id"=>"");
                                            }
                                            else if($make_status == "0")
                                            {
                                              $data1 = array("status" =>"Make Mismactched","commission_id"=>"");
                                            }
                                            else if($model_status == "0")
                                            {
                                              $data1 = array("status" =>"Model Mismactched","commission_id"=>"");
                                            }
                                            else if($varient_status == "0")
                                            {
                                              $data1 = array("status" =>"Varient Mismactched","commission_id"=>"");
                                            }
                                        }
                                        else
                                        {
                                             $data1 = array("status" =>"State Mismacthed","commission_id"=>"");
                                        }
                                     }
                                    else 
                                    {
                                      $data1 = array("status" =>"Insurance company or Slab Mismacthed","commission_id"=>"");
                                    }
                                }
                                else if($da->commission_type == "3")
                                {
                                    $g_status = "0";
                                    $fuel_status = "0";
                                    
                                    foreach($check as $da)
                                	{
                                        $temp_min = $da->min_val;
                                        $temp_max = $da->max_val;
                                        
                                        if($temp_min <= $total_premium && $temp_max >= $total_premium)
                                        {
                                             $g_status = "1";
                                             $commission_id[] = $da->id;
                                        }
                                        
                                        if($fuel_type == "1")
                                        {
                                        	if($da->fuel_type == "4" || $da->fuel_type == "5" || $da->fuel_type == "1" || $da->fuel_type == "6")
                                        	{
                                        	    $fuel_status = "1";
                                        	}
                                        }
                                        if($fuel_type == "2")
                                        {
                                            if($da->fuel_type == "5" || $da->fuel_type == "2" || $da->fuel_type == "6")
                                        	{
                                        	    $fuel_status = "1";
                                        	}
                                        }
                                        if($fuel_type == "5")
                                        {
                                            if($da->fuel_type == "5" || $da->fuel_type == "1" || $da->fuel_type == "2" || $da->fuel_type == "6")
                                        	{
                                        	    $fuel_status = "1";
                                        	}
                                        }
                                        if($fuel_type == "6")
                                        {
                                            if($da->fuel_type == "1" || $da->fuel_type == "2" || $da->fuel_type == "3" || $da->fuel_type == "4" || $da->fuel_type == "5" || $da->fuel_type == "6")
                                        	{
                                        	    $fuel_status = "1";
                                        	}
                                        }
                                        if($fuel_type == "7")
                                        {
                                            if($da->fuel_type == "7" || $da->fuel_type == "6")
                                        	{
                                        	    $fuel_status = "1";
                                        	}
                                        }
                            		   
                            			if($g_status == "1" && $fuel_status == "1")
                            			{
                            			    $commission_id[] = $da->id;
                            			    $status = "1";
                                            $fuel_type_status = "1";
                                          
                            			}
                                	}
                                	
                                    if($status == "1")
                                    {
                                        $check_state = $this->cm->check_state_by_commission_id(array_unique($commission_id));
                                        $commission_id = [];
                                        
                                        foreach($check_state as $da)
                                        {
                                            if($da->state == $state)
                                            {
                                                 $commission_id[] = $da->id;
                                                 $state_status = "1";
                                            }
                                            else if($da->state == "All")
                                            {
                                                $commission_id[] = $da->id;
                                                $state_status = "1";
                                            }
                                        }
                                        
                                        if($state_status == "1")
                                        {
                                            $classification = $this->cm->check_classification_by_commission_id(array_unique($commission_id));
                                            $temp_commission_id = [];
                                            $temp_commission_id = $commission_id;
                                        
                                             $commission_id = [];
                                        
                                            foreach($classification as $cl)
                                            {
                                                if($policy_type == "7" || $policy_type == "12" || $policy_type == "13" || $policy_type == "14" || $policy_type == "59" || $policy_type == "60" || $policy_type == "65" || $policy_type == "66" || $policy_type == "67" || $policy_type == "68" || $policy_type == "69" || $policy_type == "70")
                                                {
                                                    if($cl->classification != "")
                                                    {
                                                       $classification = $this->cm->check_seating($v_seating,$policy_type,$temp_commission_id);
                                                       
                                                        if(count($classification) > 0)
                                                        {
                                                            $gvw_status = "1";
                                                            
                                                            foreach($classification as $da)
                                                            {
                                                                $commission_id[] = $cl->id;
                                                                $gvw_status = "1";
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $commission_id = $temp_commission_id;
                                                        $gvw_status = "1";
                                                    }
                                                }
                                                else if($policy_type == "1" || $policy_type == "2" || $policy_type == "3" || $policy_type == "4" || $policy_type == "55")
                                                {
                                                    if($cl->classification != "")
                                                    {
                                                        $classification = $this->lm->get_classification($cl->classification,$policy_type);
                                                     
                                                        if($classification != null)
                                                        {
                                                             $temp_min = $classification->from_gvw_cc;
                                                             $temp_max = $classification->to_gvw_cc;
                                                             
                                                             if(($cc >= $temp_min && $cc <= $temp_max))
                                                             {
                                                                 $commission_id[] = $cl->id;
                                                                 $gvw_status = "1";
                                                             }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $gvw_status = "1";
                                                        $commission_id = $temp_commission_id;
                                                    }
                                                }
                                                else
                                                {
                                                    if($cl->classification != "")
                                                    {
                                                        $classification = $this->lm->get_classification($cl->classification,$policy_type);
                                                      
                                                        if($classification != null)
                                                        {
                                                            $temp_min = $classification->from_gvw_cc;
                                                            $temp_max = $classification->to_gvw_cc;
                                                            
                                                            if($v_gvw >= $temp_min && $v_gvw <= $temp_max)
                                                            {
                                                                $gvw_status = "1";
                                                                $commission_id[] = $cl->id;
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $gvw_status = "1";
                                                        $commission_id = $temp_commission_id;
                                                    }
                                                }
                                            }
                                        
                                             $check_make_1 = $this->cm->check_make_already_exits(array_unique($commission_id),$policy_type,$make);
                                            
                                            if(count($check_make_1) > 0)
                                            {
                                                    if(count($check_make_1) > 0)
                                                    {
                                                        $commission_id = [];
                                                        
                                                        foreach($check_make_1 as $da)
                                                        {
                                                             $commission_id[] = $da->commission_id;
                                                        }
                                                        $status = "1";
                                                        $make_status = "1";
                                                    }
                                                    else
                                                    {
                                                        $make_status = "0";
                                                    }
                                            }
                                            else
                                            {
                                                $check_make = $this->lm->check_make_all_already_exits(array_unique($commission_id),$policy_type);
                                                
                                                if(count($check_make) > 0)
                                                {
                                                    $commission_id = [];
                                                    
                                                    foreach($check_make as $da)
                                                    {
                                                      $commission_id[] = $da->id;
                                                    }
                                                    
                                                    $status = "1";
                                                    $make_status = "1";
                                                }
                                            }

                                            $check_model_1 = $this->lm->check_model_already_exits(array_unique($commission_id),$policy_type,$make,$model);
                                             
                                            if(count($check_model_1) > 0)
                                            {
                                                $commission_id = [];
                                                
                                                foreach($check_model_1 as $da)
                                                {
                                                   $commission_id[] = $da->commission_id;
                                                }
                                                
                                                $status = "1";
                                                $model_status = "1";
                                            }
                                            else
                                            {
                                                $check_model = $this->pm->check_model_all_already_exits(array_unique($commission_id),$policy_type);
                                                if(count($check_model) > 0)
                                                {
                                                        $commission_id = [];
                                                        foreach($check_model as $da)
                                                        {
                                                             $commission_id[] = $da->id;
                                                        }
                                                     $status = "1";
                                                     $model_status = "1";
                                                }
                                            }
                                            
                                            if($make_status == "1" && $model_status == "1")
                                            {
                                                $check_varient_1 = $this->cm->check_varient_already_exits(array_unique($commission_id),$policy_type,$make,$model,$Varient);
                                               
                                                if(count($check_varient_1) > 0) 
                                                {
                                                    $commission_id = [];
                                                    foreach($check_varient_1 as $da)
                                                    {
                                                      $commission_id[] = $da->commission_id;
                                                    }
                                                    $status = "1";
                                                    $varient_status = "1";
                                                }
                                                else
                                                {
                                                    $check_varient = $this->pm->check_varient_all_already_exits(array_unique($commission_id),$policy_type);
                                                    if(count($check_varient) > 0)
                                                    {
                                                        $commission_id = [];
                                                        
                                                        foreach($check_varient as $da)
                                                        {
                                                             $commission_id[] = $da->id;
                                                        }
                                                         $status = "1";
                                            	         $varient_status = "1";
                                                    }
                                                }
                                            }
                                            
                                            if($status == "1" && $state_status == "1" && $fuel_type_status == "1" && $gvw_status == "1" && $make_status == "1" && $model_status == "1" && $varient_status == "1")
                                            {
                                                 $check_rto = $this->cm->check_rto_already_exits_2(array_unique($commission_id),$rto);
                                                 
                                                    if(count($check_rto) > 0)
                                                    {
                                                        foreach($check_rto as $rt)
                                                        {
                                                            $com_id = $rt->commission_id;
                                                        }
                                                        
                                                        if(!$this->cm->check_policy_already_exits($lead_id))
                                                        {
                                                            if(!$this->cm->check_policy_no_already_exits($policy_no))
                                                            {
                                                                 $data1 = array("status" =>"success" ,"commission_id"=>$com_id);
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $data1 = array("status" =>"Policy Already Exits","commission_id"=>"");
                                                        }
                                                    }
                                             }
                                            else if($fuel_type_status == "0")
                                            {
                                              $data1 = array("status" =>"Fuel Type Mismacthed","commission_id"=>"");
                                            }
                                            else if($gvw_status == "0")
                                            {
                                              $data1 = array("status" =>"Classification Mismatched","commission_id"=>"");
                                            }
                                            else if($make_status == "0")
                                            {
                                              $data1 = array("status" =>"Make Mismactched","commission_id"=>"");
                                            }
                                            else if($model_status == "0")
                                            {
                                              $data1 = array("status" =>"Model Mismactched","commission_id"=>"");
                                            }
                                            else if($varient_status == "0")
                                            {
                                              $data1 = array("status" =>"Varient Mismactched","commission_id"=>"");
                                            }
                                        }
                                        else
                                        {
                                            $data1 = array("status" =>"State Mismacthed","commission_id"=>"");
                                        }
                                     }
                                    else
                                    {
                                       $data1 = array("status" =>"Insurace Company or Slab Mismacthed","commission_id"=>"");
                                    }
                                }
                            }
                           echo json_encode($data1);
                   }
                   else if($class_type->class == "2")
                   {
                           $bussiness_type = $class_type->business_type;
                           $policy_class = $class_type->class;
                           $policy_type =  $class_type->policy_type;
                           $state = "All";
                           
                            $data1 = array("status" =>"Commission Slab Not Exits","commission_id"=>"");
                           
                           $check = $this->cm->check_health_commission($company,$policy_premium,$policy_class,$bussiness_type,$policy_type,$state,$from_date_1,$to_date_1);
                           
                            foreach($check as $da)
                            {
                                if($da->commission_type == "1")
                                {
                                    foreach($check as $da)
                                	{
                                        $temp_min = $da->no_policy_min;
                                        $temp_max = $da->no_policy_max;
                                        
                                        if($temp_min <= 1 && $temp_max >= 1)
                                        {
                                             $status = "1";
                                             $commission_id[] = $da->id;
                                        }
                                	}
                                	
                                	if($status == "1")
                                	{
                                	     if($da->state != "All")
                                	     {
                                	         $res = $this->cm->check_health_state($commission_id);
                                	         $commission_id = [];
                                	         
                                    	     foreach($res as $da)
                                    	     {
                                    	           $commission_id[] = $da->id;
                                    	           $c_id = $da->id;
                                    	     }
                                	     }
                                	     $data1 = array("status" =>"success","commission_id"=>$c_id);
                                	}
                                	else
                                	{
                                	     $data1 = array("status" =>"Slab Not Exits","commission_id"=>"");
                                	}
                                }
                                else if($da->commission_type == "3")
                                {
                                    foreach($check as $da)
                                	{
                                        $temp_min = $da->min_val;
                                        $temp_max = $da->max_val;
                                        
                                        if($temp_min <= $total_premium && $temp_max >= $total_premium)
                                        {
                                             $status = "1";
                                             $commission_id[] = $da->id;
                                        }
                                	}
                                	
                                	if($status == "1")
                                	{
                                	     if($da->state != "All")
                                	     {
                                	         $res = $this->cm->check_health_state($commission_id);
                                	         $commission_id = [];
                                	         
                                    	     foreach($res as $da)
                                    	     {
                                    	           $commission_id[] = $da->id;
                                    	           $c_id = $da->id;
                                    	     }
                                    	     $data1 = array("commission_id"=>$c_id,"status" => "success");
                                	     }
                                	     else
                                	     {
                                	         $data1 = array("commission_id"=>"","status" => "success");
                                	     }
                                	}
                                }
                            }
                             echo json_encode($data1);
                      }
               
                 }
        	}
       }
       
  //direct renewals 
       
  public function direct_renewals()
  {
      if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
    	{    		
		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
		   	$data["users"] = $this->lm->fetch_users();
		   	$data["client_type"] = $this->lm->fetch_client_type();
		   	$data["business"] = $this->lm->fetch_business_type();
		   	$data["class"] = $this->lm->fetch_list_of_policy_type();
    		$this->load->view('header',$pro_data);
    		$this->load->view('direct_renewals',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else if($this->session->has_userdata('logged_in') && ($this->session->userdata('session_role') == "user" || $this->session->userdata('session_role') == "AI"))
	    {
	        $pro_data["project_info"] = $this->mm->fetch_project_info();
	        $data["users"] = $this->lm->fetch_users();
	        $data["client_type"] = $this->lm->fetch_client_type();
	        $data["business"] = $this->lm->fetch_business_type();
	        $data["class"] = $this->lm->fetch_list_of_policy_type();
    		$this->load->view('header',$pro_data);
    		$this->load->view('direct_renewals',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else
	    {
	    	redirect("login");
	    }
  }
  
  public function fetch_direct_renewals()
  {
       if($this->session->has_userdata('logged_in')) 
       { 
           $draw = intval($this->input->post("draw"));
           
           $from_date = $this->input->post("from_date");
           $to_date = $this->input->post("to_date");
           
    	   $res = $this->lm->fetch_all_direct_renewals($from_date,$to_date);
    	   
    	   $a=0;
    	   $arr = [];
    	  
    	 foreach($res as $da)
    	 {
    	   $a++;
    	   $action = "<a href='create_lead?id=".$da->id."' class='btn btn-warning btn-xs'><i class='fa fa-eye'></i></a>";
            $arr[] =array(
                           $a,
                           $da->client_name,
                           $da->mobile_no,
                           $da->lclass,
                           $da->p_type,
                           $da->b_type,
                           $da->area,
                           $da->Model,
                           $da->sub_model,
                           date_format(date_create($da->due_date),"d-m-Y"),
                           $action,
                        );
            }
    	        $result = array(
            			"draw"=> $draw,
    				    "recordsTotal"=>count($res) ,
    				    "recordsFiltered"=> count($res),
    				    "data"=>$arr,
    				);
          echo json_encode($result);
       }
   }
   
   public function direct_renewals_excel()
   {
      if($this->session->has_userdata('logged_in')) 
      { 
           $from_date = $this->input->post("from_date");
           $to_date = $this->input->post("to_date");
           
    	   $res = $this->lm->fetch_all_direct_renewals($from_date,$to_date);
    	   
    	    $this->load->library('Excel');
    	    $from_date = $this->input->post("from_date");
    	    $to_date = $this->input->post("to_date");
    	    $agent_list = $this->input->post("agents");
    	    
        	$objPHPExcel = new PHPExcel();
            $objPHPExcel->setActiveSheetIndex(0);
            $rowCount = 4;
            $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
            $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight(15);
            $objPHPExcel->getActiveSheet()->SetCellValue('D2', 'Direct Renewals Report');
            
           $objPHPExcel->getActiveSheet()->getStyle('D2')->applyFromArray( 
           array(
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => 'F50A1B')
                    ),
                    'alignment' => array(
                        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                    ),
                    'font'  => array(
                        'bold'  => true,
                        'color' => array('rgb' => 'FFFFFF'),
                        'size'  => 13,
                    ),
                )
            );
            
            $objPHPExcel->getActiveSheet()->getStyle('3')->applyFromArray(
                array(
                    
                    'font'  => array(
                        'bold'  => true,
                        'color' => array('rgb' => '000000'),
                        'size'  => 13,
                    ),
                )
            );
          
            $objPHPExcel->getActiveSheet()->getRowDimension('3')->setRowHeight(20);
            $objPHPExcel->getActiveSheet()->SetCellValue('I3', 'Excel Date : ');
            $objPHPExcel->getActiveSheet()->SetCellValue('J3', date("d-m-Y"));
            $objPHPExcel->getActiveSheet()->getRowDimension('4')->setRowHeight(20);
            $objPHPExcel->getActiveSheet()->getStyle('4')->applyFromArray(
                array(
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => '31406b')
                    ),
                    'alignment' => array(
                        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                    ),
                    'font'  => array(
                        'bold'  => true,
                        'color' => array('rgb' => 'FFFFFF'),
                        'size'  => 13,
                    ),
                )
            );
            
            $objPHPExcel->getActiveSheet()->SetCellValue('A4', 'S.No');
            $objPHPExcel->getActiveSheet()->SetCellValue('B4', 'Client name	');
            $objPHPExcel->getActiveSheet()->SetCellValue('C4', 'Mobile Number');
            $objPHPExcel->getActiveSheet()->SetCellValue('D4', 'Class');
            $objPHPExcel->getActiveSheet()->SetCellValue('E4', 'Policy Type');
            $objPHPExcel->getActiveSheet()->SetCellValue('F4', 'Business type');
            $objPHPExcel->getActiveSheet()->SetCellValue('G4', 'Area');
            $objPHPExcel->getActiveSheet()->SetCellValue('H4', 'Due Date');
            $row_count = 5;

    	    $a=0;
    	    
    	    foreach($res as $da)
    	    {
    	       $a++;
                $objPHPExcel->getActiveSheet()->SetCellValue('A'.$row_count , $a);
                $objPHPExcel->getActiveSheet()->SetCellValue('B'.$row_count , $da->client_name);
                $objPHPExcel->getActiveSheet()->SetCellValue('C'.$row_count , $da->mobile_no);
                $objPHPExcel->getActiveSheet()->SetCellValue('D'.$row_count , $da->lclass);
                $objPHPExcel->getActiveSheet()->SetCellValue('E'.$row_count , $da->p_type);
                $objPHPExcel->getActiveSheet()->SetCellValue('F'.$row_count , $da->b_type);
                $objPHPExcel->getActiveSheet()->SetCellValue('G'.$row_count , $da->area);
                $objPHPExcel->getActiveSheet()->SetCellValue('H'.$row_count , date_format(date_create($da->due_date),"d-m-Y"));
                $objPHPExcel->getActiveSheet()->getRowDimension($row_count)->setRowHeight(20);
                $row_count++;
    	    }
    	     $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
            $objWriter->save('./datas/reports/direct_renewals_report.xlsx');
            echo base_url()."/datas/reports/direct_renewals_report.xlsx";
      }
   }
   
   public function add_nominee_details()
   {
      if($this->session->has_userdata('logged_in')) 
      { 
           $lead_id = $this->input->post("lead_id");
           $nominee_name = $this->input->post("nominee_name");
           $adharcard_no = $this->input->post("adharcard_no");
           $n_mobile_no = $this->input->post("n_mobile_no");
           $n_adhar_card_upload = $this->input->post("n_adhar_card_upload");
           
             if(isset($_FILES))
             {
            			$config['upload_path'] = './datas/nominee_documents/';
            			$config['allowed_types'] = '*';
            			
            			$this->load->library('upload',$config);
            			$this->upload->initialize($config);
            			if(!$this->upload->do_upload('n_adhar_card_upload'))
            			{
            				$file = '';
            			}
            			else
            			{
            				$file = $this->upload->data('file_name');
            			}
            		}
          $nominee_details = array("lead_id"=>$lead_id,"name" =>$nominee_name,"adharcard_no"=>$adharcard_no,"mobile_no"=>$n_mobile_no,"file"=>$file,"created_by"=>$this->session->userdata('session_id'),"created_date"=>date("Y-m-d H:i:s"));
          $add_nominee_details = $this->lm->add_nominee_details($nominee_details);
          echo "success";
      }
   }
   
   public function get_nominee_details()
   {
      if($this->session->has_userdata('logged_in')) 
      {
          $lead_id = $this->input->post("lead_id");
          $res= $this->lm->get_nominee_details($lead_id);
          echo json_encode($res);
      }
   }
   
   public function fetch_pcv_seating_capacity()
   {
      if($this->session->has_userdata('logged_in')) 
      {
          $policy_type = $this->input->post("policy_type");
          $res = $this->lm->get_pcv_seating($policy_type);
          $option = "<option value=''>--Select--</option>";
          foreach($res as $da)
          {
             $option .="<option value=".$da->id.">".$da->seating_capacity." Seater</option>";
          }
          echo $option;
      }
   }
   
   public function fetch_edit_pcv_seating_capacity()
   {
      if($this->session->has_userdata('logged_in')) 
      {
          $policy_type = $this->input->post("policy_type");
          $res = $this->lm->get_pcv_seating($policy_type);
          echo json_encode($res);
      }
   }
   
   
   public function fetch_area_incharge_by_agent()
   {
      if($this->session->has_userdata('logged_in')) 
      {
          $agent_pos = $this->input->post("agent_pos");
          $res = $this->lm->fetch_area_incharge_by_agent($agent_pos);
          echo json_encode($res);
      }
   }
   
   
    public function check_policy_no_already_exits()
   {
      if($this->session->has_userdata('logged_in')) 
      {
          $policy_no = $this->input->post("policy_no");
          $check = $this->lm->check_policy_no_already_exits($policy_no);
          
          if(count($check) > 0)
          {
              $status = "This Policy No Already Exits";
          }
          else
          {
              $status = "Not_exits";
          }
          echo $status;
      }
   }
   
        public function temp_save_policy()
        {
          if($this->session->has_userdata('logged_in')) 
          {
             $lead_id = $this->input->post("lead_id");
             $policy_no = $this->input->post("policy_no");
             
              $data = array(
            	        "lead_id" =>$this->input->post("lead_id"),
            	        "policy_client_ref_no"=> $this->input->post("policy_client_ref_no"),
                        "policy_cover_note_no"=> $this->input->post("policy_cover_note_no"),
                        "policy_no"=> $this->input->post("policy_no"),
                        "policy_s_date"=> $this->input->post("policy_s_date"),
                        "policy_ex_date"=> $this->input->post("policy_ex_date"),
                        "policy_premium"=> $this->input->post("policy_premium"),
                        "policy_terms"=> $this->input->post("policy_terms"),
                        "payment_frequency"=> $this->input->post("payment_frequency"),
                        "next_due_date"=> $this->input->post("next_due_date"),
                        "renewable_flag"=> $this->input->post("renewable_flag"),
                        "add_ons_opted"=> $this->input->post("add_ons_opted"),
                        "add_ons_not_opt" =>$this->input->post("add_ons_not_opt"),
                        "lead_type" =>"2",
                        "sum_insured"=> $this->input->post("sum_insured"),
                        "discount_percent"=> $this->input->post("discount_percent"),
                        "no_claim_bonus"=> $this->input->post("no_claim_bonus"),
                        "no_claim_bonus_val"=> $this->input->post("no_claim_bonus_val"),
                        "cpa"=> $this->input->post("cpa"),
                        "total_own_damage"=> $this->input->post("total_own_damage"),
                        "tot_add_on_premium"=> $this->input->post("tot_add_on_premium"),
                        "commisson_base_premium"=> $this->input->post("commisson_base_premium"),
                        "basic_tp"=> $this->input->post("basic_tp"),
                        "owner_driver_pa"=> $this->input->post("owner_driver_pa"),
                        "owner_diver_amt"=> $this->input->post("owner_diver_amt"),
                        "no_of_year_own_drv"=> $this->input->post("no_of_year_own_drv"),
                        "fuel_kit"=> $this->input->post("fuel_kit"),
                        "fuel_kit_amt"=> $this->input->post("fuel_kit_amt"),
                        "geograpical"=> $this->input->post("geograpical"),
                        "geograpical_amt"=> $this->input->post("geograpical_amt"),
                        "un_named_passenger_pa"=> $this->input->post("un_named_passenger_pa"),
                        "un_named_passenger_amt"=> $this->input->post("un_named_passenger_amt"),
                        "no_seats_per_person"=> $this->input->post("no_seats_per_person"),
                        "no_seats_per_person_amt"=> $this->input->post("no_seats_per_person_amt"),
                        "LL_paid "=> $this->input->post("llp"),
                        "LL_paid_amt"=> $this->input->post("llp_amt"),
                        "no_drv_emp"=> $this->input->post("no_drv_emp"),
                        "pa_paid_drv"=> $this->input->post("pa_paid_drv"),
                        "pa_paid_drv_amt"=> $this->input->post("pa_paid_drv_amt"),
                        "no_seats_per_person1"=> $this->input->post("no_seats_per_person1"),
                        "no_seats_per_person_amt1"=> $this->input->post("no_seats_per_person_amt1"),
                        "tot_liability_premium"=> $this->input->post("tot_liability_premium"),
                        "total_premium"=> $this->input->post("total_premium"),
                        "gst"=> $this->input->post("gst"),
                        "premium_gst"=> $this->input->post("premium_gst"),
                        "policy_issue_date"=> $this->input->post("policy_issue_date"),
                        "policy_agency_pos"=> $this->input->post("policy_agency_pos"),
                        "policy_source"=> $this->input->post("policy_source"),
                        "policy_user"=> $this->input->post("policy_user"),
                        "policy_location"=> $this->input->post("policy_location"),
                        "previous_policy_no"=> $this->input->post("previous_policy_no"),
                        "previous_insurer"=> $this->input->post("previous_insurer"),
                        "previous_insurance_plan"=> $this->input->post("previous_insurance_plan"),
                        "previous_agency_pos"=> $this->input->post("previous_agency_pos"),
                        "previous_source"=> $this->input->post("previous_source"),
                        "dectable_details"=> $this->input->post("dectable_details"),
                        "policy_additional_info"=> $this->input->post("policy_additional_info"),
                        "reference_no"=> $this->input->post("reference_no"),
                        "other_reference_no"=> $this->input->post("other_reference_no"),
                        "policy_received"=> $this->input->post("policy_received"),
                        "policy_verified"=> $this->input->post("policy_verified"),
                        "policy_verified_info"=> $this->input->post("policy_verified_info"),
                        "policy_cancelled"=> $this->input->post("policy_cancelled"),
                        "policy_cancelled_info"=> $this->input->post("policy_cancelled_info"),
                        "commisson_generation"=> $this->input->post("commisson_generation"),
                        "payment_type"=> $this->input->post("payment_type"),
                        "pay_ref_no"=> $this->input->post("pay_ref_no"),
                        "bank_name"=> $this->input->post("bank_name"),
                        "payment_check_date"=> $this->input->post("payment_check_date"),
                        "payment_and_check_no"=> $this->input->post("payment_and_check_no"),
                        "remarks"=> $this->input->post("remarks"),
                        "company"=> $this->input->post("company"),
                        "created_by"=> $this->session->userdata('session_id'),
                        "created_at"=> date("Y-m-d H:i:s"),
                        );
                
                if(!$this->lm->check_this_policy_already_exits_in_temp($policy_no))
                {
                    if(!$this->lm->check_this_policy_already_exits($policy_no))
                    {
                        $check = $this->lm->check_lead_id_already_exits($lead_id);
                        
                        if($check > 0)
                        {
                            $temp_data = $this->lm->update_temp_data_by_lead_id($data,$lead_id);
                        }
                        else
                        {
                              $temp_data = $this->lm->insert_temp_data($data);
                        }
                        $data_1 = array("policy_status" =>"1");
                        $update = $this->lm->update_policy_status($data_1,$lead_id);
                    }
                    else
                    {
                        echo "Exits";
                    }
                }
                else
                {
                    echo "Exits";
                }
            }
       }
        
        public function get_temp_data()
        {
             if($this->session->has_userdata('logged_in')) 
             {
                 $lead_id = $this->input->post("lead_id");
                 
                 $check = $this->lm->check_this_lead_already_in_policy_info($lead_id);
                 
                 if($check > 0)
                 {
                     $res = $this->lm->get_policy_data($lead_id);
                 }
                 else
                 {                                     
                    $res = $this->lm->get_temp_policy_data($lead_id);
                 }
                 
                 echo json_encode($res);
             }
        }
        
        public function fetch_edit_health_details()
        {
            if($this->session->has_userdata('logged_in')) 
             {
                 $lead_id = $this->input->post("lead_id");
                 $res = $this->lm->get_health_details($lead_id);
                 echo json_encode($res);
             }
        }
        
        
   public function edit_health_details()
    {
      if($this->session->has_userdata('logged_in'))
       {
            $lead_id=$this->input->post("lead_id");
            $h_gender=$this->input->post("h_gender");
            $Husband=$this->input->post("Husband");
            $Wife=$this->input->post("Wife");
            $Son=$this->input->post("Son");
            $Daughter=$this->input->post("Daughter");
            $Father=$this->input->post("Father");
            $Mother=$this->input->post("Mother");
            $Husband_age=$this->input->post("Husband_age");
            $Wife_age=$this->input->post("Wife_age");
            $num_daughters=$this->input->post("num_daughters");
            $num_sons=$this->input->post("num_sons");
            $son_1_age=$this->input->post("son_1_age");
           $son_2_age=$this->input->post("son_2_age");
           $son_3_age=$this->input->post("son_3_age");
           $son_4_age=$this->input->post("son_4_age");
           $daughter_1_age=$this->input->post("daughter_1_age");
           $daughter_2_age=$this->input->post("daughter_2_age");
           $daughter_3_age=$this->input->post("daughter_3_age");
           $daughter_4_age=$this->input->post("daughter_4_age");
          $father_age=$this->input->post("father_age");
          $mother_age=$this->input->post("mother_age");
          $date = date("Y-m-d"); 
          
           $son_name_1=$this->input->post("son_name_1");
           $son_name_2=$this->input->post("son_name_2");
           $son_name_3=$this->input->post("son_name_3");
           $son_name_4=$this->input->post("son_name_4");
           
           $son_dob_1=$this->input->post("son_dob_1");
           $son_dob_2=$this->input->post("son_dob_2");
           $son_dob_3=$this->input->post("son_dob_3");
           $son_dob_4=$this->input->post("son_dob_4");
           
           
           $daughter_name_1=$this->input->post("daughter_name_1");
           $daughter_name_2=$this->input->post("daughter_name_2");
           $daughter_name_3=$this->input->post("daughter_name_3");
           $daughter_name_4=$this->input->post("daughter_name_4");
           
           $daughter_dob_1=$this->input->post("daughter_dob_1");
           $daughter_dob_2=$this->input->post("daughter_dob_2");
           $daughter_dob_3=$this->input->post("daughter_dob_3");
           $daughter_dob_4=$this->input->post("daughter_dob_4");
           
           
           $Husband_name = $this->input->post("Husband_name");
           $Husband_dob = $this->input->post("Husband_dob");
           $Wife_name = $this->input->post("Wife_name");
           $Wife_dob = $this->input->post("Wife_dob");
           
           $father_name = $this->input->post("father_name");
           $father_dob = $this->input->post("father_dob");
           $mother_name = $this->input->post("mother_name");
           $dob_mother = $this->input->post("dob_mother");
           
            $date = date("Y-m-d H:i:s"); 
        
            $data = array(
                        "husband"=>$Husband,
                        "wife"=>$Wife,"father"=>$Father,
                        "mother"=>$Mother,"son"=>$Son,
                        "duaghter"=>$Daughter,
                        "father_age" =>$father_age,
                        "mother_age"=>$mother_age,
                        "husband_age"=>$Husband_age,
                        "wife_age"=>$Wife_age,
                        "son_count"=>$num_sons,
                        "duaghter_count"=>$num_daughters,
                        "son1_age"=>$son_1_age,
                        "son2_age"=>$son_2_age,
                        "son3_age"=>$son_3_age,
                        "son4_age"=>$son_4_age,
                        "daughter1_age"=>$daughter_1_age,
                        "daughter2_age"=>$daughter_2_age,
                        "daughter3_age"=>$daughter_3_age,
                        "daughter4_age"=>$daughter_4_age,
                        "gender"=>$h_gender,
                        "daughter_name_1" => $daughter_name_1,
                        "daughter_name_2" => $daughter_name_2,
                        "daughter_name_3" => $daughter_name_3,
                        "daughter_name_4" => $daughter_name_4,
                        "daughter_dob_1" => $daughter_dob_1,
                        "daughter_dob_2" => $daughter_dob_2,
                        "daughter_dob_3" => $daughter_dob_3,
                        "daughter_dob_4" => $daughter_dob_4,
                        "son_name_1" =>$son_name_1,
                        "son_name_2" =>$son_name_2,
                        "son_name_3" =>$son_name_3,
                        "son_name_4" =>$son_name_4,
                        "son_dob_1" =>$son_dob_1,
                        "son_dob_2" =>$son_dob_2,
                        "son_dob_3" =>$son_dob_3,
                        "son_dob_4" =>$son_dob_4,
                        "father_name" =>$father_name,
                        "father_dob" =>$father_dob,
                        "mother_name" =>$mother_name,
                        "mother_dob" =>$dob_mother,
                        "husband_name" =>$Husband_name,
                        "husband_dob" =>$Husband_dob,
                        "wife_name" =>$Wife_name,
                        "wife_dob" =>$Wife_dob,
                        "lead_id"=>$lead_id,
                        "updated_at"=>$date,
                        "updated_by"=>$this->session->userdata("session_id"),
                   );
         
            $res = $this->lm->update_health_details($data,$lead_id);
            }
    }
    
    public function check_this_lead_already_in_policy()
    {
       if($this->session->has_userdata('logged_in'))
       {
           $lead_id = $this->input->post("lead_id");
           $res = $this->lm->check_this_lead_already_in_policy($lead_id);
           
           if($res > 0)
           {
               echo true;
           }
           else
           {
               echo false;
           }
           
       }
    }
    
    public function check_vehi_regn_no()
    {
       if($this->session->has_userdata('logged_in'))
       {
           $regn_no = $this->input->post("regn_no");
           $res = $this->lm->check_vehi_regn_no($regn_no);
           if($res > 0)
           {
               echo "Exits";
           }
           else 
           {
               echo "No";
           }
       }
    }
    
    public function fetch_user_by_agent()
    {
       if($this->session->has_userdata('logged_in'))
       {
           $agent_pos = $this->input->post("agent_pos");
           
           $res = $this->lm->fetch_user_by_agent($agent_pos);
           
           $html = "";
           
           if($res != "")
           {
               $users = $this->lm->get_user_by_id($res->user_id);
               
               $html .="<option value='".$users->id."'>".$users->name."(".$users->email_id.")"."</option>";
           }
           
           echo $html;
       }
    }
    
    public function remove_duplicates()
    {
        if($this->session->has_userdata('logged_in'))
       {
           $res = $this->lm->get_duplicate_records();

           $arr = array();
           
           foreach($res as $da)
           {
               if(in_array($da->policy_no,$arr))
               {
                   $delete = $this->lm->delete_duplicates($da->id);
                   
                   $data0 = $this->lm->delete_duplicate_leads($da->lead_id);
                   
               }
               else
               {
                  $arr [] = $da->policy_no;  
               }
               
           }
           
           echo "success";
       }
    }
    
    
    public function update_generate_policy_status()
    {
        if($this->session->has_userdata('logged_in'))
       {
           $res = $this->lm->get_gen_policy_leads_not_completed();
           
           foreach($res as $da)
           {
               $data = array("policy_status" =>"1");
               
               $update = $this->lm->update_policy_status($data,$da->id);
           }
           echo "success";
       }
    }
    
   public function update_quote_status()
   {
       if($this->session->has_userdata('logged_in'))
       {
          $id = $this->input->post("lead_id");
           $data = array("quote_status" =>"1");
           $res = $this->lm->update_quote_status($id,$data);
           echo "success";
       }
    }
    
    
    public function update_temp_policy()
    {
       if($this->session->has_userdata('logged_in'))
       {
           $id = $this->input->post("edit_id");
           $lead_id = $this->input->post("lead_id");
           $data = array(
        	        "lead_id" =>$this->input->post("lead_id"),
        	        "policy_client_ref_no"=> $this->input->post("policy_client_ref_no"),
                    "policy_cover_note_no"=> $this->input->post("policy_cover_note_no"),
                    "policy_no"=> $this->input->post("policy_no"),
                    "policy_s_date"=> $this->input->post("policy_s_date"),
                    "policy_ex_date"=> $this->input->post("policy_ex_date"),
                    "policy_premium"=> $this->input->post("policy_premium"),
                    "policy_terms"=> $this->input->post("policy_terms"),
                    "payment_frequency"=> $this->input->post("payment_frequency"),
                    "next_due_date"=> $this->input->post("next_due_date"),
                    "renewable_flag"=> $this->input->post("renewable_flag"),
                    "add_ons_opted"=> $this->input->post("add_ons_opted"),
                    "add_ons_not_opt" =>$this->input->post("add_ons_not_opt"),
                    "lead_type" =>"2",
                    "sum_insured"=> $this->input->post("sum_insured"),
                    "discount_percent"=> $this->input->post("discount_percent"),
                    "no_claim_bonus"=> $this->input->post("no_claim_bonus"),
                    "no_claim_bonus_val"=> $this->input->post("no_claim_bonus_val"),
                    "cpa"=> $this->input->post("cpa"),
                    "total_own_damage"=> $this->input->post("total_own_damage"),
                    "tot_add_on_premium"=> $this->input->post("tot_add_on_premium"),
                    "commisson_base_premium"=> $this->input->post("commisson_base_premium"),
                    "basic_tp"=> $this->input->post("basic_tp"),
                    "owner_driver_pa"=> $this->input->post("owner_driver_pa"),
                    "owner_diver_amt"=> $this->input->post("owner_diver_amt"),
                    "no_of_year_own_drv"=> $this->input->post("no_of_year_own_drv"),
                    "fuel_kit"=> $this->input->post("fuel_kit"),
                    "fuel_kit_amt"=> $this->input->post("fuel_kit_amt"),
                    "geograpical"=> $this->input->post("geograpical"),
                    "geograpical_amt"=> $this->input->post("geograpical_amt"),
                    "un_named_passenger_pa"=> $this->input->post("un_named_passenger_pa"),
                    "un_named_passenger_amt"=> $this->input->post("un_named_passenger_amt"),
                    "no_seats_per_person"=> $this->input->post("no_seats_per_person"),
                    "no_seats_per_person_amt"=> $this->input->post("no_seats_per_person_amt"),
                    "LL_paid "=> $this->input->post("llp"),
                    "LL_paid_amt"=> $this->input->post("llp_amt"),
                    "no_drv_emp"=> $this->input->post("no_drv_emp"),
                    "pa_paid_drv"=> $this->input->post("pa_paid_drv"),
                    "pa_paid_drv_amt"=> $this->input->post("pa_paid_drv_amt"),
                    "no_seats_per_person1"=> $this->input->post("no_seats_per_person1"),
                    "no_seats_per_person_amt1"=> $this->input->post("no_seats_per_person_amt1"),
                    "tot_liability_premium"=> $this->input->post("tot_liability_premium"),
                    "total_premium"=> $this->input->post("total_premium"),
                    "gst"=> $this->input->post("gst"),
                    "premium_gst"=> $this->input->post("premium_gst"),
                    "policy_issue_date"=> $this->input->post("policy_issue_date"),
                    "policy_agency_pos"=> $this->input->post("policy_agency_pos"),
                    "policy_source"=> $this->input->post("policy_source"),
                    "policy_user"=> $this->input->post("policy_user"),
                    "policy_location"=> $this->input->post("policy_location"),
                    "previous_policy_no"=> $this->input->post("previous_policy_no"),
                    "previous_insurer"=> $this->input->post("previous_insurer"),
                    "previous_insurance_plan"=> $this->input->post("previous_insurance_plan"),
                    "previous_agency_pos"=> $this->input->post("previous_agency_pos"),
                    "previous_source"=> $this->input->post("previous_source"),
                    "dectable_details"=> $this->input->post("dectable_details"),
                    "policy_additional_info"=> $this->input->post("policy_additional_info"),
                    "reference_no"=> $this->input->post("reference_no"),
                    "other_reference_no"=> $this->input->post("other_reference_no"),
                    "policy_received"=> $this->input->post("policy_received"),
                    "policy_verified"=> $this->input->post("policy_verified"),
                    "policy_verified_info"=> $this->input->post("policy_verified_info"),
                    "policy_cancelled"=> $this->input->post("policy_cancelled"),
                    "policy_cancelled_info"=> $this->input->post("policy_cancelled_info"),
                    "commisson_generation"=> $this->input->post("commisson_generation"),
                    "payment_type"=> $this->input->post("payment_type"),
                    "pay_ref_no"=> $this->input->post("pay_ref_no"),
                    "bank_name"=> $this->input->post("bank_name"),
                    "payment_check_date"=> $this->input->post("payment_check_date"),
                    "payment_and_check_no"=> $this->input->post("payment_and_check_no"),
                    "remarks"=> $this->input->post("remarks"),
                    "company"=> $this->input->post("company"),
                    "created_by"=> $this->session->userdata('session_id'),
                    "created_at"=> date("Y-m-d H:i:s"),
                    );
                  $temp_data = $this->lm->update_temp_data($data,$id);
                  $data_1 = array("policy_status" =>"1");
                 $update = $this->lm->update_policy_status($data_1,$lead_id);
       }
    }
    
    public function get_un_assigned_ai_leads()
    {
      if($this->session->has_userdata('logged_in'))
       {
           $res = $this->lm->get_unassigned_ai_leads();
           
           foreach($res as $da)
           {
               $area_incharge = $this->lm->get_area_incharge_1($da->agency_and_pos);
               
              if($area_incharge != "")  
              {
                   $data = array("area_incharge" =>$area_incharge->area_incharge);
                   
                   $update = $this->lm->update_area_incharge_in_leads($data,$da->id);
              }
           }
           
           echo "success";
       }
    }
    
    // business complete
    
    
     public function business_complete()
    {
        if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
    	{    		
		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
		   	$data["users"] = $this->lm->fetch_users();
		   	$data["client_type"] = $this->lm->fetch_client_type();
		   	$data["business"] = $this->lm->fetch_business_type();
		   	$data["class"] = $this->lm->fetch_list_of_policy_type();
    		$this->load->view('header',$pro_data);
    		$this->load->view('business_complete',$data);
    		$this->load->view('footer',$pro_data);
	    }
	    else if($this->session->has_userdata('logged_in') && ($this->session->userdata('session_role') == "user" || $this->session->userdata('session_role') == "AI"))
	    {
	        $check_user_i = $this->mm->fetch_user_permissions($this->session->userdata('session_id'));
	        
	        if($check_user_i->policy_view == "1")
	        {
    	        $session_id = $this->session->userdata('session_id');
    	        $pro_data["project_info"] = $this->mm->fetch_project_info();
    	        $data["users"] = $this->lm->fetch_users_by_user($session_id);
    	        $data["client_type"] = $this->lm->fetch_client_type();
    	        $data["business"] = $this->lm->fetch_business_type();
    	        $data["class"] = $this->lm->fetch_list_of_policy_type();
        		$this->load->view('header',$pro_data);
        		$this->load->view('business_complete',$data);
        		$this->load->view('footer',$pro_data);
	        }
	        else
	        {
	            echo "<script>alert('Permission Denied');window.location.href='home';</script>";
	        }
	    }
	    else
	    {
	    	redirect("login");
	    }
    }
    
   public function fetch_business_complete()
   {
      	if($this->session->has_userdata('logged_in')) 
    	{
            $draw = intval($this->input->post("draw"));
            
            $res = $this->lm->fetch_business_complete();
          
            $arr = [];
            $a = $_POST['start'];
            
            
            $usr_name = "";
            $agn_name = "";
            $ai = "";
            
            foreach($res as $da)
            {
                $a++;
                
               $client_name = "<a href='#' onclick=view_data(".$da->lead_id.")>".$da->client_name."</a>";

                 if($da->policy_agency_pos != "all")
            	 {
            	     if($da->policy_agency_pos != "")
            	     {
                	     $get_agent_name = $this->lm->get_agent_name($da->policy_agency_pos);
                	     $agn_name = $get_agent_name->name;
            	     }
            	     else
            	     {
            	         $agn_name = "";
            	     }
            	 }
            	 else
            	 {
            	     $agn_name = "";
            	 }
            	 
            	 if($da->assigned_user != "all")
            	 {
            	     if($da->assigned_user != "")
            	     {
                	     $get_user = $this->lm->get_user_name($da->assigned_user);
                	     
                	     if($usr_name != "")
                	     {
                	       $usr_name = $get_user->name;
                	     }
                	     else
                	     {
                	         $usr_name = "";
                	     }
            	     }
            	     else
            	     {
            	         $usr_name = "";
            	     }
            	 }
            	 else
            	 {
            	     $usr_name = "";
            	 }
            	 
        	    if($da->area_incharge != "all")
                {
                    if($da->area_incharge != "")
                    {
                         $ai = $this->lm->get_area_incharge($da->area_incharge);
                         
                         if($ai != null)
                         {
                           $ai = $ai->name;
                         }
                         else
                         {
                             $ai = "";
                         }
                    }
                    else
                    {
                            $ai = "";
                    }
                }
                else
                {
                     $ai = "";
                } 
                
                $action = "<a href='generate_policy?id=".$da->lead_id."' class='btn btn-primary btn-xs'><i class='fa fa-file'></i> Save policy</a>";
                
                $arr[] = array(
                           $a,
                           $client_name,
                           $da->mobile_no,
                           $da->lclass,
                           $da->p_type,
                           $da->b_type,
                           $da->policy_no,
                          "<span class='pull-right'>".number_format($da->total_own_damage,2)."</span>",
                         "<span class='pull-right'>".number_format($da->tot_liability_premium,2)."</span>",
                            "<span class='pull-right'>".number_format($da->total_premium,2)."</span>",
                         "<span class='pull-right'>".number_format($da->gst,2)."</span>",
                          $date = date_format(date_create($da->policy_issue_date),"d-m-Y"),
                           $agn_name,
                           $usr_name,
                           $ai,
                           $action,
                   );
            }
            
            $result = array(
            "draw"=> $draw,
            "recordsTotal"=> $this->lm->get_filtered_business_complete_count(),
            "recordsFiltered"=> $this->lm->get_all_business_complete_count(),
            "data"=>$arr,
            );
            echo json_encode($result);
    	}
   }
   
   	public function view_business_complete_details()
	{
	    if($this->session->has_userdata('logged_in')) 
    	{
    	    $lead_id = $this->input->post("id");
    	    $res = $this->lm->view_lead_details($lead_id);
    	    $data = $this->lm->get_vechicle_details($lead_id);
    	    $client_id = $res->client_id;
    	    $get_leads_id = $this->lm->get_leads_id($client_id);
    	    
    	    
    	    $html = "";
    	    $content_1 = "";
    	    
    	    $v_info = [];
    	    
        	    if($data != null)
        	    {
        	        if($data->policy_type == "1" && $data->policy_type == "3")
        	        {
        	          $v_info = $this->lm->get_car_details($lead_id);  
        	        }
        	        else if($data->policy_type == "2" && $data->policy_type == "4")
        	        {
        	            $v_info = $this->lm->get_bike_details($lead_id);  
        	        }
                    else if($data->policy_type == "7" || $data->policy_type == "12" || $data->policy_type == "13" || $data->policy_type == "14" || $data->policy_type == "59" || $data->policy_type == "60" || $data->policy_type == "65" || $data->policy_type == "66" || $data->policy_type == "68" || $data->policy_type == "69" || $data->policy_type == "70")
                	{
                		$v_info = $this->lm->get_pc_details($lead_id,$data->policy_type);
                	}
                	else if($data->policy_type == "8" || $data->policy_type == "9" || $data->policy_type == "10" || $data->policy_type == "15" || $data->policy_type == "16" || $data->policy_type == "61")
                	{
                		$v_info = $this->lm->get_gc_details($lead_id,$data->policy_type);
                	}
                	else if($data->policy_type == "20")
                	{
                		$v_info = $this->lm->fetch_make_misc($lead_id);
                	}
                	else if($data->policy_type == "55")
                	{
                		$v_info = $this->lm->fetch_make_scooter($lead_id);
                	}
        	    }
    	    
    	         if($res->class == "1")
        	     {
        	        $html .="<h4 style='color:#2196f3;font-family: system-ui;'><u>Vehicle Documents</u></h4><div class='row'>";
        	        
        	        foreach($get_leads_id as $da)
        	        {
        	              $documents = $this->lm->get_vechile_documents($da->id);
        	              
        	              foreach($documents as $doc)
        	              {
        	                  $html .= "<div class='col-md-3'><div class='form-group'><a href='./datas/documents/".$doc->document_file."' target='_blank'><i class='fa fa-file-pdf-o' style='font-size:48px;color:red'></i></a></div></div>";
        	              }
        	        }
        	        $html .="</div>";
        	     }
        	     else if($res->class == "10")
        	     {
        	        $content_1 .="<h4 style='color:#2196f3;font-family: system-ui;'><u>Policy Quotations</u></h4><div class='row'>";
        	       
        	        foreach($get_leads_id as $da)
        	        {
        	              $documents = $this->lm->fetch_quote_files($da->id);
        	              
        	              foreach($documents as $doc)
        	              {
        	                  $content_1 .= "<div class='col-md-3'><div class='form-group'><a href='./datas/documents/".$doc->file."' target='_blank'><i class='fa fa-file-pdf-o' style='font-size:48px;color:red'></i></a></div><span>&nbsp;".$doc->file_name."</span></div>";
        	              }
        	        }
        	        
        	        $content_1 .="</div>";
        	     }
    	  
    	        $content = "";
    	        $policy_info = $this->lm->get_temp_policy_informations($lead_id);
    	        
    	           $content .="<div class='row'>";
    	        
        	        foreach($policy_info as $p)
        	        {
        	            $content .="<h4 style='color:#2196f3;font-family: system-ui;margin-left:15px;'><u>Policy Details - ".$p->business_name." </u></h4><div class='col-md-6'>
        	                         <div class='row'>
            	                           <div class='col-md-4'>
                	                        <label>Policy No  </label>
                	                        </div>
                	                        <div class='col-md-1'> :
                	                        </div>
                	                       <div class='col-md-7'>
                	                           <p>".$p->policy_no."</p>
                	                       </div>
                	                     </div>
            	                       </div>
            	                       
                    	               <div class='col-md-6'>
                        	               <div class='row'>
                	                           <div class='col-md-4'>
                    	                          <label>Insurer Name</label>
                    	                        </div>
                    	                        <div class='col-md-1'> :</div>
                	                       <div class='col-md-7'>
                	                        <p>".$p->company_name."</p>
                	                      </div>
                	                     </div>
            	                       </div>
            	                       
                	                   <div class='col-md-6'>
                        	               <div class='row'>
                	                           <div class='col-md-4'>
                	                              <label>Business Type</label>
                	                          </div>
                    	                        <div class='col-md-1'> :</div>
                        	                   <div class='col-md-7'>
                    	                          <p>".$p->business_name."</p>
                    	                      </div>
                	                     </div>
            	                       </div>
            	                       
            	                       
            	                       <div class='col-md-6'>
                        	               <div class='row'>
                	                           <div class='col-md-4'>
                	                              <label>Premium Cover</label>
                	                          </div>
                    	                        <div class='col-md-1'> :</div>
                        	                   <div class='col-md-7'>
                    	                          <p>".$p->policy_premium_name."</p>
                    	                      </div>
                	                     </div>
            	                     </div>
            	            
                	                   <div class='col-md-6'>
                        	               <div class='row'>
                	                           <div class='col-md-4'>
                	                             <label>Class</label>
                	                            </div>
                	                             <div class='col-md-1'> :</div>
                    	                    <div class='col-md-7'>
                	                        <p>".$p->class_name."</p>
                	                       </div>
                	                     </div>
            	                       </div>
                	                   
                	                  <div class='col-md-6'>
                        	               <div class='row'>
                	                           <div class='col-md-4'>
                	                                <label>Policy Type</label>
                	                           </div>
                	                          <div class='col-md-1'> :</div>
                    	                    <div class='col-md-7'>
                	                           <p>".$p->policy_type."</p>
                	                        </div>
                	                     </div>
            	                       </div>
            	                       
            	                       
            	                       <div class='col-md-6'>
                        	               <div class='row'>
                	                           <div class='col-md-4'>
                	                              <label>Policy Start Date</label>
                	                             </div>
                	                         <div class='col-md-1'> :</div>
                    	                       <div class='col-md-7'>
                	                             <p>".date_format(date_create($p->policy_s_date),"d-M-Y")."</p>
                	                      </div>
                	                     </div>
            	                       </div>
            	                       
            	                       <div class='col-md-6'>
                        	               <div class='row'>
                	                           <div class='col-md-4'>
                	                              <label>Policy Exp Date</label>
                	                             </div>
                	                         <div class='col-md-1'> :</div>
                    	                       <div class='col-md-7'>
                	                             <p>".date_format(date_create($p->policy_ex_date),"d-M-Y")."</p>
                	                      </div>
                	                     </div>
            	                       </div>
                	                   
                	                    <div class='col-md-6'>
                        	               <div class='row'>
                	                           <div class='col-md-4'>
                	                              <label>Sum Insured</label>
                	                             </div>
                	                         <div class='col-md-1'> :</div>
                    	                       <div class='col-md-7'>
                	                             <p>".number_format($p->sum_insured,2)."</p>
                	                      </div>
                	                     </div>
            	                       </div>";
            	                       
            	                       
            	                       if($res->class == "1")
            	                       {
                    	                   $content .="<div class='col-md-6'>
                                	               <div class='row'>
                        	                           <div class='col-md-4'>
                        	                              <label>Total Own Damage</label>
                        	                             </div>
                        	                         <div class='col-md-1'> :</div>
                                	                   <div class='col-md-7'>
                            	                        <p>".number_format($p->total_own_damage,2)."</p>
                            	                       </div>
                        	                     </div>
                    	                       </div>
                    	                       
                    	                            
                    	                    <div class='col-md-6'>
                            	               <div class='row'>
                    	                           <div class='col-md-4'>
                    	                              <label>Total Tp</label>
                    	                           </div>
                    	                        <div class='col-md-1'> :</div>
                        	                       <div class='col-md-7'>
                    	                        <p>".number_format($p->basic_tp,2)."</p>
                    	                       </div>
                    	                     </div>
                	                       </div>";
            	                       }
            	                  
                	                 $content .="<div class='col-md-6'>
                        	               <div class='row'>
                	                           <div class='col-md-4'>
                	                               <label>Net Premium </label>
                	                            </div>
                	                        <div class='col-md-1'> :</div>
                    	                       <div class='col-md-7'>
                	                        <p>".number_format($p->total_premium,2)."</p>
                	                      </div>
                	                     </div>
            	                       </div>
            	                       
                	                   <div class='col-md-6'>
                        	               <div class='row'>
                	                         <div class='col-md-4'>
                	                             <label>GST</label>
                	                        </div>
                	                        <div class='col-md-1'> :</div>
                    	                       <div class='col-md-7'>
                	                        <p>".number_format($p->gst,2)."</p>
                	                       </div>
                	                     </div>
            	                       </div>
            	                       
            	                       <div class='col-md-6'>
                        	               <div class='row'>
                	                         <div class='col-md-4'>
                	                             <label>Agent/ Pos Code </label>
                	                        </div>
                	                        <div class='col-md-1'> :</div>
                    	                       <div class='col-md-7'>
                	                        <p>".$p->agent_pos_code."</p>
                	                       </div>
                	                     </div>
            	                       </div>
            	                       <hr/>";
        	        }
        	        
        	         $content .="</div>";
        	         
        	        $policy_docs ="<h4 style='color:#2196f3;font-family: system-ui;'><u>Policy Documents</u></h4>";
        	        
        	        $policy_docs .="<div class='row'>";
        	        
            	          $documents = $this->lm->get_policy_documents($lead_id);
        	              
        	              foreach($documents as $doc)
        	              {
        	                  $policy_docs .= "<div class='col-md-3'><div class='form-group'><a href='./datas/documents/".$doc->document."' target='_blank'><i class='fa fa-file-pdf-o' style='font-size:48px;color:red'></i></a></div></div>";
        	              }
        	        $policy_docs .="</div>";
    	           echo json_encode(array("p_info"=>$res,"v_info" =>$v_info,"docs"=>$html,"sme_quote" =>$content_1,"policy_info"=>$content,"policy_docs" =>$policy_docs));
    	}
	}
	
	
     	public function fetch_sme_policy_details()
	    {
	        if($this->session->has_userdata('logged_in'))
    	    {
    	        $sme_id = $this->input->post("sme_id");
    	        $res = $this->lm->fetch_sme_policy_details($sme_id);
    	        echo json_encode($res);
    	    }
	    }
	    
	    
	public function save_sme_details()
	{
		if($this->session->has_userdata('logged_in')) 
    	{   
    	    $smepolicy = $this->input->post("smepolicy");
    	    $lead_id = $this->input->post("lead_id");
    	    $ins_period_from =$this->input->post("ins_period_from");
    		$ins_period_todate = $this->input->post("ins_period_todate");
    		$occupancy =$this->input->post("occupancy");
    		$commodity =$this->input->post("commodity");
    		$transport =$this->input->post("transport");
    		$packing =$this->input->post("packing");
    		$b_valuation_import =$this->input->post("b_valuation_import");
    		$b_valuation_inland =$this->input->post("b_valuation_inland");
    		$voyage_export =$this->input->post("voyage_export");
    		$voyage_import =$this->input->post("voyage_import");
    		$voyage_inland =$this->input->post("voyage_inland");
    		$turnover =$this->input->post("turnover");
    		$initial_sum_insured =$this->input->post("initial_sum_insured");
    		$sales_domestic =$this->input->post("sales_domestic");
    		$purchase_import =$this->input->post("purchase_import");
    		$purchase_domestic =$this->input->post("purchase_domestic");
    		$bottomlimit =$this->input->post("bottomlimit");
    		$locationimport =$this->input->post("locationimport");
    		$bottom_import_limit =$this->input->post("bottom_import_limit");
    		$location_import_limit =$this->input->post("location_import_limit");
    		$current_insurer =$this->input->post("current_insurer");
    		$claim_history =$this->input->post("claim_history");
    		$date =$this->input->post("date");
    		
    		$fire_from_date =$this->input->post("fire_from_date");
    		$fire_to_date =$this->input->post("fire_to_date");
    		$fire_occupancy =$this->input->post("fire_occupancy");
    		$commodity =$this->input->post("commodity");
    		$financial_institution =$this->input->post("financial_institution");
    		$fire_particulars_1 =$this->input->post("fire_particulars_1");
    		$fire_sum_ins_1 =$this->input->post("fire_sum_ins_1");
    		$burglary_sum_ins_1 =$this->input->post("burglary_sum_ins_1");
    		$fire_particulars_2 =$this->input->post("fire_particulars_2");
    		$fire_sum_ins_2 =$this->input->post("fire_sum_ins_2");
    		$burglary_sum_ins_2 =$this->input->post("burglary_sum_ins_2");
    		$fire_particulars_3 =$this->input->post("fire_particulars_3");
    		$fire_sum_ins_3 =$this->input->post("fire_sum_ins_3");
    		$burglary_sum_ins_3 =$this->input->post("burglary_sum_ins_3");
    		$fire_particulars_4 =$this->input->post("fire_particulars_4");
    		$fire_sum_ins_4 =$this->input->post("fire_sum_ins_4");
    		$burglary_sum_ins_4 =$this->input->post("burglary_sum_ins_4");
    		$clause_under_burglary =$this->input->post("clause_under_burglary");
    		$fire_expiry_insurer =$this->input->post("fire_expiry_insurer");
    		$fire_date =$this->input->post("fire_date");
    		
    		//wc compensation
    		$pre_no_of_emp = $this->input->post("pre_no_of_emp");
            $cur_no_of_emp = $this->input->post("cur_no_of_emp");
            $wc_claim_paid = $this->input->post("wc_claim_paid");
            $wc_tot_claim = $this->input->post("wc_tot_claim");
            $wc_premium_paid = $this->input->post("wc_premium_paid");
            $wc_out_claim = $this->input->post("wc_out_claim");
            $wc_last_claim = $this->input->post("wc_last_claim");
            $wc_wages_per_mon = $this->input->post("wc_wages_per_mon");
            $wc_no_supervisor = $this->input->post("wc_no_supervisor");
            $wc_no_site_engineer = $this->input->post("wc_no_site_engineer");
            $wc_salary_per_supervisor = $this->input->post("wc_salary_per_supervisor");
            $wc_salary_engineer = $this->input->post("wc_salary_engineer");
            
            //GMC
            
            $gmc_current_status = $this->input->post("gmc_current_status");
        	$gmc_cur_ins = $this->input->post("gmc_cur_ins");
        	$gmc_premium_date = $this->input->post("gmc_premium_date");
        	$gmc_renewal_tot = $this->input->post("gmc_renewal_tot");
        	$gmc_period_of_ins = $this->input->post("gmc_period_of_ins");
        	$gmc_premium_inscep = $this->input->post("gmc_premium_inscep");
        	$gmc_total_lives = $this->input->post("gmc_total_lives");
        	$gmc_incurred_claims = $this->input->post("gmc_incurred_claims");
        	$gmc_sum_ins_app = $this->input->post("gmc_sum_ins_app");
        	$gmc_family_def = $this->input->post("gmc_family_def");
        	$gmc_exclusion_waiver_year = $this->input->post("gmc_exclusion_waiver_year");
        	$gmc_maternity_coverage = $this->input->post("gmc_maternity_coverage");
        	$gmc_hospital_coverage = $this->input->post("gmc_hospital_coverage");
        	$gmc_icu_limits = $this->input->post("gmc_icu_limits");
        	$gmc_int_desease_cover = $this->input->post("gmc_int_desease_cover");
        	$gmc_ppn_cause = $this->input->post("gmc_ppn_cause");
        	$gmc_claim_sub_mission = $this->input->post("gmc_claim_sub_mission");
        	$gmc_lasik_surgery = $this->input->post("gmc_lasik_surgery");
        	$gmc_corporate_buffer = $this->input->post("gmc_corporate_buffer");
        	$gmc_cataract_surgery = $this->input->post("gmc_cataract_surgery");
        	$gmc_comorbities = $this->input->post("gmc_comorbities");
        	$gmc_metail_illness = $this->input->post("gmc_metail_illness");
        	$gmc_addition = $this->input->post("gmc_addition");
        	$gmc_current_status = $this->input->post("gmc_current_status");
        	$gmc_covid_hospitlization = $this->input->post("gmc_covid_hospitlization");
        	$gmc_day_care = $this->input->post("gmc_day_care");
        	$gmc_sum_ins = $this->input->post("gmc_sum_ins");
        	$gmc_policy_type = $this->input->post("gmc_policy_type");
        	$gmc_exclusion_wavier = $this->input->post("gmc_exclusion_wavier");
        	$gmc_child_day_cover = $this->input->post("gmc_child_day_cover");
        	$gmc_room_rent = $this->input->post("gmc_room_rent");
        	$gmc_sub_limits = $this->input->post("gmc_sub_limits");
        	$gmc_ext_desease_cover = $this->input->post("gmc_ext_desease_cover");
        	$gmc_claim_int = $this->input->post("gmc_claim_int");
        	$gmc_int_capping = $this->input->post("gmc_int_capping");
        	$gmc_ayush_treatment = $this->input->post("gmc_ayush_treatment");
        	$gmc_robotic = $this->input->post("gmc_robotic");
        	$gmc_ambulance = $this->input->post("gmc_ambulance");
        	$gmc_sinus_surgery = $this->input->post("gmc_sinus_surgery");
        	$gmc_age_macular = $this->input->post("gmc_age_macular");
        	$gmc_terroism_deases = $this->input->post("gmc_terroism_deases");
        	$gmc_special_coverage = $this->input->post("gmc_special_coverage");
            
           
    
        	if($smepolicy == "74")
        	{ 	
        		$data = array(
        		              "sme_id" => $smepolicy,
        		              "lead_id" =>$lead_id,
        		              "ins_period_from"=>$ins_period_from,
        		              "ins_period_todate"=>$ins_period_todate, 
        		              "occupancy" => $occupancy,
        		              "commodity" =>$commodity, 
        		              "transport" =>$transport,
        		              "packing" =>$packing,
        		              "b_valuation_import"=>$b_valuation_import,
        		              "b_valuation_inland"=>$b_valuation_inland,
        		              "transport"=>$transport,
        		              "voyage_export"=>$voyage_export,
        		              "voyage_import"=>$voyage_import,
        		              "voyage_inland"=>$voyage_inland,
        		              "turnover"=>$turnover,
        		              "initial_sum_insured"=>$initial_sum_insured,
        		              "sales_domestic" =>$sales_domestic,
        		              "purchase_import" =>$purchase_import,
        		              "bottomlimit"=>$bottomlimit,
        		              "bottom_import_limit"=>$bottom_import_limit,
        		              "location_import_limit"=>$location_import_limit,
        		              "locationimport" =>$locationimport,
        		              "current_insurer"=>$current_insurer,
        		              "claim_history" => $claim_history,
        		              "date" => $date);
        		              
        	    	$res =$this->lm->add_sme_maraine_details($data);
        	}
        	else if($smepolicy == "78")
        	{ 
        	     $data =array(
                		        "sme_id" => $smepolicy,
                		        "lead_id" =>$lead_id,
                		        "fire_from_date" =>$fire_from_date,
                		        "fire_to_date" =>$fire_to_date,
                		        "fire_occupancy" =>$fire_occupancy,
                		        "financial_institution" =>$financial_institution,
                		        "fire_particulars_1" =>$fire_particulars_1,
                		        "burglary_sum_ins_1" =>$burglary_sum_ins_1,
                		        "fire_particulars_2" =>$fire_particulars_2,
                		        "fire_sum_ins_2" => $fire_sum_ins_2,
                		        "burglary_sum_ins_3" => $burglary_sum_ins_3,
                		        "fire_particulars_3" => $fire_particulars_3,
                		        "fire_sum_ins_3" => $fire_sum_ins_3,
                		        "burglary_sum_ins_3"=>$burglary_sum_ins_3,
                		        "fire_particulars_4" =>$fire_particulars_4,
                		        "fire_sum_ins_4" =>$fire_sum_ins_4,
                		        "burglary_sum_ins_4" =>$burglary_sum_ins_4,
                		        "clause_under_burglary"=>$clause_under_burglary,
                		        "fire_expiry_insurer" =>$fire_expiry_insurer,
                		        "fire_date" =>$fire_date
                		             );
                		      $this->lm->add_sme_fire_and_burgulary($data);
        	}
	        else if($smepolicy == "77")
	        {
	            $data = array(
	                           "sme_id" =>$smepolicy,
	                           "lead_id" =>$lead_id,
	                           "pre_no_of_employee" =>$pre_no_of_emp,
	                           "cur_no_of_employee" =>$cur_no_of_emp,
	                           "claim_paid" =>$wc_claim_paid,
	                           "outstanding_claim" =>$wc_out_claim,
	                           "total_claim" =>$wc_tot_claim,
	                           "last_three_yrs_claim" =>$wc_premium_paid,
	                           "premium_paid" =>$wc_premium_paid,
	                           "wages_per_emp" =>$wc_wages_per_mon,
	                           "salary_per_supervisor" =>$wc_salary_per_supervisor,
	                           "no_of_engineer" =>$wc_no_site_engineer,
	                           "salary_site_engineer" =>$wc_salary_engineer,
	                           "created_by" =>$this->session->userdata("session_id"),
	                           "created_date" =>date("Y-m-d H:i:s"));
	                           
	            $res = $this->lm->add_workman_compensation_details($data);
	        }
	        else if($smepolicy == "75")
	        {
               $data = array(
                 "sme_id" => $smepolicy,
        		 "lead_id" =>$lead_id,
                "gmc_current_status" =>$gmc_current_status,
                "gmc_cur_ins" =>$gmc_cur_ins,
                "gmc_premium_date" =>$gmc_premium_date,
                "gmc_renewal_tot" =>$gmc_renewal_tot,
                "gmc_period_of_ins" =>$gmc_period_of_ins,
                "gmc_premium_inscep" =>$gmc_premium_inscep,
                "gmc_total_lives" =>$gmc_total_lives,
                "gmc_incurred_claims" =>$gmc_incurred_claims,
                "gmc_sum_ins_app" =>$gmc_sum_ins_app,
                "gmc_family_def" =>$gmc_family_def,
                "gmc_exclusion_waiver_year" =>$gmc_exclusion_waiver_year,
                "gmc_maternity_coverage" =>$gmc_maternity_coverage,
                "gmc_hospital_coverage" =>$gmc_hospital_coverage,
                "gmc_icu_limits" =>$gmc_icu_limits,
                "gmc_int_desease_cover" =>$gmc_int_desease_cover,
                "gmc_ppn_cause" =>$gmc_ppn_cause,
                "gmc_claim_sub_mission" =>$gmc_claim_sub_mission,
                "gmc_lasik_surgery" =>$gmc_lasik_surgery,
                "gmc_corporate_buffer" =>$gmc_corporate_buffer,
                "gmc_cataract_surgery" =>$gmc_cataract_surgery,
                "gmc_comorbities" =>$gmc_comorbities,
                "gmc_metail_illness" =>$gmc_metail_illness,
                "gmc_addition" =>$gmc_addition,
                "gmc_current_status" =>$gmc_current_status,
                "gmc_covid_hospitlization" =>$gmc_covid_hospitlization,
                "gmc_day_care" =>$gmc_day_care,
                "gmc_sum_ins" =>$gmc_sum_ins,
                "gmc_policy_type" =>$gmc_policy_type,
                "gmc_exclusion_wavier" =>$gmc_exclusion_wavier,
                "gmc_child_day_cover" =>$gmc_child_day_cover,
                "gmc_room_rent" =>$gmc_room_rent,
                "gmc_sub_limits" =>$gmc_sub_limits,
                "gmc_ext_desease_cover" =>$gmc_ext_desease_cover,
                "gmc_claim_int" =>$gmc_claim_int,
                "gmc_int_capping" =>$gmc_int_capping,
                "gmc_ayush_treatment" =>$gmc_ayush_treatment,
                "gmc_robotic" =>$gmc_robotic,
                "gmc_ambulance" =>$gmc_ambulance,
                "gmc_sinus_surgery" =>$gmc_sinus_surgery,
                "gmc_age_macular" =>$gmc_age_macular,
                "gmc_terroism_deases" =>$gmc_terroism_deases,
                "gmc_special_coverage" =>$gmc_special_coverage,
                "created_date" =>date("Y-m-d H:i:s"),
                "created_by" =>$this->session->userdata("session_id"),
                );
                
              $res = $this->lm->add_gmc_details($data);
	        }
		    echo "success";
	   }
	   
	}
	   public function upload_sme_files()
	   {
    	   if($this->session->has_userdata('logged_in')) 
        	{ 
                    $file_type = $this->input->post("file_name");
                    $count = count($_FILES['files']['name']);
                    $lead_id = $this->input->post("lead_id");
                    $data = array();
                    for($i=0;$i<$count;$i++)
                    {
                          if(!empty($_FILES['files']['name'][$i]))
                          {
                                $_FILES['file']['name'] = $_FILES['files']['name'][$i];
                                $_FILES['file']['type'] = $_FILES['files']['type'][$i];
                                $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
                                $_FILES['file']['size'] = $_FILES['files']['size'][$i];
                                $config['upload_path'] = './datas/sme_quotes/'; 
                                $config['allowed_types'] = '*';
                                $config['file_name'] = $_FILES['files']['name'][$i];
                                
                                $this->load->library('upload',$config); 
                                
                                if($this->upload->do_upload('file'))
                                {
                                    $uploadData = $this->upload->data();
                                    $filename = $uploadData['file_name'];
                                    $data0 = array("lead_id" =>$lead_id,"file" =>$filename,"file_name" =>$file_type[$i]);
                                    $res0 = $this->lm->add_sme_files($data0);
                                }
                           }
                    }
                
                echo "<script>alert('File Uploaded Successfully');window.location.href='create_lead?id=$lead_id'</script>";
        	}
	   }
	   
	   
	   public function fetch_quote_files()
	   {
	        if($this->session->has_userdata('logged_in')) 
        	{
        	    $lead_id = $this->input->post("lead_id");
        	    
        	    $res = $this->lm->fetch_quote_files($lead_id);
        	    
        	    $content = "";
        	    
        	    $content .= "<div class='row'>";
        	    
        	    foreach($res as $da)
        	    {
        	         $content .= "<div class='col-md-4'>
        	                       <div class = 'form-group'>
        	                         <a href= './datas/sme_quotes/".$da->file."' target='_blank'>&nbsp;&nbsp;<i class='fa fa-file fa-4x'></i><span>&nbsp;&nbsp;".$da->file_name."</span></a>
        	                      </div></div>";
        	    }
        	    
        	    $content .= "</div>";
        	    
        	    echo $content;
        	}
	   }
	   
	   public function fetch_total_premium()
	   {
	        if($this->session->has_userdata('logged_in')) 
        	{
        	    $lead_id = $this->input->post("lead_id");
        	    $res = $this->lm->get_total_premium($lead_id);
        	    echo json_encode($res);
        	}
	   }
	   
	  public function add_sme_commission()
	  {
            if($this->session->has_userdata('logged_in')) 
            {
                $own_com_amt  = $this->input->post("own_com_amt");
                $agn_com_amt = $this->input->post("agn_com_amt");
                $ai_com_amt = $this->input->post("ai_com_amt");
                $sub_agn_1  = $this->input->post("sub_agn_1");
                $sub_agn_2 = $this->input->post("sub_agn_2");
                $sub_agn_amt1 = $this->input->post("sub_agn_amt1");
                $sub_agn_amt2 = $this->input->post("sub_agn_amt2");
                $lead_id = $this->input->post("lead_id");
                $policy_no = $this->input->post("policy_no");
               
                    if(!$this->lm->check_this_policy_already_exits($policy_no))
                    {
                                $check = $this->lm->check_lead_id_already_exits_in_policy($lead_id);
                                
                                if($check > 0)
                                {
                                    echo "Exits";
                                }
                                else
                                {
                                    $res = $this->lm->save_policy_data($lead_id);
                                    
                                    if($res)
                                    {
                                        $data = array(
                                                     "own_commission_amt" =>$own_com_amt,
                                                     "agent_commission_amt" =>$agn_com_amt,
                                                     "ai_com" =>$ai_com_amt,
                                                     "sub_agn_1" =>$sub_agn_1,
                                                     "sub_agn_2" =>$sub_agn_2,
                                                     "sub_agn_amt_1" =>$sub_agn_amt1,
                                                     "sub_agn_amt_2" =>$sub_agn_amt2,
                                                 );
                                         
                                         $res = $this->lm->update_sme_commission($data,$lead_id);
                                         
                                         echo "success";
                                    }
                                }
                    }
                    else
                    {
                        echo "Exits";
                    }
            }
	  }
	  
	  // acc own commission
	  
	  public function acc_own_commission($lead_id)
	  {
	       if($this->session->has_userdata('logged_in')) 
           {
               $res = $this->lm->get_commission_details($lead_id);
               $own_com_id = "acc212";
               $own_com = 0;
            
                $date = date("Y-m-d H:i:s");
                $year = date('y');
                $month = date('m');
                
                if($month < 4)
                {
                    $year = $year-1;
                }
               
                $x = 0;
                do 
                {
                  $x++;
                  $new_sr_no = "OC".$x."/".$year;
                } 
                while($this->lm->check_sr_no_already_exits($new_sr_no));
                    
          
               if($res != "" || $res != null)
               {
                   $own_com = floor($res->own_commission_amt);
                   $tds = 0;
                   $tds = $own_com * 10/100;
                   
                   $check = $this->lm->check_ac_policy_no_already_exits($res->policy_no);
                   
                   if($check < 1)
                   {
                       $data = array(
                                "sr_no" =>$new_sr_no,
                                "credit"=>$own_com,
                                "cr_parent_id" =>$own_com_id,
                                "tds" =>$tds,
                                "lead_id"=>$lead_id,
                                "sub_id" =>$res->policy_no,
                                "note" =>"Own commission Credit",
                                "datetime" =>date("Y-m-d H:i:s")
                                );
                       
                       $res0 = $this->lm->add_acc_own_commission($data);
                   }
               }
               //echo "success";
           }
	  }
	  
	  public function acc_agn_commission($lead_id)
	  {
	      if($this->session->has_userdata('logged_in')) 
          {
                $res = $this->lm->get_commission_details($lead_id);
                
                $own_com_id = "acc212";
                $agn_com_id = "acc213";
              
                $agn_com = 0;
                $date = date("Y-m-d H:i:s");
                $year = date('y');
                $month = date('m');
                
                if($month < 4)
                {
                    $year = $year-1;
                }
               
                $x = 0;
                do 
                {
                    $x++;
                    $new_sr_no = "AC".$x."/".$year;
                } 
                while($this->lm->check_sr_no_already_exits($new_sr_no));
               
               if($res != "" || $res != null)
               {
                    $agn_com = floor($res->agent_commission_amt);
                    $tds = 0;
                    $tds = $agn_com * 5/100;
                  
                     $data =   array(
                                "sr_no" =>$new_sr_no,
                                "debit"=>$agn_com,
                                "cr_parent_id" =>$agn_com_id,
                                "dr_parent_id" =>$own_com_id,
                                "tds" =>$tds,
                                "sub_id" =>$res->policy_agency_pos,
                                "lead_id"=>$lead_id,
                                "note" =>"Own commission Debit",
                                "datetime" =>date("Y-m-d H:i:s")
                                );
                                
                     $res0 = $this->lm->add_acc_own_commission($data);
                     
                       $data1 =   array(
                                "sr_no" =>$new_sr_no,
                                "credit"=>$agn_com,
                                "cr_parent_id" =>$agn_com_id,
                                "dr_parent_id" =>$own_com_id,
                                "tds" =>$tds,
                                "sub_id" =>$res->policy_agency_pos,
                                "lead_id"=>$lead_id,
                                "note" =>"Agent commission Credit",
                                "datetime" =>date("Y-m-d H:i:s")
                                );
                                
                     $res1 = $this->lm->add_acc_own_commission($data1);
                     
               }
               
          }
	  }


}

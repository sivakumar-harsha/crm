<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ClaimCtrl extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('Configmod','cm');
		$this->load->model('MasterMod','mm');
		$this->load->model('ClaimMod','clm');
		$this->load->model('LeadMod','lm');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper('cookie');
	}
 
     public function claim()
     {
          if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
        	{    		
    		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
    		   	$data["users"]=$this->cm->fetch_users();
    		   	$data["agents_pos"] = $this->clm->list_of_pos_and_agents();
    		   	$data["customers"] = $this->clm->fetch_all_customers();
        		$this->load->view('header',$pro_data);
        		$this->load->view('claim',$data);
        		$this->load->view('footer',$pro_data);
    	    }
    	    else if($this->session->has_userdata('user_logged_in') && $this->session->userdata('session_role') == "user")
    	    {
    	        $data["users"] = $this->cm->fetch_user_by_session_id($this->session->has_userdata('session_id'));
    	        $pro_data["project_info"] = $this->mm->fetch_project_info();
    	        $data["agents_pos"] = $this->clm->list_of_pos_and_agents();
    	        $data["customers"] = $this->clm->fetch_all_customers();
        		$this->load->view('header',$pro_data);
        		$this->load->view('claim',$data);
        		$this->load->view('footer',$pro_data);
    	    }
    	    else
    	    {
    	    	redirect("login");
    	    }
     }
 
 
     public function fetch_policy_no()
     {
          if($this->session->has_userdata('logged_in'))
          {
              $lead_id = $this->input->post("lead_id");
              $res = $this->clm->fetch_policy_no($lead_id);
              echo json_encode($res);
          }
     }
     
     public function fetch_client_details_by_policy_no()
     {
         if($this->session->has_userdata('logged_in'))
          {
              $policy_no = $this->input->post("policy_no");
              
              $res = $this->clm->fetch_client_details_by_policy_no($policy_no);
              
               if($res != "")
    	        {
    	            $policy_type = $res->policy_type;
    	            $lead_id = $res->lead_id;
    	            
    	            if($policy_type == "1")
    	            {
    	                  $data = $this->lm->get_car_details($lead_id);  
    	            }
    	            else if($policy_type == "2")
    	            {
    	                  $data = $this->lm->get_bike_details($lead_id); 
    	            }
    	            else if($policy_type == "3")
    	            {
    	                  $data = $this->lm->get_car_details($lead_id);  
    	            }
    	            else if($policy_type == "4")
    	            {
    	                  $data = $this->lm->get_bike_details($lead_id); 
    	            }
    	        }
    	        echo json_encode(array("basic_details"=>$res,"vechi_details"=>$data));
              
          }
     }
     
     public function add_claim_details()
     {
         if($this->session->has_userdata('logged_in'))
          {
            $lead_id = $this->input->post("lead_id");
            $client_id = $this->input->post("client_id");
            $client_name = $this->input->post("client_name");
            $policy_no = $this->input->post("policy_no");
            $re_date = $this->input->post("re_date");
            $estimated_loss = $this->input->post("estimated_loss");
            $date_of_loss = $this->input->post("date_of_loss");
            $agency_pos = $this->input->post("agency_pos");
            $claim_report = $this->input->post("claim_report");
            $fir_copy =$this->input->post("fir_copy");
            $surveyor_report = $this->input->post("surveyor_report");
     
           
             if(isset($_FILES))
        		{
        			$config['upload_path'] = './datas/documents/';
        			$config['allowed_types'] = '*';
        			
        			$this->load->library('upload',$config);
        			$this->upload->initialize($config);
        			if(!$this->upload->do_upload('rc_book'))
        			{
        				$rc_book = '';
        			}
        			else
        			{
        				$rc_book = $this->upload->data('file_name');
        			}
        		}
             if(isset($_FILES))
        		{
        			$config['upload_path'] = './datas/documents/';
        			$config['allowed_types'] = '*';
        			
        			$this->load->library('upload',$config);
        			$this->upload->initialize($config);
        			if(!$this->upload->do_upload('driving_license'))
        			{
        				$driving_licence = '';
        			}
        			else
        			{
        				$driving_licence = $this->upload->data('file_name');
        			}
        		}
             if(isset($_FILES))
        		{
        			$config['upload_path'] = './datas/spot_videos/';
        			$config['allowed_types'] = '*';
        			
        			$this->load->library('upload',$config);
        			$this->upload->initialize($config);
        			if(!$this->upload->do_upload('spot_video'))
        			{
        				$spot_videos = "";
        			}
        			else
        			{
        				$spot_videos = $this->upload->data('file_name');
        			}
        		}
            $datas = array(
                         "client_id" => $client_id,
                         "lead_id" =>$lead_id,
                         "client_name" => $client_name,
                         "policy_no" => $policy_no,
                         "claim_receipt_date" => $re_date,
                         "estimated_loss" =>$estimated_loss,
                         "date_of_loss" => $date_of_loss,
                         "rc_book_file" =>$rc_book,
                         "driving_license" => $driving_licence,
                         "spot_video" => $spot_videos,
                         "agent_pos" => $agency_pos,
                         "claim_report" =>$claim_report,
                         "fir_copy" => $fir_copy,
                         "surveyor_report" =>$surveyor_report,
                         "created_by" => $this->session->userdata('session_id'),
                         "created_at" => date("Y-m-d H:i:s"),
                         );
             
             $qry = $this->clm->add_claim_details($datas);
             
            
            $countfiles = count($_FILES['files']['name']);
            

              for($i=0;$i<$countfiles;$i++)
              {
                    if(!empty($_FILES['files']['name'][$i])){
                      $_FILES['file']['name'] = $_FILES['files']['name'][$i];
                      $_FILES['file']['type'] = $_FILES['files']['type'][$i];
                      $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
                      $_FILES['file']['error'] = $_FILES['files']['error'][$i];
                      $_FILES['file']['size'] = $_FILES['files']['size'][$i];
             
                      $config['upload_path'] = './datas/spot_photos/'; 
                      $config['allowed_types'] = '*';
                      $config['file_name'] = $_FILES['files']['name'][$i];
              
                      $this->load->library('upload',$config); 
                      $arr = array('msg' => 'something went wrong', 'success' => false);
                      
                      if($this->upload->do_upload('file')){
                          
                       $data = $this->upload->data(); 
                       $data = array("client_id"=>$client_id,"lead_id"=>$lead_id,"policy_no"=>$policy_no,"file_path"=>$data['file_name']);
                       $res = $this->clm->insert_spot_photos($data);
                      }
                    }
              
                  }
                 
                 
                    $data_2= array(
                             "client_id"=>$res,
                             "remarks" => $remarks,
                             "contact_person" =>$contact_person,
                             "contact_details" =>$contact_details,
                             "mobile_no" => $mobile_no,
                                 );
             
             
                  $data_1 = $this->clm->add_claim_report($data_2);

                  
          }
     }
     
     public function fetch_claims()
     {
          if($this->session->has_userdata('logged_in'))
          {
              
            $draw = intval($this->input->post("draw"));
			$res = $this->clm->fetch_claims();
			
        		$arr = [];
                $a = 0 ;
                
                foreach($res as $da)
                {
                	$a++;
        
                    $action = "
                    		 <button class='btn btn-danger btn-xs' onclick=claim_data(".$da->id.")><i class='fa fa-plus'></i>ADD</button>";
                    		 
                    $client_name = "<a href='#' onclick=view_data(".$da->id.")>".$da->client_name."</a>";		 
                    		 
                    
                    $arr[] = array(
                        $a,
                        $client_name,
                        $da->policy_no,
                        "",
                        date_format(date_create($da->claim_receipt_date),"d-m-Y"),
                        $da->estimated_loss,
                        date_format(date_create($da->date_of_loss),"d-m-Y"),
                        "Y",
                        $da->user_name,
                        $action,
                    );
                }
        
                $result = array(
                			"draw"=> $draw,
        				    "recordsTotal"=>count($res),
        				    "recordsFiltered"=> count($res),
        				    "data"=>$arr,
        				);
                echo json_encode($result);
          }
     }
     
     public function add_claim_report()
     {
          if($this->session->has_userdata('logged_in'))
          {
            $contact_person = $this->input->post("contact_person");
            $contact_details = $this->input->post("contact_details");
            $mobile_no = $this->input->post("mobile_no");
            $remarks = $this->input->post("remarks");
            $date = $this->input->post("date");
            $id = $this->input->post("id");
            
            $data = array(
                 "client_id" =>$id,
                 "contact_person"=>$contact_person,
                 "contact_details" => $contact_details,
                 "mobile_no" => $mobile_no,
                 "remarks" =>$remarks,
                 "date" => $date,
                  );
            $res = $this->clm->add_claim_report($data);

          }   
     }
     
     
     public function claim_view()
      {
          if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
        	{    		
    		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
        		$this->load->view('header',$pro_data);
        		$this->load->view('claim_view');
        		$this->load->view('footer',$pro_data);
    	    }
    	    else if($this->session->has_userdata('user_logged_in') && $this->session->userdata('session_role') == "user")
    	    {
    	        $data["users"] = $this->cm->fetch_user_by_session_id($this->session->has_userdata('session_id'));
    	        $pro_data["project_info"] = $this->mm->fetch_project_info();
        		$this->load->view('header',$pro_data);
        		$this->load->view('claim_view');
        		$this->load->view('footer',$pro_data);
    	    }
    	    else
    	    {
    	    	redirect("login");
    	    }
     }
     
     
     
       public function claim_follow_up()
      {
          if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin") 
        	{    		
    		   	$pro_data["project_info"] = $this->mm->fetch_project_info();
        		$this->load->view('header',$pro_data);
        		$this->load->view('claim_follow_up');
        		$this->load->view('footer',$pro_data);
    	    }
    	    else if($this->session->has_userdata('user_logged_in') && $this->session->userdata('session_role') == "user")
    	    {
    	        $data["users"] = $this->cm->fetch_user_by_session_id($this->session->has_userdata('session_id'));
    	        $pro_data["project_info"] = $this->mm->fetch_project_info();
        		$this->load->view('header',$pro_data);
        		$this->load->view('claim_follow_up');
        		$this->load->view('footer',$pro_data);
    	    }
    	    else
    	    {
    	    	redirect("login");
    	    }
     }
     
     
      public function fetch_claim_dateils()
     {
          if($this->session->has_userdata('logged_in'))
          {
              
            $draw = intval($this->input->post("draw"));
			$res = $this->clm->fetch_claim_dateils();
			
        		$arr = [];
                $a = 0 ;
                
                foreach($res as $da)
                {
                	$a++;
                    
                    
                    
                    $arr[] = array(
                        $a,
                        $da->sname,
                        $da->contact_person,
                        $da->contact_details,
                        $da->mobile_no,
                        $da->remarks,
                        date_format(date_create($da->date),"d-m-Y"),
                    );
                }
        
                $result = array(
                			"draw"=> $draw,
        				    "recordsTotal"=>count($res),
        				    "recordsFiltered"=> count($res),
        				    "data"=>$arr,
        				);
                echo json_encode($result);
          }
     }
     
     
     
     public function fetch_claim_contact_details()
        {
      	if($this->session->has_userdata('logged_in')) 
      	
      	 $id = $this->input->post("id");
      	 
      	 
      	  $content = "<table class='table table-bordered'>
    	                 
                 <tr>
                       <th>Name</th>
                       <th>Mobile No</th>
                       <th>Address</th>
                 <tr>";
                 
           $res1 = $this->clm->fetch_claims_details();
        
            $content .= "<tr>
                  <td>".$res1->sname."</td>
                  <td>".$res1->cmobile."</td>
                  <td>".$res1->naddress."</td>
             </tr>";
             
            $content .="</table>";
      	 
          
            
      	 $content .= "<table class='table table-bordered'>
    	                 
                 <tr>
                       <th>S.no</th>
                       <th>Date</th>
                       <th>Contact Person</th>
                       <th>Contact Designation</th>
                       <th>Mobile No</th>
                       <th>Remarks</th>
                 <tr>";
    
    	       $a = 0;
    	       
    	       	$res = $this->clm->fetch_claim_dateils($id);
    	       
    	       
    	        foreach($res as $da)
                {
                     $a++;
                    $content .= "<tr>
                                      <td>".$a."</td>
                                      <td>".date_format(date_create($da->date),"d-m-Y")."</td>
                                      <td>".$da->contact_person."</td>
                                      <td>".$da->contact_details."</td>
                                      <td>".$da->mobile_no."</td>
                                      <td>".$da->remarks."</td>
                                 </tr>";
                }
                
        
            
            $content .="</table>";
            
            echo $content;
    	}
  
              
}
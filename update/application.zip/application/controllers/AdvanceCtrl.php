<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdvanceCtrl extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('AdvanceMod','am');
		$this->load->model('MasterMod','mm');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper('cookie');
		$this->load->library('upload');
	}
	
	public function agent_advance()
	{
	    if($this->session->has_userdata('logged_in') && $this->session->userdata('session_role') == "admin")
	    {
	        $pro_data["project_info"] = $this->mm->fetch_project_info();
    		$this->load->view('header',$pro_data);
    		$this->load->view('agent_advance');
    		$this->load->view('footer',$pro_data);
	    }
	}
	
	public function fetch_load_agents()
	{
	    if($this->session->has_userdata('logged_in'))
	    {
	        $res = $this->am->fetch_load_agents();
	        echo json_encode($res);
	    }
	}
	
	// advance 
	
	public function add_advance_amount()
	{
	    if($this->session->has_userdata('logged_in'))
	    {
	        $agent = $this->input->post("agents");
	        $amount = $this->input->post("amount");
	        $date = $this->input->post("date");
	        $payment_mode = $this->input->post("payment_mode");
	        $transaction_no = $this->input->post("transaction_no");
	        $reason = $this->input->post("reason");
	        
	        $data = array(
	                        "agent_id" =>$agent,
	                        "amount" =>$amount,
	                        "type" =>"debit",
	                        "date" =>$date,
	                        "payment_mode" =>$payment_mode,
	                        "transaction_no" =>$transaction_no,
	                        "reason" =>$reason,
	                        "created_by" =>$this->session->userdata("session_id"),
	                        "created_date" =>date("Y-m-d H:i:s"),
	                       );
	                       
	        $res = $this->am->add_advance_amount($data);
	        
	        $ablog = array(
                            "agent_id" =>$agent,
                            "tran_date" =>date('Y-m-d H:i:s'),
                            "vocher_no" =>$transaction_no,
                            "debit" =>$amount,
                            "reason" =>"Agent_advance",
                            "created_by" =>$this->session->userdata("session_id"),
                            "created_at" =>date("Y-m-d H:i:s"),
	                       );
	                                   
	        $result = $this->am->agent_balance_log($ablog);
	        
	        echo "success";
	    }
	}
	
	public function fetch_agent_advance()
	{
	    if($this->session->has_userdata('logged_in'))
	    {
            $draw = intval($this->input->post("draw"));
            
            $month = $this->input->post("month");
            $year = $this->input->post("year");
            $agent = $this->input->post("agent");
            
            $date = $year."-".$month."-01";
            
            $res = $this->am->fetch_agent_advance($date,$agent);
            $arr = [];
            $a = 0 ;
            
            foreach($res as $da)
            {
                $a++;
                    $arr[] = array(
                        $a,
                        date_format(date_create($da->date),"d-m-Y"),
                         $da->agent_pos_name,
                        $da->agent_pos_code,
                        $da->reason,
                        $da->amount,
                    );
            }
            
            $result = array(
            "draw"=> $draw,
            "recordsTotal"=>count($res),
            "recordsFiltered"=> count($res),
            "data"=>$arr,
            );
            echo json_encode($result);
	    }
	}
	
	
	

}
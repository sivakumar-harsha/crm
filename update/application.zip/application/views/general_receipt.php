 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 style="font-size: 17px;">
        General Receipt
      </h1>
    </section>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
     <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>


    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-body">
         <div class= "row">
             
            <div class = "form-group col-md-6">
              <label>Account Head</label>
              <select class = "form-control select2" id="account_head" name="account_head" style='width:100%'>
                  <option value = "">--Select--</option>
                    <?php foreach($account_head as $da){ ?>
                       <option value = "<?php echo $da->account_id ?>"><?php echo $da->account_name ?></option>
                      <?php } ?>
              </select>
            </div>
            
            <div class = "form-group col-md-6">
              <label>Date</label>
              <input type="date" class="form-control" name = "date" id="date" value="<?php echo date('Y-m-d') ?>" disabled>
            </div>
            
            <div class = "form-group col-md-6">
              <label>Particulars</label>
              <select class="form-control" name="add_particulars" id="add_particulars">
                  <option value = "">--Select--</option>
              </select>
            </div>
            
            
            <div class = "form-group col-md-6">
              <label>Amount</label>
              <input type="number" class="form-control" name ="amount" id="amount">
            </div>
            
            
            <div class = "form-group col-md-6">
              <label>Naration</label>
              <textarea class="form-control" name = "narration" id="narration" rows="4"></textarea>
            </div>
              
          
               <div class = "form-group col-md-6">
                  <label>Payment Mode</label><br>
                   <input class="form-check-input" type="radio" name="pay_mode" id="pay_mode_cheque" value="Cheque">&nbsp;Cheque &nbsp;
                    <input class="form-check-input" type="radio" name="pay_mode" id="pay_mode_cash" value="Cash">&nbsp;Cash &nbsp;
                     <input class="form-check-input" type="radio" name="pay_mode" id="pay_mode_transfer" value="Transfer">&nbsp;Transfer
                
              </div>
              
               <div class = "form-group col-md-6 hidden" id="bank_div">
                  <label>Bank</label>
                  <input type="text" class = "form-control" name="bank" id="bank">
               </div>
             
               <div class = "form-group col-md-6 hidden" id="bank_branch_div">
                      <label>Branch</label>
                      <input type="text" class = "form-control" name="bank_branch" id="bank_branch">
                </div>
                
                <div class = "form-group col-md-6 hidden" id="cheque_div">
                      <label>Cheque No</label>
                      <input type="text" class = "form-control" name="cheque_no" id="cheque_no">
                </div>
                
                <div class = "form-group col-md-6 hidden" id="transaction_div">
                      <label>Transaction No</label>
                      <input type="text" class = "form-control" name="transaction_no" id="transaction_no">
                </div>
                
                  <div class = "form-group col-md-6">
                      <label>Transaction Date</label>
                      <input type="date" class = "form-control" name="trans_date" id="trans_date">
                </div>
                

                  <div class="col-md-3">
                     <div class = "form-check">
                       <input class="form-check-input" type="checkbox" value="yes" id="print_receipt">
                         <label class="form-check-label">Print Receipt</label>
                     </div>
               </div>
                
                  
                   <button type="button" class="btn btn-sm btn-primary pull-left" id="save_btn">Save</button>&nbsp;
                    <button type="button" class="btn btn-sm btn-default">Clear</button> 
               </div>                
         </div>
           
            
          
        </div><!-- /.box-body -->        
      </div><!-- /.box -->

    </section><!-- /.content -->
  </div><!-- /.content-wrapper -->
  
  
  <script>
      
      $(document).ready(function(){
         
          $('.select2').select2();
          
          $("#save_btn").click(function(){
             
             var account_head = $("#account_head").val();
             var particulars = $("#add_particulars").val();
             var amount = $("#amount").val();
             var date = $("#date").val();
             var narration = $("#narration").val();
             var paymode = $("input[name='pay_mode']:checked").val();
             var bank = $("#bank").val();
             var bank_branch = $('#bank_branch').val();
             var cheque_no = $("#cheque_no").val();
             var transaction_no = $("#transaction_no").val();
             var trans_date = $("#trans_date").val();
             
             if($('#print_receipt').is(':checked'))
             {
                var print_receipt = "Yes"; 
             }
             else
             {
                 var print_receipt = "NO"; 
             }

             if(account_head == "")
             {
                 snackbar_show("Select Account Head");
             }
             else if(date == "")
             {
                 snackbar_show("Select Date");
             }
             else if(particulars == "")
             {
                 snackbar_show("Select Particulars");
             }
             else if(narration == "")
             {
                 snackbar_show("Enter Narration");
             }
             else if(paymode == "")
             {
                 snackbar_show("Select Paymode");
             }
             else if((paymode == "Transfer" || paymode == "Cheque") && bank == "")
             {
                 snackbar_show("Select Bank");
             }
             else if((paymode == "Transfer" || paymode == "Cheque") && bank_branch == "")
             {
                 snackbar_show("Select Bank Branch");
             }
             else if(paymode == "Transfer" && transaction_no == "")
             {
                 snackbar_show("Select transaction no");
             }
             else if(paymode == "Cheque" && cheque_no == "")
             {
                 snackbar_show("Enter Cheque no");
             }
             else if(trans_date == "")
             {
                 snackbar_show("Select Transaction Date");
             }
             else
             {
                   $.ajax({
                            url : "add_general_receipt",
                            method : "POST",
                            data : {account_head:account_head,particulars:particulars,amount:amount,date:date,narration:narration,paymode:paymode,bank:bank,bank_branch:bank_branch,cheque_no:cheque_no,transaction_no:transaction_no,trans_date:trans_date},
                            beforeSend:function(){
                               $("#save_btn").attr("disabled",true);
                            },
                            success:function(resposne)
                            {
                                $("#save_btn").attr("disabled",false);
                                snackbar_show("General Receipt Created Sucessfully");
                                
                                if(print_receipt == "Yes")
                                {
                                    window.open("print_general_receipt?gr_no="+resposne+"", "_blank");
                                }
                                $("#account_head").val("");
                                $("#account_head").trigger("change");
                                $("#add_particulars").val("");
                                $("#amount").val("");
                                $("#date").val("");
                                $("#narration").val("");
                                 $("input[name='pay_mode']:checked").prop("checked", false)
                                $("#bank").val("");
                                $('#bank_branch').val("");
                                $("#cheque_no").val("");
                                $("#transaction_no").val("");
                                $("#trans_date").val("");
                            }
                    });
             }
          });
          
          
          $("input[name='pay_mode'").change(function(){
              var paymode = $("input[name='pay_mode']:checked").val();
              
              if(paymode == "Transfer")
              {
                    $("#bank_div").removeClass("hidden");
                    $("#bank_branch_div").removeClass("hidden");
                    $("#bank_branch_div").removeClass("hidden");
                    $("#transaction_div").removeClass("hidden");
                    $("#cheque_div").addClass("hidden");
              }
              else if(paymode == "Cheque")
              {
                    $("#bank_div").removeClass("hidden");
                    $("#bank_branch_div").removeClass("hidden");
                    $("#bank_branch_div").removeClass("hidden");
                    $("#cheque_div").removeClass("hidden");
                    $("#transaction_div").addClass("hidden");
              }
              else if(paymode == "Cash")
              {
                    $("#bank_div").addClass("hidden");
                    $("#bank_branch_div").addClass("hidden");
                    $("#bank_branch_div").addClass("hidden");
                     $("#cheque_div").addClass("hidden");
                    $("#transaction_div").addClass("hidden");
              }
          }); 
          
          $("#account_head").change(function(){
       
                var account_head = $("#account_head").val();
                 
                 $.ajax({
                            url : "get_particulars_by_account_head",
                            method : "POST",
                            data : {account_head:account_head},
                            success:function(response)
                            {
                                $("#add_particulars").html(response);
                            }
                 });
              
          });
      });
  </script>

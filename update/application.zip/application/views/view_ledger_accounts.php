 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <section class="content-header">
      <h1 style="font-size: 17px;">
        Ledger Accounts
      </h1>
      
      <div class = "row">
          
          <div class = "col-md-3">
              <div class = "form-group">
                  <label>Accounts Head</label>
                  <select class = "form-control select2" name = "acc_head" id="acc_head" style="width:100%">
                      <option value = "">--select Account Head--</option>
                      <?php foreach($account_head as $da)  { ?>
                      <option value = "<?php echo $da->account_id ?>"><?php echo $da->account_name ?></option>
                      <?php } ?>
                  </select>
              </div>
          </div>
          
          <div class = "col-md-3">
              <div class = "form-group">
                  <label>Sub Category</label>
                  <select class = "form-control" name = "acc_sub_category" id="acc_sub_category">
                      <option value = "">--Select Sub Category--</option>
                  </select>
              </div>
          </div>
          
          <div class = "col-md-2">
              <div class = "form-group">
                  <label>From Date</label>
                  <input type = "date" class="form-control" id="f_date" name="f_date">  
              </div>
          </div>
          
          <div class = "col-md-2">
              <div class = "form-group">
                  <label>To Date</label>
                  <input type = "date" class="form-control" id="to_date" name="to_date">  
              </div>
          </div>
          
           <div class = "col-md-2">
              <div class = "form-group">
                  <br>
                <button class = "btn btn-success btn-sm pull-right" id="search_btn"><i class="fa fa-search" aria-hidden="true"></i> Search</button>
              </div>
          </div>
          
      </div>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box">
        <div class="box-body">
          <div id="table_view"></div>
        </div>       
      </div>
    </section><!-- /.content -->
  </div><!-- /.content-wrapper -->
  
  
  
  <script>
  
    var acc_head = $("#acc_head").val();
    var acc_sub_category = $("#acc_sub_category").val();
    var f_date = $("#f_date").val();
    var to_date = $("#to_date").val();
  
    $(document).ready(function(){
        $('.select2').select2();
         acc_ledger(acc_head,acc_sub_category,f_date,to_date)
         
         $("#acc_head").change(function(){
       
                var account_head = $("#acc_head").val();
                 
                 $.ajax({
                            url : "get_particulars_by_account_head",
                            method : "POST",
                            data : {account_head:account_head},
                            success:function(response)
                            {
                                $("#acc_sub_category").html(response);
                            }
                 });
              
          });
          
         $("#search_btn").click(function(){
              acc_head = $("#acc_head").val();
              acc_sub_category = $("#acc_sub_category").val();
              f_date = $("#f_date").val();
              to_date = $("#to_date").val();
             
              acc_ledger(acc_head,acc_sub_category,f_date,to_date)
             
             
         });
    });
    
    
    
    
      function acc_ledger(acc_head,acc_sub_category,f_date,to_date)
      {
            $.ajax({
              url:"fetch_view_accounts_ledger",
              data:{acc_head:acc_head,acc_sub_category:acc_sub_category,f_date:f_date,to_date:to_date},
              method:"POST",
              success:function(response){
                $("#table_view").html(response);
              },
              error: function(code) {   
                alert(code.statusText);
              },
            });
        }
  </script>

      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
        <strong>Copyright &copy; 2022 <a href="http://harshainfotech.com">Harsha Infotech</a>.</strong> All rights reserved.
      </footer>

    </div><!-- ./wrapper -->

    <?php if($project_info->server == "CDN"){ ?>

    <!-- Bootstrap 3.3.5 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery-slimScroll/1.3.8/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fastclick/1.0.6/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/2.3.0/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/2.3.0/js/demo.js"></script>

    <?php }else{ ?>

    <!-- Bootstrap 3.3.5 -->
    <script src="https://harshainfotech.net/themes/AdminLTE/bootstrap/js/bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="https://harshainfotech.net/themes/AdminLTE/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="https://harshainfotech.net/themes/AdminLTE/plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="https://harshainfotech.net/themes/AdminLTE/dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="https://harshainfotech.net/themes/AdminLTE/dist/js/demo.js"></script>


    <?php } ?>


  </body>
</html>

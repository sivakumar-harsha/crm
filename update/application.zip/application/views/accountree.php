 
 <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>

  .form-control {
    display: block;
    width: 100%;
    height: 31px;
    padding: 4px 11px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgb(0 0 0 / 8%);
    box-shadow: inset 0 1px 1px rgb(0 0 0 / 8%);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
}

   label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: unset;
    font-size: 14px;
}

  .select2-container--default .select2-selection--multiple .select2-selection__choice {
    background-color: #337ab7 !important;
    border: 1px solid #fff;
    border-radius: 4px;
    cursor: default;
    color: #fff;
    float: left;
    margin-right: 5px;
    margin-top: 5px;
    padding: 0 5px;
}

  .select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
    color: #fff !important;
    cursor: pointer;
    display: inline-block;
    font-weight: bold;
    margin-right: 2px;
}

</style>
 
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 style="font-size: 17px;">
        Account Tree
        <button data-toggle="modal" data-target="#add_model" class="btn btn-primary btn-sm pull-right">Add New</button>
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-body">
          <div id="table_view"></div>
        </div><!-- /.box-body -->        
      </div><!-- /.box -->

    </section><!-- /.content -->
  </div><!-- /.content-wrapper -->
  
  
  
   <div class="modal fade in" id="add_model">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true" style="color:white;">×</span></button>
                <h4 class="modal-title text-center">Account Tree</h4>
            </div>
            <div class="modal-body">
                
                 <div class="form-group">
                      <label>Main Ledger</label>
                      <select class="form-control select2" name="add_main_ledger" id="add_main_ledger" style="width:100%">
                          <option value="">--Select--</option>
                      </select>
                  </div>

                 <div class="form-group">
                      <label>Sub Ledger</label>
                      <select class="form-control select2" style='width:100%' name="add_sub_ledger" id="add_sub_ledger">
                          <option value="">--Select--</option>
                        
                      </select>
                  </div>
               
                 <div class="form-group">
                      <button class="btn btn-primary btn-xs pull-right" id="add_new_ledger">
                          <i class="fa fa-plus" aria-hidden="true"></i> Create Sub Ledger</button>
                  </div>
                  <br>
                  
                 <div class="form-group">
                      <label>Account name</label>
                      <input type="text" class="form-control" name="add_acc_name" id="add_acc_name">
                  </div>
                  
                  
                  <div class="form-group">
                      <label>Type</label>
                      <select class="form-control" name="add_type" id="add_type">
                          <option value="">--Select--</option>
                          <option value = "1">Credit</option>
                          <option value = "2">Debit</option>
                          <option value = "3">Both</option>
                      </select>
                  </div>
                  
                  <div class="form-group">
                      <label>Account tree</label>
                      <select class="form-control" name="tree_type" id="tree_type">
                          <option value="">--Select--</option>
                          <option value="2">Open</option>
                          <option value="3">Close</option>
                      </select>
                  </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-sm btn-primary" id="add_btn">Submit</button>
            </div>
        </div>
    </div>
  </div>
  
  
   <div class="modal fade in" id="sub_ledger_modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true" style="color:white;">×</span></button>
                <h4 class="modal-title text-center">Add Sub Ledger</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                  <label>Ledger name</label> 
                  <input type="text" class="form-control" id="add_sub_ledger_name">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-sm btn-primary" id="add_sub_ledger_btn">Submit</button>
            </div>
        </div>
    </div>
  </div>
  
  
   <div class="modal fade in" id="view_model">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true" style="color:white;">×</span></button>
                <h4 class="modal-title text-center">Sub Ledgers</h4>
            </div>
            <div class="modal-body">
                 <div id="view_data"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-sm btn-primary" id="add_btn">Submit</button>
            </div>
        </div>
    </div>
  </div>
  
  
  <script>
      
       $(document).ready(function(){
           
          $('.select2').select2();
          fetch_main_ledgers();
          
          fetch_accounts_tree();
          
          $("#add_new_ledger").click(function(){
              
              $("#sub_ledger_modal").modal("toggle");
          });
         
          $("#add_main_ledger").change(function(){
                  var main_ledger = $("#add_main_ledger").val();
                  fetch_all_sub_ledgers(main_ledger);
              });
          
          $("#add_sub_ledger_btn").click(function(){
                  var main_ledger_id = $("#add_main_ledger").val();
                  var sub_ledger_name = $("#add_sub_ledger_name").val();
                  
                  $.ajax({
                        url : "add_sub_ledger",
                        method : "POST",
                        data : {main_ledger_id:main_ledger_id,sub_ledger_name:sub_ledger_name},
                        success:function(response)
                        {
                            fetch_all_sub_ledgers();
                            $("#sub_ledger_modal").modal("toggle");
                            $("#add_main_ledger").val("");
                            $("#add_sub_ledger_name").val("");
                            $("#add_sub_ledger_name").trigger("change");
                            snackbar_show("Sub-legder was successfully added");
                        }
                  });
              });
              
          
          $("#add_btn").click(function(){
                 var main_ledger_id = $("#add_main_ledger").val();
                 var add_sub_ledger_id = $("#add_sub_ledger").val();
                 var add_acc_name = $("#add_acc_name").val();
                 var add_type = $("#add_type").val();
                 var tree_type = $("#tree_type").val();
                 
                 if(main_ledger_id == "")
                 {
                     snackbar_show("Select Main Ledger");
                 }
                 else if(add_sub_ledger_id == "")
                 {
                     snackbar_show("Select Sub Ledger");
                 }
                 else if(add_type == "")
                 {
                     snackbar_show("Select Type Credit / Debit");
                 }
                 else if(tree_type == "")
                 {
                     snackbar_show("Select Tree Type");
                 }
                 else if(add_acc_name == "")
                 {
                     snackbar_show("Select Account Name");
                 }
                 else
                 {
                        $.ajax({
                                url : "add_multi_sub_ledger",
                                method : "POST",
                                data : {main_ledger_id:main_ledger_id,add_sub_ledger_id:add_sub_ledger_id,add_acc_name:add_acc_name,add_type:add_type,tree_type:tree_type},
                                beforeSend:function()
                                {
                                     $("#add_btn").attr("disabled",true);
                                },
                                success:function(response)
                                {
                                    $("#add_model").modal("toggle");
                                    $("#add_main_ledger").val("");
                                    $("#add_sub_ledger").val("");
                                    $("#add_sub_ledger").trigger("change");
                                    $("#add_acc_name").val("");
                                    $("#add_btn").attr("disabled",false);
                                    snackbar_show("Sub-legder was successfully added");
                                }
                          });
                 }
                
                  
          });
          
      });
      
      function fetch_main_ledgers()
      {
          $.ajax({
                    url : "fetch_main_ledgers",
                    method : "POST",
                    success:function(response)
                    {
                        var obj = jQuery.parseJSON(response);
                        var content = "<option value=''>--Select--</option>";
                        
                        for(var i= 0;i<obj.length;i++)
                        {
                            content += "<option value="+obj[i].vchaccid+">"+obj[i].vchaccname+"</option>";
                        }
                        
                        $("#add_main_ledger").html(content);
                    }
          });
      }
      
      function fetch_all_sub_ledgers(main_ledger)
      {
           $.ajax({
                    url : "fetch_all_sub_ledgers",
                    method : "POST",
                    data : {main_ledger:main_ledger},
                    success:function(response)
                    {
                        var obj = jQuery.parseJSON(response);
                        var content = "<option value=''>--Select--</option>";
                        
                        for(var i= 0;i<obj.length;i++)
                        {
                            content += "<option value="+obj[i].vchaccid+">"+obj[i].vchaccname+"</option>";
                        }
                        $("#add_sub_ledger").html(content);
                    }
          });
      }
      
      
      function fetch_accounts_tree()
      {
         var content = "";
          content += "<div class='table-responsive'>";
          content += "<table id='table_id' class='table table-hover table-bordered'>"; 
          content += "<thead><th>S.No</th><th>Account Id</th><th>Account Name</th><th>Balance</th></thead>";
          content += "<tbody></tbody>";
          content += "</table>";
          content += "</div>";
          
          $("#table_view").html(content);
    
          $("#table_id").DataTable({
              "processing": true,
              "serverSide": false,
              "ordering": false,
              "pageLength": 25,
              "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
              "ajax":{
                'url':'fetch_accounts_tree',
              }
      });      
      }
      
      function view_data(accid)
      {
           $.ajax({
                     url : "get_child_account_tree",
                     method : "POST",
                     data : {accid:accid},
                     success:function(response)
                     {
                         $("#view_data").append(response);
                         $("#view_model").modal("toggle");
                     }
           });   
      }
      
      function view_data_1(accid)
      {
           $.ajax({
                     url : "get_child_account_tree",
                     method : "POST",
                     data : {accid:accid},
                     success:function(response)
                     {
                         $("#sub_data").append(response);
                         //$("#view_model").modal("toggle");
                     }
           });   
      }
      
  </script>

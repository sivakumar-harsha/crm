 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 style="font-size: 17px;">
        Create Claim
      </h1>
    </section>

 
 <style>
     .select2-container--default .select2-selection--multiple .select2-selection__choice {
    background-color: #337ab7 !important;
    border: 1px solid #fff;
    border-radius: 4px;
    cursor: default;
    color: #fff;
    float: left;
    margin-right: 5px;
    margin-top: 5px;
    padding: 0 5px;
}

.select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
    color: #fff !important;
    cursor: pointer;
    display: inline-block;
    font-weight: bold;
    margin-right: 2px;
}

 .form-control {
    display: block;
    width: 100%;
    height: 29px;
    padding: 4px 10px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgb(0 0 0 / 8%);
    box-shadow: inset 0 1px 1px rgb(0 0 0 / 8%);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
}

.form-check-input:checked {
    background-color: #0d6efd !important;
    border-color: #0d6efd !important;
}
.form-check-input{
    border-color: 1px solid #D3CFC8 !important;
}

label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: unset;
    font-size: 14px;
}

.form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control {
    background-color: #fff;
    opacity: 1;
}
 </style>

   
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box">
        <div class="box-body">
            
            <div class="row" id="create_claim">
                <div class="col-md-6">
                    
                    
                  <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Policy Number</label>
                            </div>
                             <div class="col-md-8">
                               <input type="text" placeholder="Enter Your Policy Number" class="form-control" name="add_policy_no" id="add_policy_no">
                            </div>
                        </div>
                    </div>
                    
                     <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Mobile No</label>
                            </div>
                             <div class="col-md-8">
                               <input type="text" class="form-control" name="add_mobile_no" id="add_mobile_no" readonly>
                            </div>
                        </div>
                    </div>
                   
                     <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Business Type</label>
                            </div>
                             <div class="col-md-8">
                               <input type="text" class="form-control" name="add_business_type" id="add_business_type" readonly>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Make/Model/Varient</label>
                            </div>
                             <div class="col-md-8">
                               <input type="text" class="form-control" name="add_make_model" id="add_make_model" readonly>
                            </div>
                        </div>
                    </div>
                    
                    
                   
                     <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Claim Receipt Date</label>
                            </div>
                             <div class="col-md-8">
                               <input type="date" class="form-control" name="add_re_date" id="add_re_date" value="<?php echo date("Y-m-d") ?>">
                            </div>
                        </div>
                    </div>
                    
                        <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Estimated Loss</label>
                            </div>
                             <div class="col-md-8">
                               <input type="number" class="form-control" id="add_estimated_loss" name="add_estimated_loss">
                            </div>
                        </div>
                    </div>
                    
                     <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Date Of Loss</label>
                            </div>
                             <div class="col-md-8">
                               <input type="date" class="form-control" id="add_date_of_loss" name="add_date_of_loss">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Agency/Pos</label>
                            </div>
                             <div class="col-md-8">
                               <select class="form-control select2" name="add_agency_pos" id="add_agency_pos">
                                   <option value="">--Select--</option>
                                   <?php foreach($agents_pos as $da){ ?>
                                     <option value="<?php echo $da->id ?>"><?php echo $da->name ?></option>
                                   <?php } ?>
                               </select>
                            </div>
                        </div>
                    </div>
                    
                    
                <div class="form-group">
                    <div class="row">   
                       <div class="col-md-4">
                            <label>Document Submit</label>
                       </div>
                         <div class="col-md-8">
                              <label> Claim Repory</label>
                             <input type="checkbox" class="form-check-input"  name="claim_report" id="claim_report" >
                              <label>FIR Copy</label>
                             <input type="checkbox" class="form-check-input"   name="fir_copy" id="fir_copy" >
                             <label>Surveyor report</label>
                             <input type="checkbox" class="form-check-input"   name="surveyor_report" id="surveyor_report" >
                         </div>
                    </div>
                </div>
                    
                    
                </div>
                
                <div class="col-md-6">
                    
                    <input type="hidden" id="lead_id">
                    <input type="hidden" id="client_id">
                    
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Client Name</label>
                            </div>
                             <div class="col-md-8">
                               <input type="text" class="form-control" name="add_client_name" id="add_client_name" readonly>
                            </div>
                        </div>
                    </div>
                    
                     <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>address</label>
                            </div>
                             <div class="col-md-8">
                               <textarea type="text" class="form-control" name="add_address" id="add_address" rows="2" readonly></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Rc Book</label>
                            </div>
                             <div class="col-md-8">
                               <input type="file" class="form-control" name="add_rc_book" id="add_rc_book">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Driving Licence</label>
                            </div>
                             <div class="col-md-8">
                               <input type="file" class="form-control" name="add_driving_license" id="add_driving_license">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group hidden" id="files_hidden">
                        <div class="row">
                             <div class="col-md-12">
                               <div id="uploaded_files"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Spot Photos</label>
                            </div>
                             <div class="col-md-8">
                               <input type='file' name='add_files[]' id="add_files" multiple="multiple" class="form-control">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Spot Video</label>
                            </div>
                             <div class="col-md-8">
                               <input type="file" class="form-control" name="add_spot_video" id="add_spot_video">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Claim Processing Status</label>
                            </div>
                             <div class="col-md-8">
                               <select class="form-control" name="add_pro_status" id="add_pro_status">
                                   <option value="">--Select--</option>
                                   <option value="New Intimation">New Intimation</option>
                                   <option value="Processing">Processing</option>
                                   <option value="Payment Received">Payment Received</option>
                               </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">
                             <div class="col-md-12">
                              <button class="btn btn-success pull-right" id="submit_btn"><i class="fa fa-save"></i> Submit</button>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>
            
            <div class="row" id="all_claims">
                <div id="table_view"></div>
            </div>
            
          
        </div><!-- /.box-body -->        
      </div><!-- /.box -->
      
    </section><!-- /.content -->
  </div><!-- /.content-wrapper -->
  
  <script>
  
  var content = "";
  
  
  
    $(document).ready(function(){
          
        <?php 
          if(isset($_GET["tab"]))
          {?>
              $("#all_claim").addClass("hidden");
              //$("#create_claim").removeClass("hidden");
         <?php }
          else
          {?>
              fetch_claims();
              //$("#create_claim").addClass("hidden");
              $("#all_claim").removeClass("hidden");
           <?php }
         ?>
           
          $('.select2').select2();
        
          $("#add_policy_no").change(function(){
              var policy_no = $("#add_policy_no").val();
               $.ajax({
                            url : "fetch_client_details_by_policy_no",
                            method : "POST",
                            data : {policy_no:policy_no},
                            success:function(response)
                            {
                                 var obj = jQuery.parseJSON(response);
                                 $("#add_client_name").val(obj["basic_details"].client_name);
                                 $("#add_mobile_no").val(obj["basic_details"].mobile_no);
                                 $("#add_business_type").val(obj["basic_details"].bussiness_type);
                                 
                                 $("#lead_id").val(obj["basic_details"].lead_id);
                                 $("#client_id").val(obj["basic_details"].id);
                                 
                                 $("#add_address").val(obj["basic_details"].address);
                                 $("#add_make_model").val(obj["vechi_details"].brand_name+" "+" "+obj["vechi_details"].model_name+" "+obj["vechi_details"].varient_name);
                            }
                  });
          });
          
           $("#submit_btn").click(function(){
              
            var add_client_name = $("#add_client_name").val();
            var add_policy_no = $("#add_policy_no").val();
            var add_re_date = $("#add_re_date").val();
            var add_estimated_loss = $("#add_estimated_loss").val();
            var add_agency_pos = $("#add_agency_pos").val();
            var add_date_of_loss = $("#add_date_of_loss").val();
            var drv_license = $("#add_driving_license").val(); 
            var spot_img = $("#add_files").val();
            var lead_id = $("#lead_id").val();
            var client_id = $("#client_id").val();
            var add_rc_book = $("#add_rc_book").prop('files')[0];
            var add_driving_license = $("#add_driving_license").prop('files')[0];
            
            if($('#claim_report').is(":checked"))
             {
                 var claim_report = "Yes";
             }
             else
             {
                 var claim_report = "No";
             }
             
             if($('#fir_copy').is(":checked"))
             {
                 var fir_copy = "Yes";
             }
             else
             {
                 var fir_copy = "No";
             }
            
             if($('#surveyor_report').is(":checked"))
             {
                 var surveyor_report = "Yes";
             }
             else
             {
                 var surveyor_report = "No";
             }
            
            var add_spot_video = $("#add_spot_video").prop('files')[0];
            var add_pro_status = $("#add_pro_status").val();
    
            var check = 0;
            
            if(add_re_date == "")
            {
                    Swal.fire(
                      'Select Claim Receipt Date ?',
                      'That thing is still around?',
                      'question'
                    )
                    check = 1;
            }
            else if(add_estimated_loss == "")
            {
                 Swal.fire(
                      'Enter Estimated Loss ?',
                      'That thing is still around?',
                      'question'
                    )
                    check = 1;
            }
            else if(add_date_of_loss == "")
            {
                 Swal.fire(
                      'Enter Date Of Loss?',
                      'That thing is still around?',
                      'question'
                    )
                    check = 1;
            }
            else if(drv_license == "")
            {
                 Swal.fire(
                      'Select Driving Licence ?',
                      'That thing is still around?',
                      'question'
                    )
                    check = 1;
            }
            
            else if(spot_img == "")
            {
                 Swal.fire(
                      'Select Spot Photos ?',
                      'That thing is still around?',
                      'question'
                    )
                    check = 1;
            }
            
            else if(add_pro_status == "")
            {
                 Swal.fire(
                      'Select Claim Processing Status ?',
                      'That thing is still around?',
                      'question'
                    )
                    check = 1;
            }
            else if(check != 1)
            {
                var formdata = new FormData();
                var ins = document.getElementById('add_files').files.length;
                for(var x = 0; x<ins;x++) {
                formdata.append("files[]", document.getElementById('add_files').files[x]);
                }
                formdata.append('lead_id',lead_id);
                formdata.append('client_id',client_id);
                formdata.append('client_name',add_client_name);
                formdata.append('policy_no',add_policy_no);
                formdata.append('re_date',add_re_date);
                formdata.append('estimated_loss',add_estimated_loss);
                formdata.append('date_of_loss',add_date_of_loss);
                formdata.append('agency_pos',add_agency_pos);
                formdata.append('rc_book',add_rc_book);
                formdata.append('driving_license',add_driving_license);
                formdata.append('spot_video',add_spot_video);
                formdata.append('pro_status',add_pro_status);
                formdata.append('claim_report',claim_report);
                formdata.append('fir_copy',fir_copy);
                formdata.append('surveyor_report',surveyor_report);
                
                 $.ajax({
                        url : "add_claim_details",
                        method : "POST",
                        data:formdata,
                        processData:false,  
                        contentType:false,
                        cache:false,
                        dataType:'text',
                        beforeSend:function(){
                            $("#submit_btn").attr("disabled",true);
                        },
                        success:function(response)
                        {
                            $("#submit_btn").attr("disabled",false);
                            Swal.fire({
                              position: 'top-end',
                              icon: 'success',
                              title: 'New Claim Added Successfully',
                              showConfirmButton: false,
                              timer: 1500
                            })
                            $(".form-control").val("");
                            $("#add_agency_pos").select2("val", "");
                        }
             });
            }
          });
          
          
      });
      
      
      
      
  </script>
  
  
  
  
<?php  
class ReportMod extends CI_Model  
{  
  	function __construct()  
  	{ 
    	parent::__construct();  
    	$this->load->dbforge();
  	}

    public function add_clients_data($data)
    {
        $this->db->insert("list_of_clients",$data);
        $insert_id = $this->db->insert_id();
        return  $insert_id;
    }
    
    public function add_lead_details($arr)
    {
         $this->db->insert("list_of_leads",$arr);
    }
    
    public function fetch_agent_using_type($agent_type)
    {
        $this->db->select("list_of_pos_and_agents.*,admin_login.name as ai_name,list_of_reigion.reigion as region_name");
         $this->db->from("list_of_pos_and_agents");
         $this->db->join("admin_login","admin_login.id = list_of_pos_and_agents.area_incharge");
         $this->db->join("list_of_reigion","list_of_reigion.id = list_of_pos_and_agents.region");
         $this->db->where("list_of_pos_and_agents.role",$agent_type);
  	    return $this->db->get()->result();
    }
    
    // commission 
    
    public function fetch_generate_policy($from_date,$to_date)
	{
      	$this->db->select("policy_info.id,company_payout_commission.no_of_policy_id,policy_info.agent_commission_amt,policy_info.own_commission_amt,policy_info.agent_commission_amt,policy_info.policy_agency_pos,list_of_leads.business_type,policy_info.policy_premium,list_of_leads.class,policy_info.company,policy_info.gst,policy_info.policy_s_date,policy_info.policy_ex_date,list_of_premium_cover_type.name as policy_premium_name,type_of_bussiness.bussiness_type as business_name,list_of_class.class as class_name,list_of_policy_type.policy_type,policy_info.total_own_damage,policy_info.tot_liability_premium,policy_info.basic_tp,policy_info.total_premium,policy_info.policy_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_pos_and_agents.agent_pos_code,list_of_insurance_company.company_name,company_payout_commission.commission_type,company_payout_commission.net_premium_id");
      	$this->db->join("list_of_leads","policy_info.lead_id = list_of_leads.id");
  	    $this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("list_of_pos_and_agents","policy_info.policy_agency_pos = list_of_pos_and_agents.id");
  	    $this->db->join("list_of_insurance_company","policy_info.company = list_of_insurance_company.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("list_of_premium_cover_type","policy_info.policy_premium = list_of_premium_cover_type.id",'left');
  	    $this->db->join("company_payout_commission","company_payout_commission.id = policy_info.commission_id");
  	    
      	$this->db->where("policy_info.commission_status !=","1");
      	$this->db->where("list_of_leads.lead_type","2");
      	//$this->db->where("policy_info.policy_no","32760519202200");
      	$this->db->where("policy_info.policy_issue_date >=",$from_date);
      	$this->db->where("policy_info.policy_issue_date <=",$to_date);
      	return $this->db->get("policy_info")->result();
	}

   public function fetch_commission_type_id($state,$company,$policy_class,$bussiness_type,$policy_premium,$rto,$category,$vehicle_classification)
  	{
  	    $rto_arr = [];
  	    $rto_arr[] = "all";
  	    $rto_arr[] = $rto;
  	    
  	    $sub_str = substr($rto,0,2);
  	    
  	    if($sub_str == "TN")
  	    {
  	        $rto_arr[] = "All TN";
  	    }
  	    $this->db->select("payout_commission.id,payout_commission.commission_type,payout_commission.on_net,payout_commission.irdi_commission,payout_commission.own_od,payout_commission.own_tp,payout_commission.bronze_category,payout_commission.silver_category,payout_commission.gold_category");
  	    $this->db->where("state",$state);
  	    $this->db->where("insurer_company",$company);
  	    $this->db->where("class",$policy_class);
  	    $this->db->where("business_type",$bussiness_type);
  	    $this->db->where("category",$category);
  	    $this->db->where("policy_premium_type",$policy_premium);
  	    $this->db->where("product",$vehicle_classification);
  	    $this->db->where_in('commission_rto_log.rto', $rto_arr);
  	    $this->db->join("commission_rto_log","payout_commission.id = commission_rto_log.commission_id");
  	    return $this->db->get("payout_commission")->row();
  	}
  	
  	
  	public function fetch_agent_tot_amount_policy($id)
  	{
  	    $this->db->where("policy_agency_pos",$id);
  	    $res = $this->db->get("policy_info")->result();
  	    
  	    $total = 0;
  	    
  	    foreach($res as $r)
  	    {
  	        $total = $total + $r->total_premium;
  	    }
  	    return $total;
  	}
  	
  	public function fetch_agent_status($tot_amount)
  	{
  	    $this->db->where("from_amt<=",$tot_amount);
  	    $this->db->where("to_amt>=",$tot_amount);
  	    $res = $this->db->get("commission_paid_category")->row();
  	    if($res != "")
  	    {
  	        return $res->category;
  	    }
  	    else
  	    {
  	        return "";    
  	    }
  	}
  	
  	public function fetch_health_commission_type($policy_premium,$company)
  	{
  	    $this->db->where("class",2);
  	    $this->db->where("policy_premium_type",$policy_premium);
  	    $this->db->where("insurer_company",$company);
  	    return $this->db->get("payout_commission")->row();
  	}
  	
  	
  	// fix commission
  	
  	
  	public function fetch_generate_policy_by_id($policy_arr)
	{
      	$this->db->select("policy_info.id,policy_info.policy_agency_pos,list_of_leads.business_type,policy_info.policy_premium,list_of_leads.class,policy_info.company,policy_info.gst,policy_info.policy_s_date,policy_info.policy_ex_date,list_of_premium_cover_type.name as policy_premium_name,type_of_bussiness.bussiness_type as business_name,list_of_class.class as class_name,list_of_policy_type.policy_type,policy_info.total_own_damage,policy_info.basic_tp,policy_info.total_premium,policy_info.policy_no,policy_info.commission_id,list_of_clients.client_name,list_of_clients.mobile_no,list_of_pos_and_agents.agent_pos_code,list_of_insurance_company.company_name,company_payout_commission.commission_type");
      	$this->db->join("list_of_leads","policy_info.lead_id = list_of_leads.id");
  	    $this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("list_of_pos_and_agents","policy_info.policy_agency_pos = list_of_pos_and_agents.id");
  	    $this->db->join("list_of_insurance_company","policy_info.company = list_of_insurance_company.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("list_of_premium_cover_type","policy_info.policy_premium = list_of_premium_cover_type.id");
  	    $this->db->join("company_payout_commission","company_payout_commission.id = policy_info.commission_id");
      	$this->db->where("policy_info.commission_status !=","1");
      	$this->db->where_in("policy_info.id",$policy_arr);
      	return $this->db->get("policy_info")->result();
	}
	
   public function update_agent_commission($data,$id)
   {
       $this->db->where("id",$id);
       $this->db->update("policy_info",$data);
   }    
   
   public function fetch_all_agents_list()
   {
       return $this->db->get("list_of_pos_and_agents")->result();
   }
   
   public function fetch_agent_commission_report($from_date,$to_date,$agent_id)
   {
        $this->db->select("policy_info.id,policy_info.policy_agency_pos,list_of_leads.business_type,policy_info.policy_premium,list_of_leads.class,policy_info.company,policy_info.gst,policy_info.policy_s_date,policy_info.policy_ex_date,list_of_premium_cover_type.name as policy_premium_name,policy_info.commission_id,type_of_bussiness.bussiness_type as business_name,list_of_class.class as class_name,list_of_policy_type.policy_type,policy_info.total_own_damage,policy_info.basic_tp,policy_info.total_premium,policy_info.policy_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_pos_and_agents.agent_pos_code,list_of_insurance_company.company_name,company_payout_commission.commission_type,company_payout_commission.net_premium_id");
      	$this->db->join("list_of_leads","policy_info.lead_id = list_of_leads.id");
  	    $this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("list_of_pos_and_agents","policy_info.policy_agency_pos = list_of_pos_and_agents.id");
  	    $this->db->join("list_of_insurance_company","policy_info.company = list_of_insurance_company.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("list_of_premium_cover_type","policy_info.policy_premium = list_of_premium_cover_type.id");
  	      $this->db->join("company_payout_commission","company_payout_commission.id = policy_info.commission_id");
      	$this->db->where("policy_info.commission_status","1");
      	$this->db->where("policy_info.created_date >=",$from_date);
      	$this->db->where("policy_info.created_date <=",$to_date);
      	$this->db->where("policy_info.policy_agency_pos",$agent_id);
      	return $this->db->get("policy_info")->result();
   }
   
   public function get_agent_code($from_date,$to_date)
   {
       $this->db->select("policy_info.*,list_of_pos_and_agents.agent_pos_code");
       $this->db->from("policy_info");
       $this->db->join("list_of_pos_and_agents","policy_info.policy_agency_pos = list_of_pos_and_agents.id");
       $this->db->group_by('policy_info.policy_agency_pos'); 
       $this->db->where("policy_info.commission_status","1");
       $this->db->where("policy_info.created_date >=",$from_date);
       $this->db->where("policy_info.created_date <=",$to_date);
       return $this->db->get()->result();
   }
   
   public function get_single_agent_code($agent_id)
   {
       $this->db->where("id",$agent_id);
       return $this->db->get("list_of_pos_and_agents")->row();
   }
   
   
   // vocher 
   
   public function fetch_single_agent_commission_report($from_date,$to_date,$agent_id)
   {
       $this->db->select("policy_info.id,policy_info.agent_commission_amt,policy_info.agn_add_com,policy_info.policy_agency_pos,list_of_leads.business_type,policy_info.policy_premium,list_of_leads.class,policy_info.company,policy_info.gst,policy_info.policy_s_date,policy_info.policy_ex_date,list_of_premium_cover_type.name as policy_premium_name,type_of_bussiness.bussiness_type as business_name,list_of_class.class as class_name,list_of_policy_type.policy_type,policy_info.total_own_damage,policy_info.basic_tp,policy_info.total_premium,policy_info.policy_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_pos_and_agents.agent_pos_code,list_of_insurance_company.company_name");
      	$this->db->join("list_of_leads","policy_info.lead_id = list_of_leads.id");
  	    $this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("list_of_pos_and_agents","policy_info.policy_agency_pos = list_of_pos_and_agents.id");
  	    $this->db->join("list_of_insurance_company","policy_info.company = list_of_insurance_company.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("list_of_premium_cover_type","policy_info.policy_premium = list_of_premium_cover_type.id",'left');
      	$this->db->where("policy_info.commission_status","1");
      	$this->db->where("policy_info.vocher_status","0");
      	
      	if($from_date !="")
      	{
          	$this->db->where("policy_info.policy_issue_date >=",$from_date);
      	    $this->db->where("policy_info.policy_issue_date <=",$to_date);
      	}
      	
      	$this->db->where("policy_info.policy_agency_pos",$agent_id);
      	return $this->db->get("policy_info")->result();
   }
   
   public function randomcheck($randomString)
   {
       $this->db->where("vocher_no",$randomString);
       $query=$this->db->get("policy_info")->num_rows();
       
       if($query > 0)
        {
            return false;
        }
        else
        {
            return true;
        }
   }
   
   public function update_vocher_details($data,$id)
   {
       $this->db->where("id",$id);
       $this->db->update("policy_info",$data);
       
       $this->db->where("id",$id);
       return $this->db->get("policy_info")->row();
   }
   
   // company details 
   
   public function get_company_details()
   {
       return $this->db->get("company_settings")->row();
   }
   
   public function fetch_agent_vocher($policy_id)
   {
        $this->db->select("policy_info.id,policy_info.policy_issue_date,policy_info.agent_commission_amt,policy_info.agn_add_com,policy_info.created_at,policy_info.policy_agency_pos,list_of_leads.business_type,policy_info.policy_premium,list_of_leads.class,policy_info.company,policy_info.gst,policy_info.policy_s_date,policy_info.policy_ex_date,list_of_premium_cover_type.name as policy_premium_name,type_of_bussiness.bussiness_type as business_name,list_of_class.class as class_name,list_of_policy_type.policy_type,policy_info.total_own_damage,policy_info.basic_tp,policy_info.total_premium,policy_info.policy_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_pos_and_agents.agent_pos_code,list_of_insurance_company.company_name");
      	$this->db->join("list_of_leads","policy_info.lead_id = list_of_leads.id");
  	    $this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("list_of_pos_and_agents","policy_info.policy_agency_pos = list_of_pos_and_agents.id");
  	    $this->db->join("list_of_insurance_company","policy_info.company = list_of_insurance_company.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("list_of_premium_cover_type","policy_info.policy_premium = list_of_premium_cover_type.id",'left');
      	$this->db->where("policy_info.commission_status","1");
      	$this->db->where("list_of_leads.lead_type","2");
      	$this->db->where("policy_info.vocher_status","1");
      	$this->db->where("policy_info.id",$policy_id);
      	return $this->db->get("policy_info")->result();
   }
   
   public function get_vocher_no()
   {
      return $this->db->get("vocher_series")->num_rows();
   }
   
   
   public function vocher_no_already_exits($new_vocher_no)
   {
        $this->db->where("vocher_no",$new_vocher_no);
  		$num = $this->db->get("vocher_series")->num_rows();
  		
  		if($num > 0)
  		{
  		    return true;
  		}
  		else
  		{
  		    $data = array(
  		        "vocher_no" => $new_vocher_no,
  		        );
  		    $this->db->insert("vocher_series",$data);
  		    return false;
        }
   }
   
   public function add_agent_voucher_details($data)
   {
       $this->db->insert("agent_voucher_details",$data);
   }
   
   public function update_tds_log($data)
   {
       $this->db->insert("tds_log",$data);
   }
   
   // agent voucher
   
   public function fetch_bank_list()
   {
       return $this->db->get("list_of_bank_name")->result();
   }
   
   public function fetch_agent_vouchers($agents)
   {
        $this->db->select("SUM(agent_commission_amt) AS ac,SUM(agn_add_com) As add_com,policy_info.Vocher_no,policy_info.vocher_date,policy_info.policy_agency_pos");
      	$this->db->where("policy_info.commission_status","1");
      	$this->db->where("policy_info.pay_status","0");
      	$this->db->where("policy_info.vocher_status","1");
      	$this->db->group_by("policy_info.vocher_no");
      	
      	if($agents != "all")
      	{
      	    $this->db->where("policy_info.policy_agency_pos",$agents);
      	}
      	
      	return $this->db->get("policy_info")->result();
   }
   
   public function fetch_agent_vouchers_list($agents,$f_date,$to_date)
   {
        $this->db->select("SUM(agent_commission_amt) AS ac,SUM(tds) AS tc,SUM(agn_add_com) As add_com,policy_info.Vocher_no,policy_info.vocher_date,policy_info.policy_agency_pos");
      	$this->db->where("policy_info.commission_status","1");
      	$this->db->where("policy_info.pay_status","0");
      	$this->db->where("policy_info.vocher_status","1");
      	$this->db->group_by("policy_info.vocher_no");
      
      	if($agents != "all")
      	{
      	    $this->db->where("policy_info.policy_agency_pos",$agents);
      	}
      	if($f_date != "" &&  $to_date != "")
      	{
      	    $this->db->where("policy_info.vocher_date >=",$f_date);
      	    $this->db->where("policy_info.vocher_date <=",$to_date);
      	}
      	
      	return $this->db->get("policy_info")->result();
   }
   
   
   public function fetch_agent_advance_list()
   {
       $this->db->select("agent_pos_advance.*,list_of_pos_and_agents.name as agn_name,list_of_pos_and_agents.agent_pos_code");
       $this->db->from("agent_pos_advance");
       $this->db->join("list_of_pos_and_agents","agent_pos_advance.agent_id = list_of_pos_and_agents.id");
       $this->db->group_by('agent_pos_advance.agent_id'); 
       return $this->db->get()->result();
   }
   
   public function fetch_advance_debit_amount_by_agent_id($agent_id)
   {
       $this->db->select("SUM(amount)AS debit_tot");
       $this->db->from("agent_pos_advance");
       $this->db->where("agent_id",$agent_id);
       $this->db->where("type","debit");
       return $this->db->get()->row();
   }
   public function fetch_advance_credit_amount_by_agent_id($agent_id)
   {
       $this->db->select("SUM(amount)AS credit_tot");
       $this->db->from("agent_pos_advance");
       $this->db->where("agent_id",$agent_id);
       $this->db->where("type","credit");
       return $this->db->get()->row();
   }
   
   public function get_voucher_total($voucher_no)
   {
       $this->db->select("agent_commission_amt as ac,agn_add_com as agn_add_com_amt");
       $this->db->from("policy_info");
       $this->db->where_in("vocher_no",$voucher_no);
       	$this->db->where("policy_info.commission_status","1");
      	$this->db->where("policy_info.pay_status","0");
      	$this->db->where("policy_info.vocher_status","1");
       return $this->db->get()->result();
   }
   
   
   public function get_voucher_total_1($voucher_no)
   {
       if($voucher_no != null || $voucher_no != "")
       {
          $this->db->select("total_commission as ac,tds as total_tds");
           $this->db->from("agent_voucher_details");
           $this->db->where_in("voucher_no",$voucher_no);
           return $this->db->get()->result();
       }
       else
       {
           return array();
       }
       
   }
   
  public function get_agent_id($vocher_no)
  {
        $this->db->select("policy_agency_pos,agent_commission_amt as ac,agn_add_com as agn_add_com_amt");
        $this->db->from("policy_info");
        $this->db->where_in("vocher_no",$vocher_no);
       	$this->db->where("policy_info.commission_status","1");
      	$this->db->where("policy_info.pay_status","0");
        $this->db->where("policy_info.vocher_status","1");
       return $this->db->get()->result();
  }
   
   public function add_agn_payment_entry($data)
   {
       $this->db->insert("agent_payment_details",$data);
       $insert_id = $this->db->insert_id();
       return $insert_id;
   }
   
   public function update_pay_status($data,$vocher_no)
   {
       $this->db->where("vocher_no",$vocher_no);
       $this->db->update("policy_info",$data);
   }
   
   
   public function get_policy_cover_type()
   {
       return $this->db->get("list_of_premium_cover_type")->result();
   }
   
   // active policy report
   
   public function fetch_active_policy_report($ins_company,$select_class,$select_c_type,$from_date,$to_date)
   { 
        $this->db->select("policy_info.id,policy_info.policy_issue_date,policy_info.tot_liability_premium,policy_info.com_add_com,policy_info.agn_add_com,policy_info.own_commission_amt,policy_info.agent_commission_amt,policy_info.commission_status,policy_info.policy_agency_pos,list_of_leads.business_type,policy_info.policy_premium,list_of_leads.class,policy_info.company,policy_info.gst,policy_info.policy_s_date,policy_info.policy_ex_date,list_of_premium_cover_type.name as policy_premium_name,type_of_bussiness.bussiness_type as business_name,list_of_class.class as class_name,list_of_policy_type.policy_type,policy_info.total_own_damage,policy_info.basic_tp,policy_info.total_premium,policy_info.policy_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_pos_and_agents.agent_pos_code,list_of_pos_and_agents.name as agn_name,list_of_insurance_company.company_name,list_of_insurance_company.short_name as ins_short_name");
      	$this->db->join("list_of_leads","policy_info.lead_id = list_of_leads.id");
  	    $this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("list_of_pos_and_agents","policy_info.policy_agency_pos = list_of_pos_and_agents.id");
  	    $this->db->join("list_of_insurance_company","policy_info.company = list_of_insurance_company.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("list_of_premium_cover_type","policy_info.policy_premium = list_of_premium_cover_type.id","left");
  	    
  	    if($this->session->userdata("session_role") == "AI")
  	    {
  	        $this->db->where("list_of_leads.area_incharge",$this->session->userdata("session_id"));
  	    }
  	    if($ins_company != "all")
  	    {
  	        $this->db->where("policy_info.company",$ins_company);
  	    }
  	    if($select_class != "all")
  	    {
  	        $this->db->where("list_of_leads.class",$select_class);
  	    }
  	    if($select_c_type != "all")
  	    {
  	        $this->db->where("policy_info.policy_premium",$select_c_type);
  	    }
  	    if($from_date != "all")
  	    {
  	        $this->db->where("policy_info.policy_issue_date >=",$from_date);
  	    }
  	    if($to_date != "all")
  	    {
  	        $this->db->where("policy_info.policy_issue_date <=",$to_date);
  	    }
  	    $this->db->where("list_of_leads.lead_type","2");
  	    //$this->db->where("policy_info.policy_ex_date >",date("Y-m-d"));
  	    return $this->db->get("policy_info")->result();
   }
   
   
   public function get_insurance_company_list()
   {
       return $this->db->get("list_of_insurance_company")->result();
   }
   
   public function get_class_list()
   {
       return $this->db->get("list_of_class")->result();
   }
   
   public function get_policy_type($class)
   {
       $this->db->where("policy_class",$class);
       $this->db->where("status !=","1");
       return $this->db->get("list_of_policy_type")->result();
   }
   
   public function get_net_premium_id($net_id)
   {
        $this->db->where("net_premium_id",$net_id);
        return $this->db->get("company_payout_commission")->result();
   }
   
   public function get_total_premium($id)
   {
       $this->db->where("commission_id",$id);
       return $this->db->get("policy_info")->result();
   }
   
   public function fetch_commission_id($from_date,$to_date)
   {
        $this->db->where("from_date >=",$from_date);
        $this->db->where("to_date >=",$to_date);
        return $this->db->get("company_payout_commission")->result();
   }
   
   public function fetch_agent_category($id)
  	{
  	    $this->db->where("id",$id);
  	    return $this->db->get("list_of_pos_and_agents")->row();
  	}
   
   public function update_additional_commissions($id,$data)
   {
       $this->db->where("id",$id);
       $this->db->update("policy_info",$data);
   }
   
   //nop
   public function get_no_of_policy_id($net_id)
   {
        $this->db->where("no_of_policy_id",$net_id);
        return $this->db->get("company_payout_commission")->result();
   }
   
   public function get_total_policy($id)
   {
       $this->db->where("commission_id",$id);
       return $this->db->get("policy_info")->result();
   }
   
   public function fetch_all_leads($order_category)
   {
        $this->db->select("list_of_leads.*,vechile_details.vechi_register_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_clients.other_contact_details,list_of_clients.landline_no,list_of_clients.address,list_of_clients.contact_person_name,list_of_clients.date_of_birth,list_of_clients.age,list_of_clients.area,type_of_bussiness.bussiness_type as b_type,list_of_class.class as lclass,list_of_policy_type.policy_type as p_type");
       	$this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("vechile_details","vechile_details.lead_id = list_of_leads.id",'left');
  	    
  	    if($order_category == "upcoming")
  	    {
  	        $this->db->where("list_of_leads.due_date >=",date("Y-m-d"));
  	        $this->db->where("list_of_leads.due_date !=","0000-00-00");
  	        $this->db->order_by("list_of_leads.due_date","asc");
  	    }
  	    else if($order_category == "overdue")
  	    {
  	        $this->db->where("list_of_leads.due_date <",date("Y-m-d"));
  	        $this->db->where("list_of_leads.due_date !=","0000-00-00");
  	        $this->db->order_by("list_of_leads.due_date","desc");
  	    }
  	    else
  	    {
  	        $this->db->where("list_of_leads.due_date","0000-00-00");
  	        $this->db->order_by("list_of_leads.id","desc");
  	    }
  	    
  	    $this->db->where("lead_type !=","2");
  	    return $this->db->get("list_of_leads")->result();
   }
   
    public function get_agent_name($id)
   {
       $this->db->where("id",$id);
       return $this->db->get("list_of_pos_and_agents")->row();
   }
   public function get_user_name($id)
   {
       $this->db->where("id",$id);
       return $this->db->get("admin_login")->row();
   }
   
   public function get_area_incharge($id)
   {
        $this->db->where("id",$id);
        return $this->db->get("admin_login")->row();
   }
   
   public function get_agent_bank_details($agent)
   {
       $this->db->where("id",$agent);
       return $this->db->get("list_of_pos_and_agents")->row();
   }
  
   public function add_agent_vocher_payment($data_1)
   {
       $this->db->insert("agent_vocher_payment",$data_1);
   }
   
   public function fetch_agent_payment_details($agent,$policy_no,$voucher_no)
   {
       $this->db->select("agent_payment_details.*,agent_vocher_payment.vocher_no,list_of_pos_and_agents.name,list_of_pos_and_agents.agent_pos_code,admin_login.name as created_by");
       $this->db->from("agent_payment_details");
       $this->db->join("agent_vocher_payment","agent_payment_details.id = agent_vocher_payment.payment_id");
       $this->db->join("list_of_pos_and_agents","list_of_pos_and_agents.id = agent_payment_details.agent_id");
       $this->db->group_by('agent_vocher_payment.payment_id'); 
       $this->db->join("admin_login","admin_login.id = agent_payment_details.created_by");
       $this->db->join("policy_info","policy_info.vocher_no = agent_vocher_payment.vocher_no");
       
       if($agent != "All")
       {
         $this->db->where("agent_payment_details.agent_id",$agent);
       }
       if($policy_no != "")
       {
           $this->db->where("policy_info.policy_no",$policy_no);
       }
       if($voucher_no != "")
       {
           $this->db->where("agent_vocher_payment.vocher_no",$voucher_no);
       }
       $this->db->order_by('transaction_date','Desc');
       return $this->db->get()->result();
   }
   
   public function fetch_agents_list()
   {
       return $this->db->get("list_of_pos_and_agents")->result();
   }
   
   public function fetch_area_incharge_list()
   {
       $this->db->where("role","AI");
       return $this->db->get("admin_login")->result();
   }
   
   public function fetch_users_list()
   {
       $this->db->where("role","user");
       return $this->db->get("admin_login")->result();
   }
   
   public function get_agent_vocher_details($id)
   {
       $this->db->select("agent_payment_details.*,list_of_pos_and_agents.name,list_of_pos_and_agents.agent_pos_code,admin_login.name as area_incharge,list_of_pos_and_agents.region,list_of_pos_and_agents.region");
       $this->db->from("agent_payment_details");
       $this->db->join("list_of_pos_and_agents","list_of_pos_and_agents.id = agent_payment_details.agent_id");
       $this->db->join("admin_login","admin_login.id = list_of_pos_and_agents.area_incharge");
       $this->db->where("agent_payment_details.id",$id);
       return $this->db->get()->row();
   }
   
   public function get_region($region_id)
   {
       $this->db->where("id",$region_id);
       return $this->db->get("list_of_reigion")->row();
   }
   
   public function get_voucher_no_by_payment_id($id)
   {
       $this->db->where("payment_id",$id);
       return $this->db->get("agent_vocher_payment")->result();
   }
   
   public function get_voucher_total_amount($voucher_no)
   {
       if($voucher_no != null)
       {
            $this->db->select("vocher_no,SUM(agent_commission_amt) as ac,SUM(agn_add_com) as agn_add_com_amt,SUM(tds) as tc");
            $this->db->from("policy_info");
            $this->db->where_in("vocher_no",$voucher_no);
            $this->db->where("policy_info.commission_status","1");
            $this->db->where("policy_info.pay_status","1");
            $this->db->where("policy_info.vocher_status","1");
            $this->db->group_by('vocher_no'); 
            return $this->db->get()->result();
       }
       else
       {
           return array();
       }
   }
   
   public function fetch_agent_voucher_details($vocher_no)
   {
        $this->db->select("policy_info.id,policy_info.agent_commission_amt,policy_info.agn_add_com,policy_info.created_at,policy_info.policy_agency_pos,list_of_leads.business_type,policy_info.policy_premium,list_of_leads.class,policy_info.company,policy_info.gst,policy_info.policy_s_date,policy_info.policy_ex_date,list_of_premium_cover_type.name as policy_premium_name,type_of_bussiness.bussiness_type as business_name,list_of_class.class as class_name,list_of_policy_type.policy_type,policy_info.total_own_damage,policy_info.basic_tp,policy_info.total_premium,policy_info.policy_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_pos_and_agents.agent_pos_code,list_of_insurance_company.company_name");
      	$this->db->join("list_of_leads","policy_info.lead_id = list_of_leads.id");
  	    $this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("list_of_pos_and_agents","policy_info.policy_agency_pos = list_of_pos_and_agents.id");
  	    $this->db->join("list_of_insurance_company","policy_info.company = list_of_insurance_company.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("list_of_premium_cover_type","policy_info.policy_premium = list_of_premium_cover_type.id",'left');
      	$this->db->where("policy_info.commission_status","1");
      	$this->db->where("policy_info.vocher_status","1");
      	//$this->db->where("policy_info.pay_status","1");
      	$this->db->where("policy_info.vocher_no",$vocher_no);
      	return $this->db->get("policy_info")->result();
   }
   
   public function get_agent_details_by_vocher_no($vocher_no)
   {
       $this->db->where("vocher_no",$vocher_no);
       return $this->db->get("policy_info")->row();
   }
   
   public function add_advance_amount($data)
  	{
  	    $this->db->insert("agent_pos_advance",$data);
  	}
  	
  public function fetch_business_complete_report($ins_company,$select_class,$policy_type,$agent,$from_date,$to_date,$area_incharge,$user)
   { 
        $this->db->select("policy_info.id,policy_info.tot_liability_premium,policy_info.lead_id,policy_info.policy_issue_date,policy_info.com_add_com,policy_info.agn_add_com,policy_info.own_commission_amt,policy_info.agent_commission_amt,policy_info.commission_status,policy_info.policy_agency_pos,list_of_leads.business_type,policy_info.policy_premium,list_of_leads.class,list_of_leads.assigned_user,policy_info.company,policy_info.gst,policy_info.policy_s_date,policy_info.policy_ex_date,list_of_premium_cover_type.name as policy_premium_name,type_of_bussiness.bussiness_type as business_name,list_of_class.class as class_name,list_of_policy_type.policy_type,policy_info.total_own_damage,policy_info.basic_tp,policy_info.total_premium,policy_info.policy_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_pos_and_agents.agent_pos_code,list_of_pos_and_agents.name as agn_name,list_of_insurance_company.company_name,list_of_insurance_company.short_name as ins_short_name,admin_login.name as ai_name,vechile_details.vechi_cc,vechile_details.vechi_gvw,vechile_details.vechi_register_no,list_of_policy_type.policy_type as p_type");
      	$this->db->join("list_of_leads","policy_info.lead_id = list_of_leads.id");
  	    $this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("list_of_pos_and_agents","policy_info.policy_agency_pos = list_of_pos_and_agents.id");
  	    $this->db->join("list_of_insurance_company","policy_info.company = list_of_insurance_company.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	     $this->db->join("admin_login","admin_login.id = list_of_leads.area_incharge",'left');
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("list_of_premium_cover_type","policy_info.policy_premium = list_of_premium_cover_type.id",'left');
  	    $this->db->join("vechile_details","vechile_details.lead_id = list_of_leads.id",'left');
        if($this->session->userdata("session_role") == "AI")
        {
        	$this->db->where("list_of_leads.area_incharge",$this->session->userdata("session_id"));
        }

  	    if($ins_company != "All")
  	    {
  	        $this->db->where("policy_info.company",$ins_company);
  	    }
  	    if($select_class != "All")
  	    {
  	        $this->db->where("list_of_leads.class",$select_class);
  	    }
  	    if($policy_type != "All")
  	    {
  	        $this->db->where("list_of_leads.policy_type",$policy_type);
  	    }
  	    if($from_date != "All" || $from_date != "")
  	    {
  	        $this->db->where("policy_info.policy_issue_date >=",$from_date);
  	    }
  	    if($to_date != "All" || $to_date != "")
  	    {
  	       $this->db->where("policy_info.policy_issue_date <=",$to_date);
  	    }
  	    if($agent != "All")
  	    {
  	      $this->db->where("policy_info.policy_agency_pos",$agent);
  	    }
  	    if($area_incharge != "All")
  	    {
  	         $this->db->where("list_of_leads.area_incharge",$area_incharge);
  	    }
  	    if($user != "All")
  	    {
  	         $this->db->where("list_of_leads.assigned_user",$user);
  	    }
  	    //$this->db->where("policy_info.policy_ex_date >",date("Y-m-d"));
  	    $this->db->order_by("policy_info.policy_issue_date","Asc");
  	    $this->db->where("list_of_leads.lead_type","2");
  	    return $this->db->get("policy_info")->result();
   }
  	
   public function fetch_generate_policy_report($ins_company,$select_class,$policy_type,$agent,$from_date,$to_date,$area_incharge,$user)
   { 
        $this->db->select("temp_policy_info.id,temp_policy_info.tot_liability_premium,temp_policy_info.lead_id,temp_policy_info.policy_issue_date,temp_policy_info.com_add_com,temp_policy_info.agn_add_com,temp_policy_info.own_commission_amt,temp_policy_info.agent_commission_amt,temp_policy_info.commission_status,temp_policy_info.policy_agency_pos,list_of_leads.business_type,temp_policy_info.policy_premium,list_of_leads.class,list_of_leads.assigned_user,temp_policy_info.company,temp_policy_info.gst,temp_policy_info.policy_s_date,temp_policy_info.policy_ex_date,list_of_premium_cover_type.name as policy_premium_name,type_of_bussiness.bussiness_type as business_name,list_of_class.class as class_name,list_of_policy_type.policy_type,temp_policy_info.total_own_damage,temp_policy_info.basic_tp,temp_policy_info.total_premium,temp_policy_info.policy_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_pos_and_agents.agent_pos_code,list_of_pos_and_agents.name as agn_name,list_of_insurance_company.company_name,list_of_insurance_company.short_name as ins_short_name,admin_login.name as ai_name,vechile_details.vechi_cc,vechile_details.vechi_gvw,vechile_details.vechi_register_no,list_of_policy_type.policy_type as p_type");
      	$this->db->join("list_of_leads","temp_policy_info.lead_id = list_of_leads.id");
  	    $this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("list_of_pos_and_agents","temp_policy_info.policy_agency_pos = list_of_pos_and_agents.id");
  	    $this->db->join("list_of_insurance_company","temp_policy_info.company = list_of_insurance_company.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("list_of_premium_cover_type","temp_policy_info.policy_premium = list_of_premium_cover_type.id",'left');
  	    
  	    $this->db->join("admin_login","admin_login.id = list_of_leads.area_incharge",'left');
  	    $this->db->join("vechile_details","vechile_details.lead_id = list_of_leads.id",'left');

  	     if($this->session->userdata("session_role") == "AI")
        {
        	$this->db->where("list_of_leads.area_incharge",$this->session->userdata("session_id"));
        }
  	    if($ins_company != "All")
  	    {
  	        $this->db->where("temp_policy_info.company",$ins_company);
  	    }
  	    if($select_class != "All")
  	    {
  	        $this->db->where("list_of_leads.class",$select_class);
  	    }
  	    if($policy_type != "All")
  	    {
  	        $this->db->where("list_of_leads.policy_type",$policy_type);
  	    }
  	    if($from_date != "All")
  	    {
  	        $this->db->where("temp_policy_info.policy_issue_date >=",$from_date);
  	    }
  	    if($to_date != "All")
  	    {
  	        $this->db->where("temp_policy_info.policy_issue_date <=",$to_date);
  	    }
  	    if($agent != "All")
  	    {
  	      $this->db->where("temp_policy_info.policy_agency_pos",$agent);
  	    }
  	    if($area_incharge != "All")
  	    {
  	         $this->db->where("list_of_leads.area_incharge",$area_incharge);
  	    }
  	    if($user != "All")
  	    {
  	         $this->db->where("list_of_leads.assigned_user",$user);
  	    }
  	    $this->db->order_by("temp_policy_info.policy_issue_date","Asc");
  	    //$this->db->where("list_of_leads.policy_status","1");
  	    $this->db->where("list_of_leads.lead_type !=","2");
  	    return $this->db->get("temp_policy_info")->result();
   }
   
 
   public function fetch_policy_failure_report($select_class,$policy_type,$from_date,$to_date,$foe)
   {
        $this->db->select("list_of_leads.*,vechile_details.vechi_register_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_clients.other_contact_details,list_of_clients.landline_no,list_of_clients.address,list_of_clients.contact_person_name,list_of_clients.date_of_birth,list_of_clients.age,list_of_clients.area,type_of_bussiness.bussiness_type as b_type,list_of_class.class as lclass,list_of_policy_type.policy_type as p_type");
       	$this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("vechile_details","vechile_details.lead_id = list_of_leads.id",'left');
  	    $this->db->where("list_of_leads.due_date >=",$from_date);
  	    $this->db->where("list_of_leads.due_date <=",$to_date);
  	   
  	    if($select_class != "all")
  	    {
  	        $this->db->where("list_of_leads.class",$select_class);
  	    }
  	    if($policy_type != "all")
  	    {
  	        $this->db->where("list_of_leads.policy_type",$policy_type);
  	    }
  	    if($foe != "All")
  	    {
  	        $this->db->where("list_of_leads.assigned_user",$foe);
  	    }
  	    
  	    
  	    $this->db->where("policy_status !=","1");
  	    $this->db->where("lead_type !=","2");
  	    $this->db->order_by("list_of_leads.due_date","Asc");
  	    return $this->db->get("list_of_leads")->result();
   }
  
   public function policy_renewal_report()
   {
       $this->db->select("list_of_leads.*,vechile_details.vechi_register_no,list_of_clients.client_name,list_of_clients.mobile_no,list_of_clients.other_contact_details,list_of_clients.landline_no,list_of_clients.address,list_of_clients.contact_person_name,list_of_clients.date_of_birth,list_of_clients.age,list_of_clients.area,type_of_bussiness.bussiness_type as b_type,list_of_class.class as lclass,list_of_policy_type.policy_type as p_type");
       	$this->db->join("list_of_clients","list_of_leads.client_id = list_of_clients.id");
  	    $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("vechile_details","vechile_details.lead_id = list_of_leads.id",'left');
  	    $this->db->where("list_of_leads.due_date >=",$from_date);
  	    $this->db->where("list_of_leads.due_date <=",$to_date);
  	    $this->db->where("policy_status !=","1");
  	    $this->db->where("lead_type !=","2");
  	    $this->db->order_by("list_of_leads.due_date","Asc");
  	    return $this->db->get("list_of_leads")->result();
   }
   
   public function get_tds_percentage()
   {
       return $this->db->get("tds")->row();
   }
   
   public function get_tds_amount($vocher_no)
   {
       $this->db->where("vocher_no",$vocher_no);
       return $this->db->get("tds_log")->row();
       
   }
   
   public function get_total_tds_amount($vocher_arr)
   {
        $this->db->select_sum('tds_amount');
        $this->db->where_in("vocher_no",$vocher_arr);
        $result = $this->db->get('tds_log')->row();  
        return $result->tds_amount;
   }
   
   public function get_foe_details($foe_id)
   {
       $this->db->where("id",$foe_id);
       return $this->db->get("admin_login")->row();
   }
   
   public function get_foe_reports($foe_id,$date,$order_by)
   {
       $this->db->select("list_website_followup.*,admin_login.name as ai_name,list_of_pos_and_agents.name as agent_name,list_of_pos_and_agents.agent_pos_code");
       $this->db->from("list_website_followup");
       $this->db->join("list_of_pos_and_agents","list_website_followup.agent_id =list_of_pos_and_agents.id",'left');
       $this->db->join("admin_login","list_website_followup.area_incharge_id =admin_login.id",'left');
       
       if($foe_id != "all")
       {
           $this->db->where("list_website_followup.created_id",$foe_id);
       }
       
       if($order_by == "date")
       {
           $this->db->order_by("list_website_followup.created_at","Asc");
       }
       else 
       {
           $this->db->order_by("list_website_followup.created_id","Asc");
       }
       
       $this->db->where("date(list_website_followup.created_at)",$date);
       return $this->db->get()->result();
   }
   
   public function get_ledger_acc($code)
   {
       $this->db->where("account_name",$code);
       $this->db->where("accvarcharid","acc0");
       return $this->db->get("account_tree")->row();
   }
   
   public function get_agent_code_by_id($agent_id)
   {
       $this->db->where("id",$agent_id);
       return $this->db->get("list_of_pos_and_agents")->row();
   }
   
   public function add_agent_commission($data)
   {
       $this->db->insert("agent_commission",$data);
   }
   
   public function get_total_credit_amount($agent_id)
   {
       $this->db->where("agent_id",$agent_id);
       $this->db->select('SUM(credit) as credit_tot');
       return $this->db->get("agent_commission")->row();
   }
   
   public function get_total_debit_amount($agent_id)
   {
        $this->db->select('SUM(debit) as debit_tot');
        $this->db->where("agent_id",$agent_id);
       return $this->db->get("agent_commission")->row();
   }
   
   public function update_ledger($data,$acc_name)
   {
       $this->db->where("account_id",$acc_name);
       $this->db->update("account_tree",$data);
   }
   
   // 
   
   public function get_tds_amount_by_voucher_no($voucher_no,$agents)
   {
       $this->db->where("vocher_no",$voucher_no);
       $this->db->where("agent_id",$agents);
       return $this->db->get("tds_log")->row();
   }
 
   public function get_tds_accvarcharid($agent_id)
   {
       $this->db->where("account_name",$agent_id);
       $this->db->where("accvarcharid","acc0226");
       return $this->db->get("account_tree")->row();
   }
   
   public function get_agent_tds_credit_amount($agent_id)
   {
        $this->db->select('SUM(tds_amount) as credit_tot');
       $this->db->where("agent_id",$agent_id);
       return $this->db->get("tds_log")->row();
   }
   
   public function get_agent_tds_debit_amount($agent_id)
   {
        $this->db->where("agent_id",$agent_id);
       $this->db->select('SUM(debit) as debit_tot');
       return $this->db->get("tds_log")->row();
   }
   
   public function update_tds_ledger($data,$acc_name)
   {
       $this->db->where("account_id",$acc_name);
       $this->db->update("account_tree",$data);
   }
   
   //
   
   public function get_total_tds_credit_amount()
   {
        $this->db->select('SUM(tds_amount) as total_credit_amt');
       return $this->db->get("tds_log")->row();
   }
   
   public function get_total_tds_debit_amount()
   {
       $this->db->select('SUM(debit) as total_debit_amt');
       return $this->db->get("tds_log")->row();
   }
   
   public function add_acc_own_commission($accarr)
   {
       $this->db->insert("acc_commission_ledger",$accarr);
   }
   
   public function check_sr_no_already_exits($new_sr_no)
    {
        $this->db->where("sr_no",$new_sr_no);
  		$num = $this->db->get("acc_commission_ledger")->num_rows();
  		if($num > 0)
  		{
  		    return true;
  		}
  		else
  		{
  		    return false;
  		}
    }
    
    //
   public function business_complete_records($from_limit,$to_limit,$report_status)
   { 
        $this->db->distinct("company");
        $this->db->join("list_of_leads","policy_info.lead_id = list_of_leads.id");
        
  	    if($from_limit != "All" || $from_limit != "")
  	    {
  	        $this->db->where("policy_info.policy_issue_date >=",$from_limit);
  	    }
  	    if($to_limit != "All" || $to_limit != "")
  	    {
  	       $this->db->where("policy_info.policy_issue_date <=",$to_limit);
  	    }
  	    if($report_status == "insurer_wise")
  	    {
  	        $this->db->group_by("policy_info.company");
  	    }
  	    $this->db->order_by("policy_info.policy_issue_date","Asc");
  	    $this->db->where("list_of_leads.lead_type","2");
  	    return $this->db->get("policy_info")->result();
   }
   
   public function generate_policy_records($from_limit,$to_limit,$report_status)
   { 
        $this->db->select("company");
  	    $this->db->join("list_of_leads","temp_policy_info.lead_id = list_of_leads.id");
  	    if($from_limit != "")
  	    {
  	        $this->db->where("temp_policy_info.policy_issue_date >=",$to_limit);
  	    }
  	    if($to_limit != "")
  	    {
  	        $this->db->where("temp_policy_info.policy_issue_date <=",$to_limit);
  	    }
  	    if($report_status == "insurer_wise")
  	    {
  	        $this->db->group_by("temp_policy_info.company");
  	    }
  	    $this->db->where("list_of_leads.lead_type !=","2");
  	    return $this->db->get("temp_policy_info")->result();
   }
  	
   public function fetch_sum_business_complete_report($from_limit,$to_limit,$report_status,$key_id)
   { 
        $this->db->select("sum(total_premium) as tot_premium");
        $this->db->join("list_of_leads","policy_info.lead_id = list_of_leads.id");
        $this->db->join("list_of_pos_and_agents","policy_info.policy_agency_pos = list_of_pos_and_agents.id");
        $this->db->join("list_of_insurance_company","policy_info.company = list_of_insurance_company.id");
        $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
        $this->db->join("admin_login","admin_login.id = list_of_leads.area_incharge",'left');
        $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
        
  	    if($from_limit != "All" || $from_limit != "")
  	    {
  	        $this->db->where("policy_info.policy_issue_date >=",$from_limit);
  	    }
  	    if($to_limit != "All" || $to_limit != "")
  	    {
  	       $this->db->where("policy_info.policy_issue_date <=",$to_limit);
  	    }
  	    if($report_status == "insurer_wise")
  	    {
  	        $this->db->where("policy_info.company",$key_id);
  	    }
  	    else if($report_status == "Area_incharge_wise")
  	    {
  	        $this->db->where("list_of_leads.area_incharge",$key_id);
  	    }
  	    else if($report_status == "policy_class_wise")
  	    {
  	        $this->db->where("list_of_leads.class",$key_id);
  	    }
  	    $this->db->order_by("policy_info.policy_issue_date","Asc");
  	    $this->db->where("list_of_leads.lead_type","2");
  	    return $this->db->get("policy_info")->row();
   }
  	
   public function fetch_sum_generate_policy_report($from_limit,$to_limit,$report_status,$key_id)
   { 
        $this->db->select("sum(total_premium) as tot_premium");
      	$this->db->join("list_of_leads","temp_policy_info.lead_id = list_of_leads.id");
  	    $this->db->join("list_of_pos_and_agents","temp_policy_info.policy_agency_pos = list_of_pos_and_agents.id");
  	    $this->db->join("list_of_insurance_company","temp_policy_info.company = list_of_insurance_company.id");
  	    $this->db->join("list_of_class","list_of_leads.class = list_of_class.id");
  	    $this->db->join("list_of_policy_type","list_of_leads.policy_type = list_of_policy_type.id");
  	    $this->db->join("admin_login","admin_login.id = list_of_leads.area_incharge",'left');
  	
  	    if($from_limit != "All" || $from_limit != "")
  	    {
  	        $this->db->where("temp_policy_info.policy_issue_date >=",$from_limit);
  	    }
  	    if($to_limit != "All" || $to_limit != "")
  	    {
  	       $this->db->where("temp_policy_info.policy_issue_date <=",$to_limit);
  	    }
  	    if($report_status == "insurer_wise")
  	    {
  	        $this->db->where("temp_policy_info.company",$key_id);
  	    }
  	    else if($report_status == "Area_incharge_wise")
  	    {
  	        $this->db->where("list_of_leads.area_incharge",$key_id);
  	    }
  	    $this->db->order_by("temp_policy_info.policy_issue_date","Asc");
  	    $this->db->where("list_of_leads.lead_type !=","2");
  	    return $this->db->get("temp_policy_info")->row();
   }
   
   
   public function fetch_all_insurance_companies()
   {
       return $this->db->get("list_of_insurance_company")->result();
   }
   
   public function fetch_all_area_incharge()
   {
       $this->db->where("role","AI");
       return $this->db->get("admin_login")->result();
   }
   
   public function fetch_all_class()
   {
       return $this->db->get("list_of_class")->result();
   }
}
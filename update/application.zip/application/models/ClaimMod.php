<?php  
class ClaimMod extends CI_Model  
{  
  	function __construct()  
  	{ 
    	parent::__construct();  
    	$this->load->dbforge();
  	}
  	
  	public function fetch_all_customers()
  	{
  	    $this->db->select("list_of_clients.*,list_of_leads.id as lead_id");
  	    $this->db->from("list_of_clients");
  	    $this->db->join("list_of_leads","list_of_clients.id = list_of_leads.client_id");
  	    $this->db->join("policy_info","list_of_leads.id = policy_info.lead_id");
  	    $this->db->where("list_of_leads.lead_type=",2);
  	    $this->db->where("policy_info.policy_ex_date >=",date("Y-m-d"));
  	    return $this->db->get()->result();
  	}
  	
  	public function list_of_pos_and_agents()
  	{
  	    return $this->db->get("list_of_pos_and_agents")->result();
  	}
  	
  	public function fetch_policy_no($lead_id)
  	{
  	    $this->db->where("lead_id",$lead_id);
  	    return $this->db->get("policy_info")->row();
  	}
  	
  	public function fetch_client_details_by_policy_no($policy_no)
  	{
  	    $this->db->select("list_of_clients.*,list_of_leads.id as lead_id,vechile_details.policy_type,vechile_details.vechile_type,type_of_bussiness.bussiness_type");
  	    $this->db->from("list_of_clients");
  	    $this->db->join("list_of_leads","list_of_clients.id = list_of_leads.client_id");
  	   $this->db->join("type_of_bussiness","list_of_leads.business_type = type_of_bussiness.id");
  	   $this->db->join("vechile_details","list_of_leads.id = vechile_details.lead_id");
  	    $this->db->join("policy_info","list_of_leads.id = policy_info.lead_id");
  	    $this->db->where("list_of_leads.lead_type=",2);
  	    $this->db->where("policy_info.policy_ex_date >=",date("Y-m-d"));
  	    $this->db->where("policy_info.policy_no",$policy_no);
  	    return $this->db->get()->row();
  	}
  	
  	
  	public function insert_spot_photos($data)
  	{
  	    $this->db->insert("spot_photos",$data);
  	}
  	
  	public function add_claim_details($datas)
  	{
  	    $this->db->insert("claim_list",$datas);
  	    return $this->db->insert_id();
  	}
  	
  	public function fetch_claims()
  	{
  	    $this->db->select("claim_list.*,list_of_pos_and_agents.name as agent_name,admin_login.name as user_name");
  	    $this->db->from("claim_list");
  	    $this->db->join("admin_login","claim_list.created_by = admin_login.id");
  	    $this->db->join("list_of_pos_and_agents","claim_list.agent_pos = list_of_pos_and_agents.id");
  	    return $this->db->get()->result();
  	}
  	public function add_claim_report($data)
  	{
  	    $this->db->insert("claim_track",$data);
  	}
  	public function fetch_claim_dateils()
  	{
  	   $this->db->select("claim_track.*,claim_list.client_name as sname");
  	   $this->db->from("claim_track");
  	   $this->db->join("claim_list","claim_track.client_id = claim_list.id");
  	   $this->db->order_by("id","desc");
  	   return $this->db->get()->result();
  	}
  	
  	public function fetch_claims_details()
  	{
  	   $this->db->select("claim_list.*,list_of_clients.client_name as sname, list_of_clients.mobile_no as cmobile,list_of_clients.address as naddress ");
  	   $this->db->from("claim_list");
  	   $this->db->join("list_of_clients","claim_list.client_id = list_of_clients.id");
  	   return $this->db->get()->row();  
  	}
  	
}
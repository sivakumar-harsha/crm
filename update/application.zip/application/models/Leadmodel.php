<?php  
class Leadmodel extends CI_Model  
{  
  	function __construct()  
  	{ 
    	parent::__construct();  
    	$this->load->dbforge();
  	}
  	public function fetch_project_info()
  	{
  		return $this->db->get("project_info")->row();
  	}
  
  public function fetch_renewallead()
    {
            $this->db->select('client_name,list_of_policy_type.policy_type,list_of_leads.business_type,mobile_no,area,policy_ex_date,');
            $this->db->from('list_of_leads');
            $this->db->join('policy_info', 'policy_info.lead_id = list_of_leads.id');
            $this->db->join('list_of_clients', 'list_of_clients.id= list_of_leads.client_id');
            $this->db->join('list_of_policy_type','list_of_policy_type.id=list_of_leads.policy_type');
            $this->db->join('type_of_bussiness','type_of_bussiness.id=list_of_leads.business_type');
            $this->db->where('policy_ex_date >=', date("Y-m-d"));
            $this->db->where('policy_ex_date <=', date('Y-m-d', strtotime(date('Y-m-d').'+1 months')));
           return $this->db->get()->result();
    }
    public function fetch_failurelead()
    {
        $this->db->select('client_name,mobile_no,type_of_bussiness.bussiness_type,list_of_class.class,list_of_policy_type.policy_type,list_of_leads.due_date,');
        $this->db->from('list_of_leads');
        $this->db->join('list_of_class','list_of_class.id=list_of_leads.class');
        $this->db->join('list_of_policy_type','list_of_policy_type.id=list_of_leads.policy_type');
        $this->db->join('list_of_clients', 'list_of_clients.id= list_of_leads.client_id');
        $this->db->join('type_of_bussiness','type_of_bussiness.id=list_of_leads.business_type');
        $this->db->where('list_of_leads.lead_type !=',"2");
        $this->db->where('list_of_leads.policy_status !=',"1");
        $this->db->order_by("due_date", "asc");
         $this->db->where('due_date <', date("Y-m-d"));
        
        return $this->db->get()->result();
        
        
    }
    
    
  
  	
}
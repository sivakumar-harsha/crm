<?php

class AccountsMod extends CI_Model  
{  
  	function __construct()  
  	{ 
    	parent::__construct();  
    	$this->load->dbforge();
  	}
 
    public function fetch_main_ledgers()
  	{
        $this->db->where("parentid","0");
        $this->db->where("chracctype","1");
        return $this->db->get("account_tree")->result();
    }
    
    public function fetch_all_sub_ledgers($main_ledger)
  	{
        $this->db->where("vchparentid",$main_ledger);
        return $this->db->get("account_tree")->result();
    }
    
    
    public function add_sub_ledger($data)
    {
          $this->db->insert("account_tree",$data);        
    }
    
    public function get_last_acc_id()
    {
        $this->db->select_max('accid');
        return $this->db->get("account_tree")->row();
    }
    
    public function get_sub_ledger_details($sub_ledger_id)
    {
        $this->db->where("accid",$sub_ledger_id);
        return $this->db->get("account_tree")->row();
    }
  
  	public function fetch_account_tree()
  	{
  	     $this->db->where("accvarcharid","acc0");
        return $this->db->get("account_tree")->result();
  	}
  	
  	public function get_child_account_tree($accid)
  	{
  	    $this->db->where("parentid",$accid);
        return $this->db->get("account_tree")->result();
  	}
  	
  	public function get_account_details($accid)
  	{
  	     $this->db->where("accid",$accid);
        return $this->db->get("account_tree")->row();
  	}
  	
  	public function get_account_head_for_general_receipt()
  	{
  	    $this->db->where("mainchracctype","2");
  	    return $this->db->get("account_tree")->result();
  	}
  	
   public function check_receipt_no_already_exits($gr_no)
   {
        $this->db->where("gr_no",$gr_no);
  		$num = $this->db->get("gr_series")->num_rows();
  		
  		if($num > 0)
  		{
  		    return true;
  		}
  		else
  		{
  		    $data = array(
  		        "gr_no" => $gr_no,
  		        );
  		    $this->db->insert("gr_series",$data);
  		    return false;
        }
   }
   
   public function check_mv_receipt_no_already_exits($mv_no)
   {
        $this->db->where("mv_no",$mv_no);
  		$num = $this->db->get("mv_series")->num_rows();
  		
  		if($num > 0)
  		{
  		    return true;
  		}
  		else
  		{
  		    $data = array(
  		        "mv_no" => $mv_no,
  		        );
  		    $this->db->insert("mv_series",$data);
  		    return false;
        }
   }
   
   
   
   public function check_pc_receipt_no_already_exits($pc_no)
   {
        $this->db->where("pc_no",$pc_no);
  		$num = $this->db->get("pc_series")->num_rows();
  		
  		if($num > 0)
  		{
  		    return true;
  		}
  		else
  		{
  		    $data = array(
  		        "pc_no" => $pc_no,
  		        "date" =>date("Y-m-d"),
  		        );
  		    $this->db->insert("pc_series",$data);
  		    return false;
        }
   }
   
   public function add_general_receipt($data)
   {
       $this->db->insert("general_receipt",$data);
   }
   
    public function add_mv_receipt($data)
   {
       $this->db->insert("mv_receipt",$data);
   }
   
   public function get_particulars_by_account_head($account_head)
   {
       $this->db->where("accvarcharid",$account_head);
       return $this->db->get("account_tree")->result();
   }
   
   public function print_general_receipt($gr_no)
   {
       $this->db->where("receipt_no",$gr_no);
       return $this->db->get("general_receipt")->row();
   }
   
   public function get_account_name($acc_id)
   {
       $this->db->where("account_id",$acc_id);
       return $this->db->get("account_tree")->row();
       
   }
   
   public function get_cash_entry($particulars)
   {
        $this->db->where("account_id",$particulars);
       return $this->db->get("account_tree")->row();
   }
   
   public function add_credit_cash_entry($data,$particulars)
   {
        $this->db->where("account_id",$particulars);
        $this->db->update("account_tree",$data);
   }
   
   public function fetch_cash_balance()
   {
        $this->db->where("account_id","acc8");
        return $this->db->get("account_tree")->row();
   }
   
   public function get_petty_cash_amount()
   {
       $this->db->where("account_id","acc10");
        return $this->db->get("account_tree")->row();
   }
   
   public function update_pettycash_balance($array)
   {
        $this->db->where("account_id","acc10");
        $this->db->update("account_tree",$array);
   }
   
   public function fetch_view_accounts_ledger($acc_head,$acc_sub,$from_date,$to_date)
   {
       $this->db->select("acc_commission_ledger.*,account_tree.account_name");
       $this->db->from("acc_commission_ledger");
       $this->db->join("account_tree","account_tree.account_id = acc_commission_ledger.cr_parent_id");
       
       if($acc_head != "" && $acc_sub == "")
       {
           $this->db->where("acc_commission_ledger.cr_parent_id",$acc_head);
       }
       if($acc_sub != "")
       {
            $this->db->where("acc_commission_ledger.cr_parent_id",$acc_sub);
       }
       
       if($from_date != "" && $to_date != "")
       {
            $this->db->where("Date(acc_commission_ledger.datetime) >=",$from_date);
            $this->db->where("Date(acc_commission_ledger.datetime) <=",$to_date);
       }
       return $this->db->get()->result();
   }
}
  	?>
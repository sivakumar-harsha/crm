<?php  
class AdvanceMod extends CI_Model  
{  
  	function __construct()  
  	{ 
    	parent::__construct();  
    	$this->load->dbforge();
  	}
  	
  	public function fetch_load_agents()
  	{
  	    return $this->db->get("list_of_pos_and_agents")->result();
  	}
  	
  	public function add_advance_amount($data)
  	{
  	    $this->db->insert("agent_pos_advance",$data);
  	}
  	
  	public function agent_balance_log($ablog)
  	{
  	    $this->db->insert("agent_balance_log",$ablog);
  	}
  	
  	public function fetch_agent_advance($date,$agent)
  	{
  	    $this->db->select("agent_pos_advance.*,list_of_pos_and_agents.name as agent_pos_name,list_of_pos_and_agents.agent_pos_code");
  	    $this->db->from("agent_pos_advance");
  	    $this->db->join("list_of_pos_and_agents","agent_pos_advance.agent_id =list_of_pos_and_agents.id");
  	    $this->db->where("agent_pos_advance.date >=",$date);
  	    $this->db->where("agent_pos_advance.date <=",date("Y-m-t", strtotime($date)));
  	    
  	    if($agent != "All")
  	    {
  	        $this->db->where("agent_pos_advance.agent_id",$agent);
  	    }
  	    
  	    return $this->db->get()->result();
  	}
}